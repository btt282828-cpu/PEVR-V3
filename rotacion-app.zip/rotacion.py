#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROTACION - Smart-Money Flow Terminal (version de escritorio)
============================================================
Descarga datos REALES de fin de dia (gratis, sin API key) de:
  1) Stooq  (fuente principal, sin key)
  2) Yahoo / yfinance  (respaldo automatico, sin key)

Calcula la rotacion sectorial estilo RRG (RS-Ratio / RS-Momentum),
detecta giros tempranos, amplitud, apetito de riesgo y un regimen
macro automatico deducido del propio mercado. Genera un panel HTML
con el mismo aspecto del terminal y lo abre en tu navegador.

USO
---
  python rotacion.py

Se ejecuta despues del cierre de Wall Street (datos de fin de dia).
La primera vez instala solas las librerias que falten.

OPCIONAL (macro mas rico): pon tu key gratuita de FRED abajo en CONFIG.
"""

import sys, subprocess, importlib, os, json, math, time, webbrowser, datetime as dt

# ----------------------------------------------------------------------
# CONFIG  (lo unico que quizas quieras tocar)
# ----------------------------------------------------------------------
BENCH = "SPY"                                   # indice de referencia
SECTORS = ["XLK","XLF","XLE","XLV","XLY","XLP","XLI","XLB","XLU","XLRE","XLC"]
# Tematicos / regionales: China, Emergentes, Espacio-Defensa, 7 Magnificos
THEMATIC = ["FXI","EEM","ITA","MAGS","EWG","EWP","COPX","URA","LIT"]   # EWG=Alemania(DAX), EWP=España(IBEX); COPX=cobre, URA=uranio, LIT=litio
# Extra utiles para detectar rotaciones (viajes, semis, banca regional, biotech, mineras oro, software, vivienda, China tech)
EXTRA = ["JETS","SMH","KRE","XBI","GDX","IGV","SOXX","ITB","KWEB","GRID","PAVE","FIW","CGW","HYDR"]   # ...+ infraestructura de IA: red eléctrica (GRID), construcción (PAVE), agua EE.UU. (FIW), global (CGW) e hidrógeno (HYDR)
SATELLITES = ["IWM","TLT","GLD","HYG","UUP"]     # para riesgo y regimen macro

# Acciones de agua (componentes de FIW) que CREO disponibles como CFD en XTB.
# OJO: no puedo verificarlo en vivo desde aqui y XTB cambia su catalogo; esto es un
# punto de partida con las large-caps mas liquidas. VERIFICALO tu en el buscador de
# instrumentos de XTB antes de operar. Anade o quita tickers a mano segun lo que veas.
XTB_CFD_AGUA = {"ECL","ROP","AWK","FERG","XYL","A","WAT","IDXX","IEX","PNR","MAS","J","ACM","VLTO"}

# === GRUPOS para organizar los paneles (selector del RRG y bloques de tablas) ===
GRUPO_SECTORES = SECTORS + ["IWM"]                                   # 11 basicos + small caps
GRUPO_SUBSECTORES = ["XBI","KRE","JETS","ITB","ITA"]                 # temas EE.UU. no-IA (biotech, banca regional, viajes, vivienda, defensa)
GRUPO_IA = ["SMH","SOXX","IGV","MAGS","GRID","PAVE","FIW","CGW","HYDR"]     # cadena de la IA: chips/software/megacaps + infraestructura (red, construccion, agua, hidrogeno)
COMMODITIES = ["COPX","URA","LIT"]
GRUPO_INTERNAC = ["EEM","FXI","KWEB","EWG","EWP","TLT","HYG","UUP","GLD","GDX"] + COMMODITIES
GRUPO = {}
for _s in GRUPO_SECTORES:    GRUPO[_s] = "sector"
for _s in GRUPO_SUBSECTORES: GRUPO[_s] = "subsector"
for _s in GRUPO_IA:          GRUPO[_s] = "ia"
for _s in GRUPO_INTERNAC:    GRUPO[_s] = "internac"
GRUPO_NOMBRE = {"sector": "Sectores", "subsector": "Subsectores EE.UU.", "ia": "IA e infraestructura", "internac": "Internacional + macro"}
GRUPO_ORDEN = ("sector", "subsector", "ia", "internac")

# Clasificacion en 3 grupos para los paneles (selector del RRG y bloques de las tablas)
GROUPS = {
    "sector":        ["XLK","XLF","XLE","XLV","XLY","XLP","XLI","XLB","XLU","XLRE","XLC","IWM"],
    "subsector":     ["SMH","SOXX","IGV","XBI","KRE","JETS","ITB","MAGS","ITA"],
    "internacional": ["EEM","FXI","KWEB","EWG","EWP","TLT","HYG","UUP","GLD","GDX","COPX","URA","LIT"],
}
GROUP_LABEL = {"sector": "Sectores", "subsector": "Subsectores EE.UU.", "internacional": "Internacional y macro"}
GROUP_OF = {t: g for g, lst in GROUPS.items() for t in lst}
def group_of(sym):
    return GROUP_OF.get(sym, "subsector")
WEEKS = 70                                       # semanas de historico a usar
TAIL = 8                                         # longitud de la estela del RRG
RRG_SOLO_SECTORES = False                        # True = en el RRG solo los 11 sectores SPDR (mas limpio)
TOPUP_YAHOO = True                               # rellenar la ultima barra que falte con Yahoo (frescura); util en local, en la nube puede limitar
DATA_PRIMARY = "stooq"                            # fuente principal: "stooq" (fiable, sin clave) o "yahoo" (mas fresco). La otra queda de respaldo
# --- Acciones lideres por sector (fuerza relativa estilo RS Rating 1-99) ---
STOCK_LEADERS = True                             # añade el panel de acciones lideres (descarga mas datos)
LEADERS_TOP_N = 6                                # cuantas acciones mostrar por sector
LEADERS_MIN_RS = 90                              # umbral de "lider" (percentil)
# Universo para calcular el percentil RS:
#   "sp500"  = las ~500 del S&P 500 (percentil de mercado real; mas lento; por defecto)
#   "sector" = ~164 acciones de SECTOR_STOCKS (mas rapido)
RS_UNIVERSE = "sp500"
SP500_FALLBACK = ["AAPL","MSFT","NVDA","AMZN","META","GOOGL","GOOG","AVGO","TSLA","BRK-B","JPM","LLY","V",
    "UNH","XOM","MA","COST","HD","PG","JNJ","ORCL","ABBV","NFLX","BAC","KO","CRM","CVX","MRK","AMD","PEP",
    "TMO","WFC","ADBE","LIN","CSCO","ACN","MCD","ABT","DHR","GE","TXN","DIS","INTU","QCOM","CAT","VZ","AMGN",
    "PM","IBM","NOW","CMCSA","UNP","SPGI","RTX","PFE","HON","GS","LOW","T","COP","ISRG","BKNG","NEE","UBER",
    "MS","BLK","AXP","SCHW","ETN","C","TJX","ADP","DE","BSX","MDT","GILD","LMT","SYK","VRTX","REGN","CB",
    "MU","PLD","ADI","MMC","SBUX","PANW","BA","SO","AMAT","KLAC","LRCX","DUK","CEG","SHW","ICE","WM","ANET",
    "CRWD","CDNS","SNPS","MRVL","NKE","FCX","NEM","CL","TGT","ORLY","CMG","MCO","APH","FTNT","WELL","EQIX",
    "AON","CME","PNC","USB","TFC","COF","AIG","MET","PRU","AFL","ALL","TRV","BK","ITW","TT","CMI","ROP","CARR",
    "OTIS","GEV","PCAR","PWR","AME","FAST","ODFL","CTAS","RSG","VRSK","EFX","URI","NSC","EMR","GD","FDX","PH",
    "MDLZ","MO","STZ","SYY","KR","ADM","HSY","KDP","MNST","CHD","CLX","K","MKC","TAP","HRL","KMB","GIS","KHC",
    "VLO","MPC","PSX","OXY","KMI","HES","DVN","OKE","HAL","BKR","FANG","TRGP","WMB","SLB","EOG","CTRA","EQT",
    "ELV","CI","HUM","CNC","MOH","CVS","BDX","EW","ZBH","BAX","DXCM","IDXX","IQV","A","MTD","WAT","HOLX","ALGN",
    "STE","RVTY","COO","ZTS","DGX","LH","WST","TFX","HSIC","XRAY","MRNA","BIIB","INCY","RMD","BMY","GEHC",
    "GM","F","ROST","YUM","HLT","AZO","RCL","CCL","NCLH","DHI","LEN","NVR","PHM","MGM","LVS","WYNN","APTV",
    "LULU","TSCO","DRI","DPZ","GRMN","EXPE","POOL","BBY","ULTA","KMX","DECK","RL","TPR","WHR","MHK","MAR",
    "EA","TTWO","WBD","OMC","IPG","LYV","FOXA","FOX","NWSA","MTCH","PARA","CHTR","TMUS","CMCSA","VZ","DIS",
    "INTC","TXN","QCOM","AMAT","MCHP","MPWR","ON","GLW","HPQ","HPE","DELL","WDC","STX","NTAP","KEYS","CDW",
    "TYL","FSLR","ENPH","TER","SWKS","QRVO","ZBRA","TRMB","PTC","ANSS","AKAM","JNPR","FFIV","GEN","NXPI",
    "BRK-B","SPG","DLR","O","PSA","CCI","VICI","EXR","AVB","EQR","INVH","MAA","ESS","UDR","ARE","VTR","DOC",
    "IRM","SBAC","REG","KIM","FRT","HST","CPT","BXP","AMT",
    "VMC","MLM","PPG","ALB","IFF","IP","PKG","AVY","BALL","AMCR","CF","MOS","FMC","EMN","CE","LYB","STLD","NUE",
    "DOW","DD","CTVA","APD","ECL",
    "D","VST","SRE","EXC","XEL","ED","PEG","WEC","ES","AEE","DTE","PPL","FE","CMS","CNP","ATO","NI","LNT",
    "EVRG","AES","PNW","NRG","AEP",
    "GD","NOC","FDX","UPS","CSX","ADP","EMR","TT","CMI","ROP","PAYX","BR","EXPD","CHRW","DAL","UAL","LUV",
    "TDG","GWW","JCI","PNR","ALLE","NDSN","ROK","SNA","SWK","TXT","MAS","BLDR","AXON","LHX","LDOS","J","DOV","XYL","IR",
    "AMP","TROW","BEN","IVZ","WTW","ACGL","HIG","CINF","L","NDAQ","MKTX","CBOE","FIS","FI","GPN","PYPL","SYF","DFS",
    "FITB","HBAN","RF","CFG","KEY","MTB","NTRS","STT","PFG","PGR","AFL"]
SECTOR_STOCKS = {
    "XLK":  ["AAPL","MSFT","NVDA","AVGO","ORCL","CRM","AMD","ADBE","ACN","CSCO","INTC","IBM","QCOM","NOW","TXN"],
    "XLF":  ["BRK-B","JPM","V","MA","BAC","WFC","GS","AXP","MS","SPGI","BLK","C","SCHW","CB","PGR"],
    "XLE":  ["XOM","CVX","COP","SLB","EOG","MPC","PSX","WMB","OXY","VLO","KMI","HES","DVN"],
    "XLV":  ["LLY","UNH","JNJ","ABBV","MRK","TMO","ABT","ISRG","DHR","PFE","AMGN","BMY","GILD","VRTX","CVS"],
    "XLY":  ["AMZN","TSLA","HD","MCD","BKNG","LOW","NKE","SBUX","TJX","CMG","ORLY","MAR","GM","F"],
    "XLP":  ["COST","WMT","PG","KO","PEP","PM","MDLZ","CL","MO","TGT","KMB","GIS","KHC"],
    "XLI":  ["GE","CAT","RTX","HON","UNP","BA","DE","UBER","ETN","LMT","UPS","ADP","NOC","CSX","EMR"],
    "XLB":  ["LIN","SHW","FCX","ECL","NEM","APD","CTVA","DOW","NUE","DD","VMC","MLM"],
    "XLU":  ["NEE","SO","DUK","CEG","AEP","D","VST","SRE","EXC","XEL","ED","PEG"],
    "XLRE": ["PLD","AMT","EQIX","WELL","SPG","DLR","O","PSA","CCI","CBRE","VICI","EXR"],
    "XLC":  ["META","GOOGL","NFLX","DIS","TMUS","T","VZ","CMCSA","CHTR","EA","TTWO","WBD"],
    "SMH":  ["NVDA","AVGO","AMD","QCOM","TXN","MU","LRCX","AMAT","KLAC","ADI","MRVL","NXPI"],
    "IGV":  ["MSFT","ORCL","CRM","NOW","ADBE","PANW","CRWD","INTU","SNPS","CDNS","FTNT","WDAY","DDOG","TEAM"],
    "FIW":  ["AWK","ROP","XYL","WAT","FERG","A","VLTO","PNR","MLI","IDXX","ECL","IEX","J","MAS","WMS","STN","CNM","WTS","ACM","TTEK","BMI","ITRI","FELE","MWA","ZWS"],
    "XBI":  ["VRTX","REGN","GILD","ALNY","EXEL","UTHR","INSM","NBIX","ARWR","BEAM","ALKS","TGTX","KRYS","INCY","IONS","BMRN","SRPT","HALO"],
    "KRE":  ["TFC","FITB","RF","HBAN","KEY","CFG","MTB","WBS","ZION","CMA","EWBC","WAL","SNV","FHN","CFR","CADE","ONB","PB"],
    "JETS": ["DAL","UAL","AAL","LUV","ALK","SKYW","ALGT","JBLU","BA","BKNG","EXPE","ABNB"],
    "ITB":  ["DHI","LEN","NVR","PHM","TOL","KBH","MTH","TMHC","BLDR","SHW","MAS","LOW","HD","MHK"],
    "ITA":  ["RTX","BA","LMT","GD","NOC","GE","TDG","LHX","HWM","AXON","HEI","TXT","CW","HII","LDOS"],
}
FRED_API_KEY = ""                                # DEJAR VACIO: la key va en los Secrets de GitHub (FRED_API_KEY), NO aqui (repo publico)
ISM_MANUAL = 54.0                                # ISM manufacturas (no esta limpio en FRED gratis): actualizalo a mano el 1er dia habil de cada mes. Ult.: 54.0 (mayo-2026)
# --- Analisis con IA (opcional): comentario automatico en el panel ---
ANTHROPIC_API_KEY = ""                           # opcional: https://console.anthropic.com (de pago por uso)
AI_MODEL = "claude-haiku-4-5"                    # modelo a usar (editable segun tu cuenta)
# --- Avisos automaticos (opcional). Rellena uno de los dos ---
TELEGRAM_TOKEN = ""                              # token del bot de Telegram (via @BotFather)
TELEGRAM_CHAT_ID = ""                            # tu chat id (via @userinfobot)
WEBHOOK_URL = ""                                 # alternativa: webhook de Discord/Slack
# (en GitHub se pueden poner como Secrets; ver README)
BACKTEST = True                                  # calcular el backtest de la estrategia
# --- Optimizaciones de la estrategia ---
TREND_FILTER = True                              # solo invertir si el S&P > su media de 40 semanas (~200d); si no, liquidez
TREND_MA_WEEKS = 40                              # media para el filtro de tendencia del mercado
MAX_POSICIONES = 5                               # tope de posiciones (las N de mayor impulso); 0 = sin tope -> prioriza los subsectores fuertes
PESO = "volatilidad"                             # reparto: "igual" | "volatilidad" (inversa, mas a lo estable) | "impulso"
BUFFER = 1.0                                     # histeresis: entra si fuerza>100+BUFFER y sale si <100-BUFFER (menos latigazos)
# --- Plan de liquidez / entrada escalonada (guia: caidas del S&P 500 desde maximos) ---
CASH_PLAN = [(5, 30), (10, 30), (20, 40)]        # (caida % desde maximo, % de cartera a desplegar)
DD_THRESHOLDS = [2.5, 5, 10, 20]                 # umbrales para la tabla de caidas
CARTERA_CAPITAL = 1000                           # € a repartir en la "cartera de la semana" (Lider+Mejorando)
CARTERA_DUAL_MOMENTUM = True                     # la cartera exige tambien momentum ABSOLUTO positivo (no entra en lo que sube vs S&P pero pierde dinero)
CARTERA_SCORE_MIN = 3                            # la cartera no entra en ETFs con scoring < este valor (0 = desactivado). 3 = fuera solo los "evitar" (<=2); 4 = solo "comprar" (estricto, muy concentrado). La distribución oculta SIEMPRE se excluye aparte.

# === TU CARTERA REAL (para el "Plan de rotacion de mi cartera") ===
# Cada linea: ("TICKER", "BROKER", importe_en_euros). Acepta ETFs (XLF), acciones (MS), apalancados (TQQQ, SOXL) y los de Europa (EWG, EWP).
# Si dejas la lista vacia, el panel no aparece. Pegame capturas de XTB/Robinhood/DEGIRO y te las convierto a estas lineas.
MI_CARTERA = [
    # ("XLF",  "XTB",       1500),
    # ("TQQQ", "Robinhood", 1200),
    # ("EWP",  "DEGIRO",     800),
    # ("MS",   "Robinhood",  600),
]
MEAN_REVERSION = True                            # calcula la rentabilidad media anual (10a) y la del año (YTD) de cada ETF -> panel "margen vs su media" (descarga ~10a por ETF, algo mas lento; pon False para desactivar)
# Vehiculos apalancados x3 por activo (informativo; MUY arriesgados, ver avisos)
LEV3X = {"SPY":"SPXL/UPRO", "QQQ":"TQQQ", "MAGS":"TQQQ", "XLK":"TECL", "XLF":"FAS",
         "XLE":"ERX", "XLV":"CURE", "XLI":"DUSL", "XLB":"—", "XLU":"UTSL", "XLRE":"DRN",
         "XLY":"WANT", "XLP":"—", "XLC":"—", "IWM":"TNA", "FXI":"YINN", "EEM":"EDC",
         "ITA":"DFEN", "GLD":"—", "TLT":"TMF", "SMH":"SOXL", "KRE":"DPST", "XBI":"LABU",
         "GDX":"NUGT", "JETS":"—", "IGV":"TECL*", "SOXX":"SOXL", "ITB":"NAIL", "KWEB":"CWEB*"}
# Empresa lider (mayor posicion) de cada ETF — ORIENTATIVO, cambia con el tiempo
TOP_HOLDING = {
    "XLK":"NVDA / MSFT / AAPL", "XLF":"BRK.B / JPM", "XLE":"XOM / CVX", "XLV":"LLY / UNH",
    "XLY":"AMZN / TSLA", "XLP":"COST / WMT", "XLI":"GE / CAT", "XLB":"LIN / SHW",
    "XLU":"NEE / SO", "XLRE":"PLD / AMT", "XLC":"META / GOOGL", "IWM":"muy diversificado",
    "MAGS":"los 7 (AAPL,MSFT,NVDA...)", "FXI":"BABA / Tencent", "EEM":"TSM / Tencent",
    "ITA":"GE Aero / RTX / BA", "JETS":"aerolineas + BKNG", "SMH":"NVDA / TSM / AVGO",
    "KRE":"banca regional (div.)", "XBI":"biotech equiponderado", "GDX":"NEM / AEM",
    "IGV":"MSFT / CRM / ORCL",
    "SOXX":"NVDA / AVGO / AMD", "ITB":"DHI / LEN / NVR", "KWEB":"BABA / Tencent / PDD",
    "EWG":"SAP / Siemens / Allianz", "EWP":"Iberdrola / Inditex / Santander",
    "COPX":"Freeport / Antofagasta / Ivanhoe", "URA":"Cameco / Kazatomprom / NexGen", "LIT":"Albemarle / SQM / Ganfeng",
    "GRID":"Eaton / Quanta / GE Vernova", "PAVE":"Eaton / Trane / Quanta",
    "FIW":"Ferguson / Xylem / Veralto", "CGW":"American Water / Veolia / Xylem",
    "HYDR":"Plug Power / Bloom / ITM Power",
}
SITE_DIR = "site"                                # carpeta que publica GitHub Pages
STATIC_DIR = "static"                            # iconos, manifest, service worker
OUTPUT_HTML = os.path.join(SITE_DIR, "index.html")
CACHE_DIR = "cache_rotacion"
# ----------------------------------------------------------------------

NAMES = {
    "SPY":("S&P 500","Indice (referencia)","bench"),
    "XLK":("Technology","Tecnologia","ciclico"),
    "XLF":("Financials","Financiero","ciclico"),
    "XLE":("Energy","Energia","sensible"),
    "XLV":("Health Care","Salud","defensivo"),
    "XLY":("Cons. Discretionary","Consumo discrecional","ciclico"),
    "XLP":("Cons. Staples","Consumo basico","defensivo"),
    "XLI":("Industrials","Industrial","ciclico"),
    "XLB":("Materials","Materiales","sensible"),
    "XLU":("Utilities","Servicios publicos","defensivo"),
    "XLRE":("Real Estate","Inmobiliario","sensible"),
    "XLC":("Comm. Services","Comunicaciones","ciclico"),
    "IWM":("Russell 2000","Small caps","ciclico"),
    "TLT":("20Y Treasuries","Bonos largos","defensivo"),
    "GLD":("Gold","Oro","defensivo"),
    "HYG":("High Yield","Credito HY","ciclico"),
    "UUP":("US Dollar","Dolar","macro"),
    "FXI":("China Large-Cap","China","ciclico"),
    "EEM":("Emerging Markets","Emergentes","ciclico"),
    "ITA":("Aerospace & Defense","Espacio y defensa","ciclico"),
    "MAGS":("Magnificent 7","7 Magnificos","ciclico"),
    "JETS":("Airlines / Travel","Viajes y aerolineas","ciclico"),
    "SMH":("Semiconductors","Semiconductores","ciclico"),
    "KRE":("Regional Banks","Banca regional","ciclico"),
    "XBI":("Biotech","Biotecnologia","ciclico"),
    "GDX":("Gold Miners","Mineras de oro","sensible"),
    "IGV":("Software","Software","ciclico"),
    "SOXX":("Semiconductors (iShares)","Semis (iShares)","ciclico"),
    "ITB":("Home Construction","Construccion / vivienda","ciclico"),
    "KWEB":("China Internet","China tecnologica","ciclico"),
    "EWG":("Germany (DAX proxy)","Alemania / DAX","ciclico"),
    "EWP":("Spain (IBEX proxy)","España / IBEX 35","ciclico"),
    "COPX":("Copper Miners","Cobre (mineras)","ciclico"),
    "URA":("Uranium","Uranio","ciclico"),
    "LIT":("Lithium & Battery","Litio y baterías","ciclico"),
    "GRID":("Smart Grid Infra","Red eléctrica (IA)","ciclico"),
    "PAVE":("US Infrastructure","Infraestructura EE.UU. (IA)","ciclico"),
    "FIW":("US Water","Agua EE.UU. (IA)","ciclico"),
    "CGW":("Global Water","Agua global (IA)","ciclico"),
    "HYDR":("Global Hydrogen","Hidrógeno (IA/energía)","ciclico"),
    "EURUSD":("Euro / Dolar","EUR/USD","macro"),
}
QUAD = {
    "leading":  ("Lider","#2FD08A","Liderazgo confirmado"),
    "weakening":("Debilitandose","#F4B740","Riesgo de recogida de beneficios"),
    "lagging":  ("Rezagado","#F4607A","Evitar / infraponderar"),
    "improving":("Mejorando","#4CC2E0","Acumulacion temprana"),
}

# ----------------------------------------------------------------------
# Bootstrap de dependencias
# ----------------------------------------------------------------------
def ensure(pkg, imp=None, optional=False):
    try:
        return importlib.import_module(imp or pkg)
    except ImportError:
        print(f"  Instalando {pkg} ...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", pkg])
            return importlib.import_module(imp or pkg)
        except Exception as e:
            if optional:
                print(f"  (Aviso) No se pudo instalar {pkg}: {e}")
                return None
            raise

print("Preparando librerias...")
pd = ensure("pandas")
yf = ensure("yfinance", optional=True)
requests = ensure("requests")
import pandas as pd  # noqa
from io import StringIO

# ----------------------------------------------------------------------
# Descarga de datos (Stooq -> Yahoo -> cache)
# ----------------------------------------------------------------------
def fetch_stooq(sym, start, end):
    """Descarga OHLCV diario directamente de Stooq (sin libreria intermedia)."""
    url = f"https://stooq.com/q/d/l/?s={sym.lower()}.us&i=d"
    try:
        r = requests.get(url, timeout=20, headers={"User-Agent": "Mozilla/5.0"})
        txt = r.text
        if not txt or "Close" not in txt.splitlines()[0]:
            return None
        df = pd.read_csv(StringIO(txt))
        if "Date" not in df.columns or "Close" not in df.columns or len(df) < 30:
            return None
        df["Date"] = pd.to_datetime(df["Date"])
        df = df.set_index("Date").sort_index()
        cols = [c for c in ["Open", "High", "Low", "Close", "Volume"] if c in df.columns]
        out = df[cols].copy()
        return out[out.index >= pd.Timestamp(start)]
    except Exception:
        return None

def fetch_yahoo(sym, start, end):
    if yf is None:
        return None
    try:
        df = yf.download(sym, start=start, end=end + dt.timedelta(days=1), interval="1d",
                         progress=False, auto_adjust=True)
        if df is None or len(df) < 30:
            return None
        if hasattr(df.columns, "nlevels") and df.columns.nlevels > 1:
            df.columns = df.columns.get_level_values(0)
        cols = [c for c in ["Open", "High", "Low", "Close", "Volume"] if c in df.columns]
        return df[cols].sort_index()
    except Exception:
        return None

def cache_path(sym):
    return os.path.join(CACHE_DIR, f"{sym}.csv")

def save_cache(sym, dframe):
    os.makedirs(CACHE_DIR, exist_ok=True)
    dframe.to_csv(cache_path(sym))

def load_cache(sym):
    p = cache_path(sym)
    if os.path.exists(p):
        try:
            return pd.read_csv(p, index_col=0, parse_dates=True).sort_index()
        except Exception:
            return None
    return None

# El seguimiento NO va en la cache (la cache es desechable y se borra para liberar espacio o forzar datos frescos).
# Va en su propia carpeta, con nombre de "no me borres", y se hace copia de seguridad en cada guardado.
SEGUIMIENTO_DIR = "historico_seguimiento_NO_BORRAR"
TRACK_FILE = os.path.join(SEGUIMIENTO_DIR, "track_record.json")
TRACK_BAK = os.path.join(SEGUIMIENTO_DIR, "track_record.bak.json")
_OLD_TRACK = os.path.join(CACHE_DIR, "track_record.json")          # ubicacion antigua (dentro de la cache)
try:
    # migracion: si tienes histórico en la cache vieja y aun no en la nueva, lo traslado para no perderlo
    if os.path.exists(_OLD_TRACK) and not os.path.exists(TRACK_FILE):
        os.makedirs(SEGUIMIENTO_DIR, exist_ok=True)
        import shutil as _sh
        _sh.copy2(_OLD_TRACK, TRACK_FILE)
except Exception:
    pass

def update_track_record(basket, px_now, datestr):
    # Guarda un snapshot por semana ISO {week, date, basket, px:{ticker:cierre}} y devuelve el historico ordenado.
    # px_now debe incluir los tickers del basket + SPY/QQQ/IWM. Asi cada semana puede valorar la cesta de la anterior.
    os.makedirs(SEGUIMIENTO_DIR, exist_ok=True)
    recs = []
    if os.path.exists(TRACK_FILE):
        try:
            with open(TRACK_FILE, "r", encoding="utf-8") as fh:
                recs = json.load(fh)
        except Exception:
            # si el principal está corrupto, intento recuperar desde la copia de seguridad
            try:
                with open(TRACK_BAK, "r", encoding="utf-8") as fh:
                    recs = json.load(fh)
            except Exception:
                recs = []
    try:
        wk = pd.Timestamp(datestr).strftime("%G-W%V")          # año-semana ISO
    except Exception:
        wk = str(datestr)
    px_clean = {k: float(v) for k, v in px_now.items() if v is not None and v == v}
    snap = {"week": wk, "date": str(datestr), "basket": list(basket), "px": px_clean}
    recs = [r for r in recs if r.get("week") != wk]            # dedup: una por semana (actualiza si se repite)
    recs.append(snap)
    recs.sort(key=lambda r: r.get("week", ""))
    try:
        with open(TRACK_FILE, "w", encoding="utf-8") as fh:
            json.dump(recs, fh, ensure_ascii=False, indent=0)
        with open(TRACK_BAK, "w", encoding="utf-8") as fh:        # copia de seguridad
            json.dump(recs, fh, ensure_ascii=False, indent=0)
    except Exception:
        pass
    return recs

def compute_track_perf(recs, benches=("SPY", "QQQ", "IWM"), ew_universe=None):
    # A partir de los snapshots, retorno semanal de la cesta del sistema (equiponderada) vs benchmarks
    # y vs una cesta de TODOS los sectores equiponderada (ew_universe), y acumulado encadenado.
    if not recs or len(recs) < 2:
        return None
    ew_universe = list(ew_universe) if ew_universe else list(SECTORS)
    weeks = []
    cum = {"sys": 1.0, "ew": 1.0}
    for b in benches:
        cum[b] = 1.0
    for i in range(len(recs) - 1):
        a, b = recs[i], recs[i + 1]
        pxa, pxb = a.get("px", {}), b.get("px", {})
        bk = [t for t in a.get("basket", []) if t in pxa and t in pxb and pxa[t]]
        if not bk:
            continue
        sysret = sum((pxb[t] / pxa[t] - 1.0) for t in bk) / len(bk)
        row = {"week": b["week"], "date": b["date"], "basket": a.get("basket", []), "sys": sysret, "bench": {}}
        cum["sys"] *= (1.0 + sysret)
        row["cum_sys"] = cum["sys"] - 1.0
        # cesta de TODOS los sectores equiponderada (referencia: ¿la selección bate a tenerlo todo por igual?)
        ewbk = [t for t in ew_universe if t in pxa and t in pxb and pxa[t]]
        if ewbk:
            ewret = sum((pxb[t] / pxa[t] - 1.0) for t in ewbk) / len(ewbk)
            row["ew"] = ewret
            cum["ew"] *= (1.0 + ewret)
        else:
            row["ew"] = None
        row["cum_ew"] = cum["ew"] - 1.0
        for bm in benches:
            if bm in pxa and bm in pxb and pxa[bm]:
                r = pxb[bm] / pxa[bm] - 1.0
                row["bench"][bm] = r
                cum[bm] *= (1.0 + r)
            row[f"cum_{bm}"] = cum[bm] - 1.0
        weeks.append(row)
    if not weeks:
        return None
    return {"weeks": weeks, "cum": {k: cum[k] - 1.0 for k in cum},
            "pending": {"week": recs[-1]["week"], "date": recs[-1]["date"], "basket": recs[-1].get("basket", [])},
            "n": len(weeks)}

def topup_recent(sym, d, end):
    # rellena con Yahoo las barras mas recientes que Stooq aun no tenga (frescura del ultimo dia).
    # devuelve (dataframe, n_barras_anyadidas)
    if not TOPUP_YAHOO or yf is None or d is None or d.empty:
        return d, 0
    try:
        last = d.index[-1]
        y = yf.download(sym, start=(last - dt.timedelta(days=4)),
                        end=end + dt.timedelta(days=1), interval="1d",
                        progress=False, auto_adjust=True)
        if y is None or y.empty:
            return d, 0
        if hasattr(y.columns, "nlevels") and y.columns.nlevels > 1:
            y.columns = y.columns.get_level_values(0)
        cols = [c for c in ["Open", "High", "Low", "Close", "Volume"] if c in y.columns]
        newer = y[cols][y.index > last]
        if newer.empty:
            return d, 0
        d = pd.concat([d, newer]).sort_index()
        d = d[~d.index.duplicated(keep="last")]
        return d, len(newer)
    except Exception:
        return d, 0

def get_ohlcv(sym, start, end):
    pairs = ([(fetch_yahoo, "yahoo"), (fetch_stooq, "stooq")] if DATA_PRIMARY == "yahoo"
             else [(fetch_stooq, "stooq"), (fetch_yahoo, "yahoo")])
    for fn, nm in pairs:
        d = fn(sym, start, end)
        if d is not None and len(d) >= 30:
            save_cache(sym, d)
            return d, nm
    c = load_cache(sym)
    if c is not None:
        return c, "cache"
    return None, "—"

def to_weekly_close(series):
    # ultimo cierre de cada semana, conservando la FECHA REAL (no el viernes teorico).
    s = series.dropna()
    if s.empty:
        return s
    return s.groupby(s.index.to_period("W")).tail(1)

def download_all():
    end = dt.date.today()
    start = end - dt.timedelta(days=int(WEEKS * 7 * 1.6) + 60)
    symbols = [BENCH] + SECTORS + SATELLITES + THEMATIC + EXTRA
    weekly = {}
    daily = {}
    sources = {}
    print(f"\nDescargando {len(symbols)} simbolos (OHLCV diario)...")
    for sym in symbols:
        d, src = get_ohlcv(sym, start, end)
        if d is None or "Close" not in d.columns:
            print(f"  {sym:5s}  sin datos")
            sources[sym] = "—"
            continue
        if src == "stooq":   # intentar refrescar el ultimo dia con Yahoo
            d, added = topup_recent(sym, d, end)
            if added:
                src = "stooq+yf"
                save_cache(sym, d)
        daily[sym] = d
        weekly[sym] = to_weekly_close(d["Close"])
        sources[sym] = src
        print(f"  {sym:5s}  {src:9s}  {len(weekly[sym])} semanas  ult {weekly[sym].index[-1].date()}")
        time.sleep(0.25)   # cortesia con la fuente
    # alinear: union de fechas + ffill para que un solo simbolo rezagado no arrastre a todos
    df = pd.DataFrame(weekly).sort_index()
    if df.shape[1] > 0:
        min_obs = max(30, int(0.7 * df.shape[0]))
        df = df.dropna(axis=1, thresh=min_obs)
    df = df.ffill().dropna()
    if len(df) > WEEKS:
        df = df.iloc[-WEEKS:]
    used = [v for v in sources.values() if v not in ("—",)]
    if used and not any("stooq" in v for v in used):
        print("  AVISO: Stooq no respondio en ninguna descarga (probable LIMITE DIARIO de Stooq por su IP, "
              "agravado por el universo de ~500 acciones). Se ha usado Yahoo. El cupo se restablece al dia siguiente; "
              "puedes bajar RS_UNIVERSE a 'sector' o poner DATA_PRIMARY='yahoo'.")
    return df, daily, sources

# ----------------------------------------------------------------------
# Motor RRG
# ----------------------------------------------------------------------
def rolling_z(s, win):
    m = s.rolling(win).mean()
    sd = s.rolling(win).std(ddof=0).replace(0, 1e-9)
    return (s - m) / sd

def compute_rrg(df):
    bench = df[BENCH]
    n = len(df)
    smooth_span = max(4, min(10, n // 6))
    z_win = max(8, min(26, n // 2))
    mom_span = max(4, min(10, n // 7))
    z_win2 = max(6, min(20, n // 3))
    SCALE = 2.4
    out = {}
    for sym in df.columns:
        if sym == BENCH:
            continue
        rs = df[sym] / bench
        smooth = rs.ewm(span=smooth_span).mean()
        ratio = (100 + SCALE * rolling_z(smooth, z_win)).clip(86, 114)
        mom_in = ratio - ratio.ewm(span=mom_span).mean()
        mom = (100 + SCALE * rolling_z(mom_in, z_win2)).clip(86, 114)
        d = pd.DataFrame({"ratio": ratio, "mom": mom}).dropna()
        if len(d) < 2:
            continue
        tail = d.iloc[-TAIL:]
        tail_dates = [ix.strftime("%d %b") for ix in tail.index]
        last = d.iloc[-1]; prev = d.iloc[-2]
        sma20 = df[sym].rolling(min(20, n - 1)).mean().iloc[-1]
        spark = rs.iloc[-min(24, len(rs)):].tolist()
        rel1 = float(rs.iloc[-1] / rs.iloc[-2] - 1) * 100 if len(rs) >= 2 else 0.0
        rel4 = float(rs.iloc[-1] / rs.iloc[-5] - 1) * 100 if len(rs) >= 5 else 0.0
        out[sym] = {
            "ratio": float(last["ratio"]), "mom": float(last["mom"]),
            "dmom": float(last["mom"] - prev["mom"]),
            "quad": quad_of(last["ratio"], last["mom"]),
            "pquad": quad_of(prev["ratio"], prev["mom"]),
            "tail": [[float(r.ratio), float(r.mom)] for r in tail.itertuples()],
            "tail_dates": tail_dates,
            "trend": bool(df[sym].iloc[-1] > sma20),
            "group": NAMES.get(sym, ("", "", ""))[2],
            "spark": [float(x) for x in spark],
            "rel1": round(rel1, 1), "rel4": round(rel4, 1),
            "ratio_series": ratio.reindex(df.index).tolist(),   # alineadas al indice (None al inicio)
            "mom_series": mom.reindex(df.index).tolist(),
        }
    return out

def quad_of(ratio, mom):
    if ratio >= 100 and mom >= 100: return "leading"
    if ratio >= 100 and mom < 100:  return "weakening"
    if ratio < 100 and mom < 100:   return "lagging"
    return "improving"

def build_alerts(rrg):
    out = []
    for s, d in rrg.items():
        q, p = d["quad"], d["pquad"]
        if q == "weakening" and p == "leading":
            out.append((s, "warn", "Pierde liderazgo -> posible recogida de beneficios. Ajusta stop / reduce."))
        elif q == "improving" and p == "lagging":
            out.append((s, "in", "Entra flujo -> acumulacion temprana. Vigilar para sobreponderar."))
        elif q == "leading" and p == "improving":
            out.append((s, "lead", "Liderazgo confirmado -> tendencia relativa al alza."))
        elif q == "lagging" and p == "weakening":
            out.append((s, "down", "Ruptura a la baja -> infraponderar / evitar."))
        elif q == "leading" and d["dmom"] < -1.2:
            out.append((s, "warn", "Impulso enfriandose dentro del liderazgo -> primera senal de aviso."))
    order = {"warn": 0, "in": 1, "down": 2, "lead": 3}
    return sorted(out, key=lambda x: order[x[1]])

def breadth_risk(rrg):
    syms = list(rrg.keys())
    if not syms:
        return {"leaders": 0, "uptrend": 0}, {"score": 0, "label": "Neutral"}
    leaders = round(100 * sum(1 for s in syms if rrg[s]["ratio"] >= 100) / len(syms))
    uptrend = round(100 * sum(1 for s in syms if rrg[s]["trend"]) / len(syms))
    off = [rrg[s]["ratio"] for s in syms if rrg[s]["group"] in ("ciclico", "sensible")]
    deff = [rrg[s]["ratio"] for s in syms if rrg[s]["group"] == "defensivo"]
    avg = lambda a: sum(a) / len(a) if a else 100
    score = avg(off) - avg(deff)
    label = "Risk-ON" if score > 1.5 else "Risk-OFF" if score < -1.5 else "Neutral"
    return {"leaders": leaders, "uptrend": uptrend}, {"score": round(score, 1), "label": label}

# ----------------------------------------------------------------------
# Flujo de dinero por volumen (OBV + Acumulacion/Distribucion)
# ----------------------------------------------------------------------
import numpy as np

def _trend(values, win=20):
    """Tendencia de una serie: cuantas desv. tipicas se mueve a lo largo de la ventana."""
    y = pd.Series(values).dropna().values
    if len(y) < 5:
        return 0.0
    y = y[-win:]
    sd = y.std() or 1.0
    z = (y - y.mean()) / sd
    x = np.arange(len(z))
    b = np.polyfit(x, z, 1)[0]
    return float(b * len(z))

def compute_volume_flow(daily, only=None):
    out = {}
    for sym, d in daily.items():
        if only is not None:
            if sym != only:
                continue
        elif sym == BENCH:
            continue
        if not {"Close", "Volume"}.issubset(d.columns):
            continue
        dd = d.dropna(subset=["Close", "Volume"]).copy()
        if len(dd) < 30:
            continue
        close = dd["Close"]; vol = dd["Volume"].astype(float)
        obv = (np.sign(close.diff().fillna(0)) * vol).cumsum()
        cmf = 0.0
        if {"High", "Low"}.issubset(dd.columns):
            hi, lo = dd["High"], dd["Low"]
            rng = (hi - lo).replace(0, np.nan)
            mfm = (((close - lo) - (hi - close)) / rng).fillna(0)
            mfv = mfm * vol
            adl = mfv.cumsum()
            win = min(20, len(dd))                      # CMF de 20 sesiones (Chaikin Money Flow)
            vsum = vol.iloc[-win:].sum()
            cmf = float(mfv.iloc[-win:].sum() / vsum) if vsum else 0.0
        else:
            adl = obv
        # OBV vs su propia media (EMA ~50 sesiones = 10 semanas): tendencia y cruce reciente
        obv_ema = obv.ewm(span=50, min_periods=10).mean()
        obv_above = bool(obv.iloc[-1] > obv_ema.iloc[-1]) if obv_ema.notna().any() else False
        obv_cross = False
        if len(obv) > 7 and obv_ema.notna().iloc[-7]:
            obv_cross = bool(obv.iloc[-1] > obv_ema.iloc[-1] and obv.iloc[-7] <= obv_ema.iloc[-7])
        obv_t, adl_t, price_t = _trend(obv), _trend(adl), _trend(close)
        flow = (obv_t + adl_t) / 2
        # volumen relativo: volumen de hoy vs su media de 20 sesiones (>1.3x = ruptura con volumen)
        vol20 = float(vol.iloc[-20:].mean()) if len(vol) >= 20 else float(vol.mean())
        vol_rel = round(float(vol.iloc[-1]) / vol20, 2) if vol20 > 0 else 1.0
        vol_break = bool(vol_rel >= 1.3 and close.iloc[-1] > close.iloc[-2])   # ruptura al alza con volumen
        diverg = None
        if price_t > 0.5 and flow < -0.5:
            diverg = "distribucion oculta"   # precio sube pero sale dinero -> aviso
        elif price_t < -0.5 and flow > 0.5:
            diverg = "acumulacion oculta"     # precio baja pero entra dinero -> temprano
        label = "Acumulacion" if flow > 0.5 else "Distribucion" if flow < -0.5 else "Neutro"
        out[sym] = {"flow": round(flow, 2), "label": label, "diverg": diverg,
                    "cmf": round(cmf, 3), "cmf_pos": bool(cmf > 0),
                    "obv_above": obv_above, "obv_cross": obv_cross,
                    "vol_rel": vol_rel, "vol_break": vol_break,
                    "obv_spark": obv.iloc[-min(40, len(obv)):].tolist()}
    return out

# ----------------------------------------------------------------------
# Heatmap de fuerza relativa temporal (sector vs indice en varios plazos)
# ----------------------------------------------------------------------
def compute_heatmap(daily):
    # Para cada ETF: su rendimiento MENOS el del indice en 1 sem / 1 mes / 3 meses / 6 meses.
    # Verde = bate al mercado; rojo = lo hace peor. Rojo largo + verde corto = rotacion temprana.
    if BENCH not in daily:
        return None
    bench = daily[BENCH]["Close"].dropna()
    wins = [("1 sem", 5), ("1 mes", 21), ("3 meses", 63), ("6 meses", 126)]

    def ret(s, n):
        s = s.dropna()
        if len(s) <= n:
            return None
        return float(s.iloc[-1] / s.iloc[-1 - n] - 1)

    rows = []
    for sym in SECTORS + THEMATIC + EXTRA:
        if sym not in daily or "Close" not in daily[sym]:
            continue
        s = daily[sym]["Close"]
        vals = []
        for _, n in wins:
            r, b = ret(s, n), ret(bench, n)
            vals.append(None if (r is None or b is None) else round((r - b) * 100, 1))
        short_pos = any(v is not None and v > 0 for v in vals[:2])
        long_neg = any(v is not None for v in vals[2:]) and all((v is None or v < 0) for v in vals[2:])
        rows.append({"sym": sym, "vals": vals, "turning": short_pos and long_neg})
    rows.sort(key=lambda r: (not r["turning"], -(r["vals"][1] if r["vals"][1] is not None else -999)))
    return {"cols": [w[0] for w in wins], "rows": rows}

def compute_probabilities(df, rrg, fwd=4):
    # Base historica honesta: para cada ETF y semana, cuenta cuantas senales ESTRUCTURALES
    # cumplia (0-3: precio>media40, RS-momentum>=100, momentum absoluto 3m>0) y mira el
    # retorno a 'fwd' semanas vista. Agrega: % de veces que subio y retorno medio por nivel.
    buckets = {0: [], 1: [], 2: [], 3: []}
    for sym in [c for c in df.columns if c in rrg]:
        s = df[sym]
        if len(s) < 40 + fwd:
            continue
        sma = s.rolling(40).mean()
        abs13 = s / s.shift(13) - 1
        mser = pd.Series(rrg[sym]["mom_series"], index=df.index)
        fwd_ret = s.shift(-fwd) / s - 1
        for i in range(40, len(s) - fwd):
            if pd.isna(sma.iloc[i]) or pd.isna(abs13.iloc[i]) or pd.isna(fwd_ret.iloc[i]):
                continue
            m = mser.iloc[i]
            if m is None or m != m:
                continue
            sc = int(s.iloc[i] > sma.iloc[i]) + int(m >= 100) + int(abs13.iloc[i] > 0)
            buckets[sc].append(float(fwd_ret.iloc[i]))
    stats = {}
    for sc, rets in buckets.items():
        if rets:
            n = len(rets)
            stats[sc] = {"n": n, "pup": round(100 * sum(1 for r in rets if r > 0) / n),
                         "avg": round(100 * sum(rets) / n, 1)}
        else:
            stats[sc] = {"n": 0, "pup": None, "avg": None}
    return {"stats": stats, "fwd": fwd, "weeks": len(df)}

def compute_mean_reversion(symbols):
    # Rentabilidad media anual (CAGR ~10a) vs lo que lleva en el año (YTD). Contexto de extension, NO senal.
    if not MEAN_REVERSION:
        return {}
    out = {}
    start = dt.date.today() - dt.timedelta(days=365 * 11)
    y0 = pd.Timestamp(dt.date(dt.date.today().year, 1, 1))
    for sym in symbols:
        try:
            d, _ = get_ohlcv(sym, start, dt.date.today())
            if d is None or "Close" not in d.columns:
                continue
            c = d["Close"].dropna()
            if len(c) < 250:
                continue
            yrs = (c.index[-1] - c.index[0]).days / 365.25
            if yrs < 1.5:
                continue
            cagr = ((c.iloc[-1] / c.iloc[0]) ** (1.0 / yrs) - 1.0) * 100
            cy = c[c.index >= y0]
            ytd = ((c.iloc[-1] / cy.iloc[0] - 1.0) * 100) if len(cy) > 1 else None
            out[sym] = {"cagr": round(float(cagr), 1),
                        "ytd": round(float(ytd), 1) if ytd is not None else None,
                        "yrs": round(yrs, 1),
                        "margen": round(float(cagr - ytd), 1) if ytd is not None else None}
        except Exception:
            continue
    return out

def compute_early(df, rrg):
    # Zona de ENTRADA TEMPRANA: impulso girándose al alza pero AÚN SIN EXTENDER.
    # Pilla el principio del movimiento (abajo-izquierda del RRG que empieza a curvarse),
    # antes de que sea un líder caro. Filtros: impulso acelerando, fuerza baja, poco estirado.
    rows = []
    for sym in SECTORS + THEMATIC + EXTRA:
        if sym not in df.columns or sym not in rrg:
            continue
        s = df[sym].dropna()
        if len(s) < 16:
            continue
        sma = s.rolling(min(40, len(s))).mean().iloc[-1]
        ext = float(s.iloc[-1] / sma - 1) * 100               # extensión sobre su media de 40s (%)
        ratio = float(rrg[sym]["ratio"]); mom = float(rrg[sym]["mom"])
        mser = [x for x in rrg[sym].get("mom_series", []) if x is not None]
        accel = float(mser[-1] - mser[-5]) if len(mser) >= 5 else 0.0   # aceleración del impulso (4 sem)
        early = (accel > 0) and (mom >= 99) and (ratio <= 101) and (ext <= 6)
        if early:
            score = accel * 1.0 + max(0.0, 101 - ratio) * 0.5 + max(0.0, 6 - ext) * 0.3
            rows.append({"sym": sym, "ratio": round(ratio, 1), "mom": round(mom, 1),
                         "accel": round(accel, 1), "ext": round(ext, 1),
                         "quad": rrg[sym]["quad"], "score": score})
    rows.sort(key=lambda r: -r["score"])
    return rows

def compute_mi_cartera_plan(holdings, rrg, scores, flow, chosen):
    # Compara TU cartera real con las señales y da acciones concretas por posicion.
    if not holdings:
        return None
    universe = set(SECTORS + THEMATIC + EXTRA + SATELLITES)
    # acciones -> su ETF de sector
    stock2etf = {}
    for etf, sts in SECTOR_STOCKS.items():
        for st in sts:
            stock2etf.setdefault(st.upper(), etf)
    # apalancados -> su subyacente (prefiriendo lo que seguimos)
    lev2base = {}
    for base, lev in LEV3X.items():
        for l in lev.replace("*", "").split("/"):
            l = l.strip().upper()
            if l and (l not in lev2base or base in universe):
                lev2base[l] = base

    def resolve(t):
        t = t.upper()
        if t in universe:
            return t, "ETF"
        if t in lev2base:
            return lev2base[t], "apalancado"
        if t in stock2etf:
            return stock2etf[t], "acción"
        return None, "no seguido"

    sc_map = {r["sym"]: r for r in scores} if scores else {}
    rows = []
    held_bases = set()
    for tk, broker, eur in holdings:
        base, kind = resolve(tk)
        if base is None or base not in rrg:
            rows.append({"tk": tk, "broker": broker, "eur": eur, "base": None, "kind": kind,
                         "act": "no seguido", "col": "#5E708A",
                         "why": "no está en el universo del panel; el tool no puede evaluarlo."})
            continue
        held_bases.add(base)
        quad = rrg[base]["quad"]
        sc = sc_map.get(base, {}).get("score")
        distrib = sc_map.get(base, {}).get("distrib", False)
        qn = QUAD.get(quad, (quad, "#888"))[0]
        if distrib:
            act, col, why = "VENDER / ROTAR", "#F4607A", f"distribución oculta (sale dinero) en {base}."
        elif quad == "lagging" or (sc is not None and sc <= 2):
            act, col, why = "VENDER / ROTAR", "#F4607A", f"{base} en {qn}" + (f", scoring {sc}/5" if sc is not None else "") + " → fuera."
        elif quad == "weakening":
            act, col, why = "REDUCIR / VIGILAR", "#F4B740", f"{base} en {qn}: impulso girándose, recoger beneficios / poner stop."
        elif quad in ("leading", "improving") and (sc is None or sc >= 3):
            act, col, why = "MANTENER", "#2FD08A", f"{base} en {qn}" + (f", scoring {sc}/5" if sc is not None else "") + ": sigue fuerte."
        else:
            act, col, why = "VIGILAR", "#9FB0C8", f"{base} en {qn}, scoring {sc}/5."
        via = "" if (base == tk.upper()) else f" (vía {base})"
        rows.append({"tk": tk, "broker": broker, "eur": eur, "base": base, "kind": kind,
                     "act": act, "col": col, "why": why, "quad": qn, "sc": sc, "via": via})
    # ROTAR HACIA: lo que recomienda la cartera y aún no tienes
    rec = []
    for s, d in (chosen or []):
        if s not in held_bases:
            sc = sc_map.get(s, {}).get("score")
            rec.append({"sym": s, "quad": QUAD.get(d["quad"], (d["quad"], "#888"))[0], "sc": sc})
    total = sum(eur for _, _, eur in holdings if isinstance(eur, (int, float)))
    return {"rows": rows, "rotar_hacia": rec, "total": total,
            "n_vender": sum(1 for r in rows if r["act"].startswith("VENDER")),
            "n_mantener": sum(1 for r in rows if r["act"] == "MANTENER")}

def compute_scores(df, rrg, daily, flow):
    # Puntuacion 0-5 por ETF (deliverable para decidir en 5 min):
    #  +1 precio > su SMA de 40 semanas | +1 RS-momentum subiendo (vs SPY)
    #  +1 momentum absoluto 3m > 0 | +1 OBV por encima de su media | +1 CMF > 0
    rows = []
    for sym in SECTORS + THEMATIC + EXTRA:
        if sym not in df.columns or sym not in rrg:
            continue
        s = df[sym].dropna()
        if len(s) < 16:
            continue
        sma = s.rolling(min(40, len(s))).mean().iloc[-1]
        price_above = bool(s.iloc[-1] > sma)
        rs_rising = bool(rrg[sym]["mom"] >= 100)
        n = min(13, len(s) - 1)
        abs_mom = float(s.iloc[-1] / s.iloc[-1 - n] - 1)
        abs_pos = bool(abs_mom > 0)
        f = flow.get(sym, {})
        diverg = f.get("diverg")
        distrib = (diverg == "distribucion oculta")     # precio sube pero el dinero sale
        obv_ok = bool(f.get("obv_above")) and not distrib  # no se puntua "entra dinero" si hay distribucion
        cmf_ok = bool(f.get("cmf_pos"))
        parts = [("precio>SMA40", price_above), ("RS subiendo", rs_rising),
                 ("mom.abs>0", abs_pos), ("OBV>media", obv_ok), ("CMF>0", cmf_ok)]
        score = sum(1 for _, v in parts if v)
        rows.append({"sym": sym, "score": score, "parts": parts, "distrib": distrib,
                     "obv_cross": bool(f.get("obv_cross")), "abs_mom": round(abs_mom * 100, 1)})
    rows.sort(key=lambda r: (-r["score"], -r["abs_mom"]))
    return rows

def heatmap_color(v):
    if v is None:
        return "background:#141A26;color:#3A4658"
    x = max(-1.0, min(1.0, v / 8.0))
    if x >= 0:
        return f"background:rgba(47,208,138,{0.12 + 0.78*x:.2f});color:#06140C"
    return f"background:rgba(244,96,122,{0.12 + 0.78*(-x):.2f});color:#1A0608"


# ----------------------------------------------------------------------
# Backtest causal: sobreponderar Lider+Mejorando vs comprar y mantener el indice
# ----------------------------------------------------------------------
def backtest(df, rrg, hold=("leading", "improving"), trend=None, max_pos=None, weight=None, buffer=None):
    trend = TREND_FILTER if trend is None else trend
    max_pos = MAX_POSICIONES if max_pos is None else max_pos
    weight = PESO if weight is None else weight
    buffer = BUFFER if buffer is None else buffer
    idx = list(df.index)
    rets = df.pct_change()
    bench_ret = rets[BENCH].tolist()
    sectors = list(rrg.keys())
    R = {s: rrg[s]["ratio_series"] for s in sectors}
    M = {s: rrg[s]["mom_series"] for s in sectors}
    ok = lambda v: v is not None and v == v
    # filtro de tendencia del mercado: S&P vs su media de TREND_MA_WEEKS
    spy = df[BENCH]
    ma = spy.rolling(min(TREND_MA_WEEKS, len(spy)), min_periods=5).mean().tolist()
    spyl = spy.tolist()
    # volatilidad movil (13s) para el peso por volatilidad inversa
    vol = {s: rets[s].rolling(13, min_periods=4).std().tolist() for s in sectors}
    held = set()   # para la histeresis
    eq_s, eq_b = [1.0], [1.0]; wins = weeks = 0; in_mkt = 0
    for i in range(1, len(idx)):
        br = bench_ret[i] if bench_ret[i] == bench_ret[i] else 0.0
        bull = not (trend and ok(ma[i-1]) and spyl[i-1] < ma[i-1])
        chosen = []
        if bull:
            for s in sectors:
                rr, mm = R[s][i-1], M[s][i-1]
                if not (ok(rr) and ok(mm)):
                    held.discard(s); continue
                q = quad_of(rr, mm)
                strong = q in hold and rr > 100 + buffer and mm > 100 - buffer
                weak = not (q in hold) or rr < 100 - buffer or mm < 100 - buffer
                if strong:
                    held.add(s)
                elif weak:
                    held.discard(s)
                if s in held:
                    chosen.append(s)
            # tope: las de mayor impulso
            if max_pos and len(chosen) > max_pos:
                chosen = sorted(chosen, key=lambda s: -(M[s][i-1] or 0))[:max_pos]
        if chosen:
            ws = {}
            for s in chosen:
                if weight == "volatilidad":
                    v = vol[s][i-1] if ok(vol[s][i-1]) and vol[s][i-1] > 1e-6 else 0.02
                    ws[s] = 1.0 / v
                elif weight == "impulso":
                    ws[s] = max(0.1, (M[s][i-1] or 100) - 99)
                else:
                    ws[s] = 1.0
            tot = sum(ws.values()) or 1.0
            r = 0.0
            for s in chosen:
                ri = rets[s].iloc[i]
                r += (ws[s] / tot) * (ri if ri == ri else 0.0)
            in_mkt += 1
        else:
            r = 0.0   # liquidez (mercado bajista o nada elegido)
        eq_s.append(eq_s[-1] * (1 + r))
        eq_b.append(eq_b[-1] * (1 + br))
        weeks += 1
        if r > br:
            wins += 1
    def mdd(curve):
        peak = curve[0]; worst = 0.0
        for v in curve:
            peak = max(peak, v); worst = min(worst, v / peak - 1)
        return worst * 100
    return {
        "eq_s": eq_s, "eq_b": eq_b, "dates": [str(d.date()) for d in idx],
        "tot_s": round((eq_s[-1] - 1) * 100, 1), "tot_b": round((eq_b[-1] - 1) * 100, 1),
        "mdd_s": round(mdd(eq_s), 1), "mdd_b": round(mdd(eq_b), 1),
        "winrate": int(round(100 * wins / max(weeks, 1))), "weeks": weeks,
        "exposure": int(round(100 * in_mkt / max(weeks, 1))),
    }


# ----------------------------------------------------------------------
# Caidas del S&P 500: frecuencia anual, probabilidad y plan de liquidez
# ----------------------------------------------------------------------
def compute_seasonality(close, ahead=5):
    # Estacionalidad por MEDIA-QUINCENA (1H = dias 1-15, 2H = 16-fin de mes) sobre el historico largo.
    # Para el periodo actual y los proximos: % de años con retorno positivo y retorno medio.
    s = close.dropna()
    if s is None or len(s) < 252 * 8:
        return None
    d = pd.DataFrame({"c": s})
    d["year"] = d.index.year
    d["month"] = d.index.month
    d["half"] = np.where(d.index.day <= 15, 1, 2)
    grp = d.groupby(["year", "month", "half"])["c"]
    ret = (grp.last() / grp.first() - 1).reset_index()
    stats = {}
    for (m, h), g in ret.groupby(["month", "half"]):
        vals = g["c"].dropna().values
        if len(vals) >= 5:
            stats[(m, h)] = {"avg": round(100 * float(vals.mean()), 2),
                             "pup": int(round(100 * float((vals > 0).mean()))), "n": int(len(vals))}
    mes = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
    today = dt.date.today()
    m, h = today.month, (1 if today.day <= 15 else 2)
    rows = []
    for k in range(ahead + 1):
        st = stats.get((m, h))
        rows.append({"label": f"{'1ª' if h == 1 else '2ª'} mitad de {mes[m-1]}",
                     "now": k == 0, "pup": st["pup"] if st else None, "avg": st["avg"] if st else None,
                     "n": st["n"] if st else 0})
        if h == 1:
            h = 2
        else:
            h = 1; m = 1 if m == 12 else m + 1
    return {"rows": rows, "years": int(s.index.year.nunique())}


def _fetch_long(stooq_sym, etf_fallback, yahoo_sym):
    """Historia LARGA de un indice (Stooq -> ETF -> Yahoo). Devuelve (close, fuente, hl) donde hl=High/Low o None."""
    start = dt.date.today() - dt.timedelta(days=365 * 60)
    try:
        r = requests.get(f"https://stooq.com/q/d/l/?s={stooq_sym}&i=d", timeout=20,
                         headers={"User-Agent": "Mozilla/5.0"})
        df = pd.read_csv(StringIO(r.text))
        if "Close" in df.columns and len(df) > 1000:
            df["Date"] = pd.to_datetime(df["Date"])
            df = df.set_index("Date").sort_index()
            hl = df[["High", "Low"]] if {"High", "Low"}.issubset(df.columns) else None
            return df["Close"], stooq_sym.upper(), hl
    except Exception:
        pass
    if etf_fallback:
        d, _ = get_ohlcv(etf_fallback, start, dt.date.today())
        if d is not None and "Close" in d.columns:
            hl = d[["High", "Low"]] if {"High", "Low"}.issubset(d.columns) else None
            return d["Close"].sort_index(), etf_fallback, hl
    if yf is not None:
        try:
            g = yf.download(yahoo_sym, start=start, progress=False, auto_adjust=False)   # sin ajustar: % de caída fieles al índice real
            c = g["Close"]
            if hasattr(c, "columns"):
                c = c.iloc[:, 0]
            hl = None
            if {"High", "Low"}.issubset(g.columns):
                h, l = g["High"], g["Low"]
                if hasattr(h, "columns"):
                    h = h.iloc[:, 0]
                if hasattr(l, "columns"):
                    l = l.iloc[:, 0]
                hl = pd.DataFrame({"High": h, "Low": l}).dropna()
            return c.dropna().sort_index(), yahoo_sym, hl
        except Exception:
            pass
    return None, "—", None

def fetch_long_close():
    """Historia LARGA del S&P 500 para estadistica de caidas."""
    return _fetch_long("^spx", "SPY", "^GSPC")

def drawdown_stats(close, thresholds, hl=None):
    close = close.dropna()
    if len(close) < 250:
        return None, None
    years = sorted(set(close.index.year))
    cur_year = dt.date.today().year
    today_md = (dt.date.today().month, dt.date.today().day)

    def count(peak_src, trough_src):
        counts = {t: {y: 0 for y in years} for t in thresholds}
        rest_hit = {t: set() for t in thresholds}
        peak = peak_src.iloc[0]
        in_ev = {t: False for t in thresholds}
        for date, p in peak_src.items():
            if p > peak:
                peak = p
            dd = (trough_src.loc[date] / peak - 1) * 100
            in_window = (date.month, date.day) >= today_md
            for t in thresholds:
                if not in_ev[t] and dd <= -t:
                    in_ev[t] = True
                    counts[t][date.year] += 1
                elif in_ev[t] and dd > -t / 2.0:
                    in_ev[t] = False
                if dd <= -t and in_window and date.year < cur_year:
                    rest_hit[t].add(date.year)
        return counts, rest_hit

    basis = "cierre"
    counts, rest_hit = count(close, close)
    if hl is not None and {"High", "Low"}.issubset(hl.columns):
        hh = hl["High"].reindex(close.index).ffill().dropna()
        ll = hl["Low"].reindex(close.index).ffill().dropna()
        idx = hh.index.intersection(ll.index)
        if len(idx) > 250:
            counts, rest_hit = count(hh.loc[idx], ll.loc[idx])   # intradía: pico=máx de High, caída con Low
            basis = "intradía"
    complete = [y for y in years if y < cur_year]
    last20 = [y for y in complete if y >= cur_year - 20]
    def stats(t, yrs):
        if not yrs:
            return 0.0, 0
        vals = [counts[t][y] for y in yrs]
        return round(sum(vals) / len(yrs), 1), int(round(100 * sum(1 for v in vals if v >= 1) / len(yrs)))
    out = {}
    for t in thresholds:
        a20, p20 = stats(t, last20)
        af, pf = stats(t, complete)
        rest = int(round(100 * len(rest_hit[t] & set(complete)) / len(complete))) if complete else 0
        out[t] = {"avg20": a20, "prob20": p20, "avgfull": af, "probfull": pf,
                  "ytd": counts[t].get(cur_year, 0), "rest": rest}
    meta = {"start": years[0], "end": years[-1], "n20": len(last20), "nfull": len(complete),
            "cur_year": cur_year, "basis": basis}
    return out, meta

def fetch_fear_greed():
    """Indice Fear & Greed de CNN (0-100, sentimiento contrario). Devuelve dict o None si falla."""
    try:
        r = requests.get("https://production.dataviz.cnn.io/index/fearandgreed/graphdata",
                         timeout=20, headers={
                             "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                                           "(KHTML, like Gecko) Chrome/123.0 Safari/537.36",
                             "Accept": "application/json"})
        fg = r.json().get("fear_and_greed", {})
        sc = fg.get("score")
        if sc is None:
            return None
        def _g(k):
            v = fg.get(k)
            return round(float(v)) if v is not None else None
        return {"score": round(float(sc)), "rating": (fg.get("rating") or "").strip(),
                "prev": _g("previous_close"), "week": _g("previous_1_week"),
                "month": _g("previous_1_month"), "year": _g("previous_1_year")}
    except Exception:
        return None

def cash_plan(close):
    close = close.dropna()
    peak = float(close.cummax().iloc[-1])
    last = float(close.iloc[-1])
    rungs = []
    for thr, pct in CASH_PLAN:
        level = peak * (1 - thr / 100)
        rungs.append({"thr": thr, "pct": pct, "level": round(level, 2), "hit": last <= level})
    return {"peak": round(peak, 2), "last": round(last, 2), "dd": round((last / peak - 1) * 100, 1), "rungs": rungs}

def fetch_fx():
    """EUR/USD avanzado para la cobertura divisa (Stooq -> Yahoo)."""
    c = None
    try:
        r = requests.get("https://stooq.com/q/d/l/?s=eurusd&i=d", timeout=20,
                         headers={"User-Agent": "Mozilla/5.0"})
        df = pd.read_csv(StringIO(r.text))
        if "Close" in df.columns and len(df) > 60:
            df["Date"] = pd.to_datetime(df["Date"])
            c = df.set_index("Date")["Close"].sort_index()
    except Exception:
        c = None
    if c is None and yf is not None:
        try:
            g = yf.download("EURUSD=X", period="3y", progress=False)["Close"]
            if hasattr(g, "columns"):
                g = g.iloc[:, 0]
            c = g.dropna()
        except Exception:
            c = None
    if c is None or len(c) < 60:
        return None
    last = float(c.iloc[-1])
    ma50 = float(c.rolling(min(50, len(c))).mean().iloc[-1])
    ma200 = float(c.rolling(min(200, len(c))).mean().iloc[-1])
    def roc(k):
        return round(float(c.iloc[-1] / c.iloc[-min(k, len(c) - 1)] - 1) * 100, 1) if len(c) > k else None
    win = c.iloc[-min(252, len(c)):]
    hi52, lo52 = float(win.max()), float(win.min())
    pos = round(100 * (last - lo52) / ((hi52 - lo52) or 1e-9))   # 0=minimo 52s, 100=maximo 52s
    cross = "alcista (50>200)" if ma50 > ma200 else "bajista (50<200)"
    # fuerza de tendencia del euro: combinacion de posicion vs medias y momentum
    score = (last > ma50) + (last > ma200) + (ma50 > ma200) + (roc(65) or 0 > 0)
    return {"last": round(last, 4), "ma50": round(ma50, 4), "ma200": round(ma200, 4),
            "roc1m": roc(22), "roc3m": roc(65), "roc6m": roc(130),
            "hi52": round(hi52, 4), "lo52": round(lo52, 4), "pos": pos, "cross": cross,
            "above50": last > ma50, "above200": last > ma200, "strong": score >= 3,
            "spark": [float(x) for x in c.iloc[-min(160, len(c)):].tolist()]}

# ----------------------------------------------------------------------
# Acciones lideres por sector (RS Rating 1-99, estilo IBD/O'Neil)
# ----------------------------------------------------------------------
def fetch_stock_universe():
    print(f"\n[Universo RS: '{RS_UNIVERSE}']")
    if RS_UNIVERSE == "sp500":
        closes = fetch_sp500_universe()
        if len(closes) >= 150:
            # Asegurar que TODAS las acciones de SECTOR_STOCKS (las de agua de FIW incluidas) entren
            # en el ranking aunque NO sean del S&P 500 (p.ej. MLI Mueller) o falten en la lista (p.ej. FERG).
            # Sin esto, esas acciones no tienen percentil y desaparecen del panel.
            extra = sorted({t for lst in SECTOR_STOCKS.values() for t in lst if t not in closes})
            if extra:
                print(f"  +{len(extra)} acciones de SECTOR_STOCKS fuera del S&P (incluye agua FIW: MLI, FERG, etc.)...")
                start = dt.date.today() - dt.timedelta(days=500)
                for t in extra:
                    try:
                        d, _ = get_ohlcv(t, start, dt.date.today())
                        if d is not None and "Close" in d.columns and len(d) > 200:
                            closes[t] = d["Close"].dropna()
                    except Exception:
                        pass
                    time.sleep(0.15)
            return closes
        print("  (S&P 500 insuficiente; uso la lista por sectores)")
    tickers = sorted({t for lst in SECTOR_STOCKS.values() for t in lst})
    start = dt.date.today() - dt.timedelta(days=500)
    closes = {}
    print(f"\nDescargando {len(tickers)} acciones para el ranking de lideres...")
    for i, t in enumerate(tickers):
        d, _ = get_ohlcv(t, start, dt.date.today())
        if d is not None and "Close" in d.columns and len(d) > 200:
            closes[t] = d["Close"].dropna()
        if (i + 1) % 20 == 0:
            print(f"  ...{i + 1}/{len(tickers)}")
        time.sleep(0.15)
    print(f"  acciones con datos: {len(closes)}")
    return closes

def sp500_tickers():
    for url in ("https://raw.githubusercontent.com/datasets/s-and-p-500-companies/main/data/constituents.csv",
                "https://datahub.io/core/s-and-p-500-companies/r/constituents.csv"):
        try:
            r = requests.get(url, timeout=20, headers={"User-Agent": "Mozilla/5.0"})
            df = pd.read_csv(StringIO(r.text))
            col = "Symbol" if "Symbol" in df.columns else df.columns[0]
            ts = [str(t).strip().upper().replace(".", "-") for t in df[col].dropna()]
            ts = list(dict.fromkeys(ts))
            if len(ts) > 400:
                print(f"  lista S&P 500 obtenida: {len(ts)} valores")
                return ts
        except Exception:
            continue
    print(f"  (no pude bajar la lista del S&P; uso respaldo de {len(set(SP500_FALLBACK))})")
    return list(dict.fromkeys(SP500_FALLBACK))

def _yf_batch_closes(tickers):
    closes = {}
    if yf is None:
        return closes
    for i in range(0, len(tickers), 80):
        chunk = tickers[i:i + 80]
        try:
            data = yf.download(chunk, period="2y", interval="1d", progress=False,
                               auto_adjust=True, threads=True)
            if data is None or len(data) == 0:
                continue
            if isinstance(data.columns, pd.MultiIndex):
                cl = data["Close"]
            else:
                cl = data[["Close"]].rename(columns={"Close": chunk[0]})
            for t in cl.columns:
                s = cl[t].dropna()
                if len(s) > 200:
                    closes[str(t)] = s
        except Exception:
            continue
        time.sleep(0.4)
    return closes

def fetch_sp500_universe():
    tickers = sp500_tickers()
    print(f"\nDescargando el S&P 500 ({len(tickers)} acciones) para el RS...")
    closes = _yf_batch_closes(tickers)
    print(f"  via yfinance: {len(closes)}")
    # completar lo que falte por la via fiable (Stooq/Yahoo individual)
    missing = [t for t in tickers if t not in closes]
    if missing:
        print(f"  completando {len(missing)} por descarga individual (tarda un poco)...")
        start = dt.date.today() - dt.timedelta(days=500)
        for i, t in enumerate(missing):
            d, _ = get_ohlcv(t, start, dt.date.today())
            if d is not None and "Close" in d.columns and len(d) > 200:
                closes[t] = d["Close"].dropna()
            time.sleep(0.12)
            if (i + 1) % 50 == 0:
                print(f"    ...{i + 1}/{len(missing)}")
    print(f"  acciones del S&P con datos: {len(closes)}")
    return closes

def compute_rs_leaders(stock_close):
    OFF = 65   # ~3 meses (dias de bolsa) para medir la aceleracion del percentil
    def score_at(s, off):
        end = len(s) - 1 - off
        if end < 252:
            return None
        f = lambda k: float(s.iloc[end] / s.iloc[end - k] - 1)
        return 2 * f(63) + f(126) + f(189) + f(252)
    perf, perf_then, hi52 = {}, {}, {}
    for sym, s in stock_close.items():
        s = s.dropna()
        if len(s) < 260:
            continue
        sc = score_at(s, 0)
        if sc is None:
            continue
        perf[sym] = sc
        hi52[sym] = round(float(s.iloc[-1] / s.iloc[-252:].max()) * 100)
        st = score_at(s, OFF)
        if st is not None:
            perf_then[sym] = st
    if len(perf) < 5:
        return None, 0
    order = sorted(perf.items(), key=lambda kv: kv[1])
    n = len(order)
    rs = {sym: int(round(1 + 98 * i / (n - 1))) for i, (sym, _) in enumerate(order)}
    # percentil de hace 3 meses (mismo metodo) para la aceleracion
    rs_then = {}
    if len(perf_then) >= 5:
        ot = sorted(perf_then.items(), key=lambda kv: kv[1])
        nt = len(ot)
        rs_then = {sym: int(round(1 + 98 * i / (nt - 1))) for i, (sym, _) in enumerate(ot)}
    out = {}
    for sec, stocks in SECTOR_STOCKS.items():
        rows = []
        for st in stocks:
            if st in rs:
                drs = (rs[st] - rs_then[st]) if st in rs_then else None
                rows.append({"sym": st, "rs": rs[st], "hi": hi52.get(st, 0), "drs": drs})
        rows.sort(key=lambda x: -x["rs"])
        if rows:
            out[sec] = rows
    # amplitud REAL del sector: % de sus acciones por encima de su media de 50 sesiones (detecta falso liderazgo)
    breadth = {}
    for sec, stocks in SECTOR_STOCKS.items():
        above = tot = 0
        for st in stocks:
            s = stock_close.get(st)
            if s is None:
                continue
            s = s.dropna()
            if len(s) < 55:
                continue
            tot += 1
            if float(s.iloc[-1]) > float(s.iloc[-50:].mean()):
                above += 1
        if tot >= 3:
            breadth[sec] = {"pct": round(100 * above / tot), "n": tot}
    return out, n, breadth


# ----------------------------------------------------------------------
def pct_change(df, sym, weeks=13):
    if sym not in df.columns or len(df) <= weeks:
        return None
    return float(df[sym].iloc[-1] / df[sym].iloc[-1 - weeks] - 1) * 100

def detect_regime(df, rrg, risk, fred_sig=None):
    sig = {
        "Bonos (TLT)": pct_change(df, "TLT"),
        "Credito HY (HYG)": pct_change(df, "HYG"),
        "Oro (GLD)": pct_change(df, "GLD"),
        "Dolar (UUP)": pct_change(df, "UUP"),
        "Apetito riesgo": risk["score"],
    }
    tlt = sig["Bonos (TLT)"] or 0          # <0 => tipos al alza
    hyg = sig["Credito HY (HYG)"] or 0
    gld = sig["Oro (GLD)"] or 0
    uup = sig["Dolar (UUP)"] or 0
    rk = risk["score"]
    scores = {
        "reflacion":   (tlt < -1) * 2 + (rk > 1) * 2 + (hyg > 0) * 1 + (uup < 1) * 1,
        "goldilocks":  (rk > 1) * 2 + (gld < 2) * 1 + (hyg > 0) * 1 + (-2 < tlt < 2) * 1,
        "riskoff":     (rk < -1) * 2 + (hyg < -1) * 2 + (gld > 1) * 1 + (tlt > 1) * 1 + (uup > 1) * 1,
        "estanflacion":(gld > 3) * 2 + (tlt < -1) * 1 + (rk < 0) * 1,
        "pivote":      (tlt > 2) * 2 + (uup < -1) * 1 + (rrg.get("XLK", {}).get("quad") in ("leading", "improving")) * 1,
    }
    # señales macro reales de FRED (si hay key): tienen mas peso que las de mercado
    if fred_sig:
        curve = fred_sig.get("curve_chg", 0) or 0     # pendiente 2s10s, +=empinando
        y10 = fred_sig.get("dgs10_chg", 0) or 0       # tipo 10A, +=al alza
        hyo = fred_sig.get("hy_chg", 0) or 0          # diferencial HY, +=stress de credito
        scores["reflacion"] += (y10 > 0) * 2 + (curve > 0) * 1
        scores["riskoff"] += (hyo > 0.2) * 3 + (curve < 0) * 1
        scores["pivote"] += (y10 < 0) * 2 + (curve > 0.1) * 1
        scores["estanflacion"] += (y10 < 0 and gld > 2) * 1
    best = max(scores, key=scores.get)
    labels = {
        "reflacion": "Reflacion / tipos al alza",
        "goldilocks": "Goldilocks / desinflacion",
        "riskoff": "Risk-off / desaceleracion",
        "estanflacion": "Estanflacion / shock de oferta",
        "pivote": "Pivote dovish / recortes Fed",
    }
    favor = {
        "reflacion": ["XLF","XLE","XLI","XLB","IWM"], "goldilocks": ["XLK","XLY","XLC","IWM"],
        "riskoff": ["XLP","XLU","XLV","GLD","TLT"], "estanflacion": ["XLE","XLB","GLD"],
        "pivote": ["XLRE","XLU","XLK","GLD","IWM"],
    }
    hurt = {
        "reflacion": ["XLU","XLRE","TLT","XLK"], "goldilocks": ["XLP","XLU","GLD"],
        "riskoff": ["XLY","XLK","IWM","HYG","XLE"], "estanflacion": ["XLY","XLK","TLT","XLF"],
        "pivote": ["XLF"],
    }
    sig = {k: (round(v, 1) if v is not None else None) for k, v in sig.items()}
    return {"id": best, "label": labels[best], "favor": favor[best], "hurt": hurt[best], "sig": sig}

def conviction(rrg, regime):
    buy, avoid = [], []
    for s, d in rrg.items():
        if d["quad"] in ("improving", "leading") and s in regime["favor"]:
            buy.append(s)
        if d["quad"] in ("weakening", "lagging") and s in regime["hurt"]:
            avoid.append(s)
    return buy, avoid

# ----------------------------------------------------------------------
# FRED opcional (macro real) + avisos automaticos
# ----------------------------------------------------------------------
def _fred_key():
    """Resuelve la key de FRED: variable de entorno (Secret de GitHub / entorno del PC) ->
    archivo local 'clave_fred*' junto al script o en la carpeta actual (NO se sube; esta en .gitignore)
    -> constante FRED_API_KEY. Tolerante con Windows: acepta clave_fred.txt.txt, BOM y comillas."""
    k = os.environ.get("FRED_API_KEY", "") or FRED_API_KEY
    if k:
        return k.strip()
    import glob
    try:
        here = os.path.dirname(os.path.abspath(__file__))
    except Exception:
        here = os.getcwd()
    seen = []
    for d in (here, os.getcwd()):
        if d and d not in seen:
            seen.append(d)
    for d in seen:
        try:
            for p in sorted(glob.glob(os.path.join(d, "clave_fred*"))):
                try:
                    with open(p, "r", encoding="utf-8-sig") as f:   # utf-8-sig quita el BOM de Notepad
                        v = f.read().strip().strip('"').strip("'").strip()
                    if v:
                        return v
                except Exception:
                    continue
        except Exception:
            continue
    return ""

def fetch_fred():
    """Devuelve (panel_para_mostrar, señales_para_el_regimen) o (None, None)."""
    key = _fred_key()
    if not key:
        return None, None
    series = {"DGS10": "Tipo 10A (%)", "T10Y2Y": "Pendiente 2s10s",
              "BAMLH0A0HYM2": "Diferencial HY (OAS)", "DFII10": "Tipo real 10A (%)"}
    out = {}
    raw = {}
    for sid, lab in series.items():
        try:
            url = ("https://api.stlouisfed.org/fred/series/observations"
                   f"?series_id={sid}&api_key={key}&file_type=json"
                   "&sort_order=desc&limit=70")
            r = requests.get(url, timeout=15).json()
            obs = [o for o in r.get("observations", []) if o["value"] not in (".", "")]
            if not obs:
                continue
            last = float(obs[0]["value"])
            prev = float(obs[min(13, len(obs) - 1)]["value"])
            out[lab] = {"last": round(last, 2), "chg": round(last - prev, 2)}
            raw[sid] = {"last": last, "chg": last - prev}
        except Exception:
            continue
    if not out:
        return None, None
    sig = {
        "dgs10_chg": raw.get("DGS10", {}).get("chg", 0),
        "curve_chg": raw.get("T10Y2Y", {}).get("chg", 0),
        "hy_chg": raw.get("BAMLH0A0HYM2", {}).get("chg", 0),
        "hy_last": raw.get("BAMLH0A0HYM2", {}).get("last", 0),
    }
    return out, sig

def fetch_macro():
    """Descarga macro de FRED (empleo, inflacion, PCE, blandos) y calcula nivel + direccion.
    Defensivo: sin key o si falla una serie, la salta. Devuelve dict {sid: {...}} o None."""
    key = _fred_key()
    if not key:
        return None
    def _obs(sid, limit=90):
        try:
            url = ("https://api.stlouisfed.org/fred/series/observations"
                   f"?series_id={sid}&api_key={key}&file_type=json&sort_order=desc&limit={limit}")
            r = requests.get(url, timeout=15).json()
            return [float(o["value"]) for o in r.get("observations", []) if o["value"] not in (".", "")]
        except Exception:
            return []
    def _yoy(v, per=12):
        return (v[0] / v[per] - 1.0) * 100 if len(v) > per and v[per] else None
    m = {}
    # INFLACION (indices -> YoY y direccion del YoY a 6 meses)
    for sid, lab in (("PCEPILFE", "PCE subyacente"), ("CPILFESL", "IPC subyacente")):
        v = _obs(sid)
        yoy = _yoy(v)
        yoy6 = _yoy(v[6:]) if len(v) > 18 else None
        if yoy is not None:
            m[sid] = {"lab": lab, "val": round(yoy, 2), "unit": "% i.a.",
                      "dir": round(yoy - yoy6, 2) if yoy6 is not None else 0.0, "kind": "hard", "goodup": False}
    # EMPLEO
    pay = _obs("PAYEMS")
    if len(pay) > 4:
        chg3 = (pay[0] - pay[3]) / 3.0
        m["PAYEMS"] = {"lab": "Nóminas (prom. 3m)", "val": round(chg3, 0), "unit": "k/mes",
                       "dir": round((pay[0] - pay[1]) - (pay[3] - pay[4]), 0), "kind": "hard", "goodup": True}
    un = _obs("UNRATE")
    if len(un) > 3:
        m["UNRATE"] = {"lab": "Paro", "val": round(un[0], 2), "unit": "%",
                       "dir": round(un[0] - un[3], 2), "kind": "hard", "goodup": False}
    cl = _obs("ICSA", limit=60)
    if len(cl) > 8:
        m4, p4 = sum(cl[0:4]) / 4.0, sum(cl[4:8]) / 4.0
        m["ICSA"] = {"lab": "Paro semanal (4s)", "val": round(m4 / 1000, 0), "unit": "k",
                     "dir": round((m4 - p4) / 1000, 1), "kind": "soft", "goodup": False}
    # CRECIMIENTO
    ip = _obs("INDPRO")
    yoy_ip = _yoy(ip)
    if yoy_ip is not None:
        yoy_ip6 = _yoy(ip[6:]) if len(ip) > 18 else None
        m["INDPRO"] = {"lab": "Prod. industrial", "val": round(yoy_ip, 2), "unit": "% i.a.",
                       "dir": round(yoy_ip - yoy_ip6, 2) if yoy_ip6 is not None else 0.0, "kind": "hard", "goodup": True}
    # BLANDOS (lideres)
    um = _obs("UMCSENT")
    if len(um) > 3:
        m["UMCSENT"] = {"lab": "Confianza consumidor", "val": round(um[0], 1), "unit": "",
                        "dir": round(um[0] - um[3], 1), "kind": "soft", "goodup": True}
    cu = _obs("T10Y2Y", limit=70)
    if len(cu) > 13:
        m["T10Y2Y"] = {"lab": "Curva 2s10s", "val": round(cu[0], 2), "unit": "pp",
                       "dir": round(cu[0] - cu[13], 2), "kind": "soft", "goodup": True}
    hy = _obs("BAMLH0A0HYM2", limit=70)
    if len(hy) > 13:
        m["HY"] = {"lab": "Spread HY (riesgo)", "val": round(hy[0], 2), "unit": "pp",
                   "dir": round(hy[0] - hy[13], 2), "kind": "soft", "goodup": False}
    return m or None

def compute_macro_regime(m, ism):
    """Reloj de inversion: cruza direccion de CRECIMIENTO x direccion de INFLACION -> cuadrante + playbook.
    Las probabilidades son GRUESAS (base-rate del regimen), nunca una prediccion."""
    if not m:
        return None
    # eje INFLACION
    infl_dir, n = 0.0, 0
    for sid in ("PCEPILFE", "CPILFESL"):
        if sid in m:
            infl_dir += m[sid]["dir"]; n += 1
    infl_dir = infl_dir / n if n else 0.0
    infl_up = infl_dir > 0.1
    infl_lbl = "subiendo" if infl_up else ("bajando" if infl_dir < -0.1 else "estable")
    # eje CRECIMIENTO (compuesto blandos + hard; ISM pesa doble)
    g, gmax = 0, 0
    if ism is not None:
        gmax += 2; g += (2 if ism >= 53 else (1 if ism >= 50 else (-1 if ism >= 47 else -2)))
    if "INDPRO" in m:
        gmax += 1; g += (1 if (m["INDPRO"]["val"] > 0 and m["INDPRO"]["dir"] >= 0) else (-1 if (m["INDPRO"]["val"] < 0 or m["INDPRO"]["dir"] < -0.2) else 0))
    if "ICSA" in m:
        gmax += 1; g += (1 if m["ICSA"]["dir"] < 0 else (-1 if m["ICSA"]["dir"] > 5 else 0))
    if "UMCSENT" in m:
        gmax += 1; g += (1 if m["UMCSENT"]["dir"] > 0 else (-1 if m["UMCSENT"]["dir"] < -2 else 0))
    if "PAYEMS" in m:
        gmax += 1; g += (1 if m["PAYEMS"]["val"] > 100 else (-1 if m["PAYEMS"]["val"] < 50 else 0))
    if "T10Y2Y" in m:
        gmax += 1; g += (1 if m["T10Y2Y"]["dir"] > 0.05 else 0)
    grow_up = g > 0
    grow_lbl = "acelerando" if g > 0 else ("desacelerando" if g < 0 else "estable")
    # cuadrante del reloj de inversion
    if grow_up and not infl_up:
        quad, label = "recuperacion", "Recuperación / reflación temprana"
        favor, hurt = ["XLK", "XLY", "XLF", "IWM", "XLC", "SMH"], ["XLP", "XLU", "TLT", "GLD"]
    elif grow_up and infl_up:
        quad, label = "sobrecalentamiento", "Sobrecalentamiento"
        favor, hurt = ["XLE", "XLB", "XLF", "COPX", "GLD"], ["TLT", "XLK", "XLY"]
    elif (not grow_up) and infl_up:
        quad, label = "estanflacion", "Estanflación / shock de oferta"
        favor, hurt = ["XLE", "GLD", "XLP", "XLU", "GDX"], ["XLY", "IWM", "XLK", "SMH"]
    else:
        quad, label = "desinflacion", "Desinflación / desaceleración"
        favor, hurt = ["TLT", "XLU", "XLP", "XLV", "GLD"], ["XLE", "XLB", "IWM", "XLF"]
    # probabilidades GRUESAS (transparentes): cuanto mas clara la senal, mas peso al caso base
    conf = abs(g) / max(gmax, 1)
    base = 0.45 + 0.20 * conf
    rest = 1 - base
    bull, bear = (rest * 0.6, rest * 0.4) if g >= 0 else (rest * 0.4, rest * 0.6)
    pr = {"base": round(base * 100), "bull": round(bull * 100), "bear": round(bear * 100)}
    return {"quad": quad, "label": label, "favor": favor, "hurt": hurt,
            "grow_lbl": grow_lbl, "infl_lbl": infl_lbl, "grow_up": grow_up, "infl_up": infl_up,
            "g": g, "gmax": gmax, "conf": conf, "pr": pr}

def notify(text):
    """Envia el resumen a Telegram y/o a un webhook (Discord/Slack). Devuelve True si envio algo."""
    sent = False
    tok = os.environ.get("TELEGRAM_TOKEN") or TELEGRAM_TOKEN
    chat = os.environ.get("TELEGRAM_CHAT_ID") or TELEGRAM_CHAT_ID
    if tok and chat:
        try:
            requests.post(f"https://api.telegram.org/bot{tok}/sendMessage",
                          data={"chat_id": chat, "text": text}, timeout=15)
            sent = True
        except Exception:
            pass
    hook = os.environ.get("WEBHOOK_URL") or WEBHOOK_URL
    if hook:
        try:
            requests.post(hook, json={"content": text, "text": text}, timeout=15)
            sent = True
        except Exception:
            pass
    return sent

# ----------------------------------------------------------------------
# Analisis con IA (opcional)
# ----------------------------------------------------------------------
def state_summary(rrg, risk, regime, breadth, plan, flow):
    by_q = {"leading": [], "weakening": [], "improving": [], "lagging": []}
    for s, d in rrg.items():
        by_q[d["quad"]].append(s)
    divs = [f"{s} ({d['diverg']})" for s, d in (flow or {}).items() if d.get("diverg")]
    lines = [
        f"Regimen macro: {regime['label']}. Apetito de riesgo: {risk['label']} ({risk['score']:+}).",
        f"Amplitud: {breadth['leaders']}% con fuerza>indice, {breadth['uptrend']}% en tendencia.",
        f"LIDER: {', '.join(by_q['leading']) or '-'}.",
        f"DEBILITANDOSE: {', '.join(by_q['weakening']) or '-'}.",
        f"MEJORANDO: {', '.join(by_q['improving']) or '-'}.",
        f"REZAGADO: {', '.join(by_q['lagging']) or '-'}.",
    ]
    if divs:
        lines.append(f"Divergencias de flujo: {', '.join(divs)}.")
    if plan:
        lines.append(f"Caida actual del S&P desde maximos: {plan['dd']}%.")
    return "\n".join(lines)

def ai_commentary(summary):
    key = ANTHROPIC_API_KEY or os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        return None
    prompt = ("Eres analista de rotacion sectorial. Con estos datos de cierre (no en tiempo real), "
              "escribe un analisis breve en espanol (maximo 150 palabras): que esta rotando, que vigilar "
              "para entrar o proteger, y como encaja con la macro. Se concreto y prudente; no es asesoramiento.\n\n"
              + summary)
    try:
        r = requests.post("https://api.anthropic.com/v1/messages",
                          headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                                   "content-type": "application/json"},
                          json={"model": AI_MODEL, "max_tokens": 500,
                                "messages": [{"role": "user", "content": prompt}]},
                          timeout=40)
        j = r.json()
        txt = "".join(b.get("text", "") for b in j.get("content", []) if b.get("type") == "text")
        return txt.strip() or None
    except Exception:
        return None

# ----------------------------------------------------------------------
# Render del panel HTML (SVG + tablas, sin JS)
# ----------------------------------------------------------------------
CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{--bg:#0A0E17;--bg2:#0F1521;--bg3:#131B2A;--line:#1E2A3D;--line2:#2A3A52;
--txt:#E6EDF6;--txt2:#93A4BC;--txt3:#5E708A;--accent:#5B8CFF;
background:var(--bg);color:var(--txt);font-family:ui-sans-serif,system-ui,'Segoe UI',Roboto,sans-serif;
line-height:1.45;-webkit-font-smoothing:antialiased;padding-bottom:40px}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-variant-numeric:tabular-nums}
header{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;
padding:14px 22px;border-bottom:1px solid var(--line);background:var(--bg2)}
.brand{display:flex;align-items:center;gap:11px}
.title{font-size:17px;font-weight:800;letter-spacing:4px}
.sub{font-size:10.5px;letter-spacing:2px;text-transform:uppercase;color:var(--txt3)}
.status{display:flex;gap:14px;flex-wrap:wrap;align-items:center;font-family:ui-monospace,monospace;font-size:11px;color:var(--txt2)}
.status b{color:var(--txt3);font-weight:500;font-size:9.5px;letter-spacing:1px;text-transform:uppercase;margin-right:5px}
.pill{font-size:10px;font-weight:700;letter-spacing:1px;padding:3px 9px;border-radius:4px;font-family:ui-monospace,monospace}
.RiskON{background:rgba(47,208,138,.14);color:#2FD08A}.RiskOFF{background:rgba(244,96,122,.14);color:#F4607A}
.Neutral{background:rgba(147,164,188,.12);color:var(--txt2)}
main{max-width:1280px;margin:0 auto;padding:16px;display:grid;grid-template-columns:1.55fr 1fr;gap:14px}
@media(max-width:900px){main{grid-template-columns:1fr}}
.panel{background:var(--bg2);border:1px solid var(--line);border-radius:10px;padding:14px 15px;margin-bottom:14px}
.panel h2{font-size:12.5px;font-weight:600;margin-bottom:10px}
.note{font-size:11.5px;color:var(--txt2);margin:6px 0 10px}
svg{width:100%;height:auto;display:block;background:var(--bg);border-radius:8px}
.legend{display:flex;gap:14px;flex-wrap:wrap;margin-top:10px;font-size:11px;color:var(--txt2)}
.legend i{width:9px;height:9px;border-radius:2px;display:inline-block;margin-right:5px}
.alerts{display:flex;flex-direction:column;gap:7px}
.alert{display:flex;gap:9px;background:var(--bg3);border:1px solid var(--line);border-left-width:3px;border-radius:7px;padding:8px 10px}
.a-warn{border-left-color:#F4B740}.a-in{border-left-color:#4CC2E0}.a-lead{border-left-color:#2FD08A}.a-down{border-left-color:#F4607A}
.atk{font-family:ui-monospace,monospace;font-weight:700;font-size:12px;min-width:42px}
.atx{font-size:11.5px;color:var(--txt2)}
table{width:100%;border-collapse:collapse;font-size:12px}
th{font-size:10px;text-transform:uppercase;letter-spacing:.6px;color:var(--txt3);text-align:left;padding:6px}
td{padding:7px 6px;border-top:1px solid var(--line);color:var(--txt2)}
td.r{text-align:right;font-family:ui-monospace,monospace}
.tk b{color:var(--txt);font-family:ui-monospace,monospace}.tk em{color:var(--txt3);font-style:normal;font-size:10px;display:block}
.dot{width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:5px}
.bar-row{display:grid;grid-template-columns:46px 1fr 44px;align-items:center;gap:9px;margin-bottom:6px}
.bar-lab{font-family:ui-monospace,monospace;font-size:12px;color:var(--txt)}
.bar-track{position:relative;height:16px;background:var(--bg3);border-radius:4px}
.bar-mid{position:absolute;left:50%;top:0;bottom:0;width:1px;background:var(--line2)}
.bar{position:absolute;top:2px;bottom:2px;border-radius:3px}
.bar-val{text-align:right;font-family:ui-monospace,monospace;font-size:11.5px}
.meter{margin-bottom:12px}.meter-top{display:flex;justify-content:space-between;font-size:11.5px;color:var(--txt2);margin-bottom:5px}
.meter-top b{font-family:ui-monospace,monospace}.meter-track{height:7px;background:var(--bg3);border-radius:4px;overflow:hidden}
.meter-fill{height:100%;border-radius:4px}
.bigrisk{font-size:22px;font-weight:800;letter-spacing:2px;text-align:center;padding:12px 0 6px;font-family:ui-monospace,monospace}
.tags{display:flex;flex-wrap:wrap;gap:5px;margin-top:5px}
.tag{font-family:ui-monospace,monospace;font-size:11px;padding:2px 7px;border-radius:4px;font-weight:600}
.tag.good{background:rgba(47,208,138,.12);color:#2FD08A}.tag.bad{background:rgba(244,96,122,.12);color:#F4607A}
.conv{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:10px}
@media(max-width:560px){.conv{grid-template-columns:1fr}}
.conv-box{border:1px solid var(--line);border-radius:8px;padding:11px;background:var(--bg3)}
.conv-box h3{font-size:11.5px;margin-bottom:5px}
.kv{display:flex;justify-content:space-between;font-size:12px;padding:5px 0;border-bottom:1px solid var(--line)}
.kv span{color:var(--txt3)}.kv b{color:var(--txt);font-family:ui-monospace,monospace;font-weight:500}
.full{grid-column:1/-1}
.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:2px}
@media(max-width:700px){.summary{grid-template-columns:1fr 1fr}}
.scard{background:var(--bg2);border:1px solid var(--line);border-radius:10px;padding:11px 13px}
.scard .lab{font-size:9px;text-transform:uppercase;letter-spacing:1px;color:var(--txt3);margin-bottom:6px}
.scard .big{font-size:17px;font-weight:800;font-family:ui-monospace,monospace;line-height:1.1}
.scard .sm{font-size:10.5px;color:var(--txt2);margin-top:4px}
td.spk{width:84px;padding-right:10px}
td.spk svg{display:block;opacity:.9}
td.ts2{font-size:10.5px;color:var(--txt3);white-space:nowrap}
.planwrap{display:grid;grid-template-columns:1.1fr 1fr;gap:16px}
@media(max-width:760px){.planwrap{grid-template-columns:1fr}}
.dd-now{background:var(--bg3);border:1px solid var(--line);border-radius:9px;padding:11px 13px;margin-bottom:10px}
.dd-now .lab{font-size:9.5px;text-transform:uppercase;letter-spacing:1px;color:var(--txt3)}
.dd-big{font-size:30px;font-weight:800;font-family:ui-monospace,monospace;line-height:1.1;margin:2px 0}
.dd-now .sm{font-size:11px;color:var(--txt2);font-family:ui-monospace,monospace}
.rung{display:grid;grid-template-columns:54px 1fr auto auto auto;gap:10px;align-items:center;
background:var(--bg3);border:1px solid var(--line);border-left:3px solid var(--line);border-radius:8px;padding:9px 11px;margin-bottom:7px}
.rk-thr{font-family:ui-monospace,monospace;font-weight:800;font-size:15px;color:var(--txt)}
.rk-lvl{font-family:ui-monospace,monospace;font-size:11.5px;color:var(--txt2)}
.rk-pct{font-size:11.5px;color:#5B8CFF;font-weight:600}
.rk-veh{font-family:ui-monospace,monospace;font-size:11px;color:#F4B740;background:rgba(244,183,64,.12);padding:1px 6px;border-radius:4px}
.rk-st{font-size:10.5px;font-family:ui-monospace,monospace;text-align:right}
@media(max-width:520px){.rung{grid-template-columns:46px 1fr auto;row-gap:4px}.rk-veh,.rk-st{grid-column:2/4}}
.planstats table{width:100%}
.planstats th{vertical-align:bottom;line-height:1.15}
.veh3{font-family:ui-monospace,monospace;font-size:10.5px;color:#F4B740;background:rgba(244,183,64,.12);padding:1px 6px;border-radius:4px}
svg circle{cursor:help}
td.tk{cursor:help}
.veh3.off{color:#5E708A;background:none}
.qgrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
@media(max-width:560px){.qgrid{grid-template-columns:1fr}}
.qcell{background:var(--bg3);border:1px solid var(--line);border-radius:9px;padding:10px 11px;min-height:84px}
.qhead{font-family:ui-monospace,monospace;font-size:11px;font-weight:700;letter-spacing:1px;margin-bottom:8px}
.qhead span{color:var(--txt3);font-weight:400;letter-spacing:0;text-transform:none}
.qchips{display:flex;flex-wrap:wrap;gap:6px}
.qchip{border:1px solid var(--line);border-radius:6px;padding:3px 7px;font-size:11px;background:var(--bg2);cursor:help}
.qchip b{font-family:ui-monospace,monospace}.qchip i{color:var(--txt3);font-style:normal;font-size:9.5px;font-family:ui-monospace,monospace}
.qempty{color:var(--txt3);font-size:11px}
.viewtabs{display:flex;gap:6px;margin-bottom:10px}
.viewtab{font-size:11px;color:var(--txt3);background:var(--bg3);border:1px solid var(--line);border-radius:6px;padding:5px 12px;cursor:pointer}
.viewtab.active{color:#fff;background:#5B8CFF;border-color:#5B8CFF;font-weight:600}
.ai-box{background:linear-gradient(180deg,rgba(91,140,255,.07),rgba(91,140,255,0));border:1px solid rgba(91,140,255,.25);
border-radius:9px;padding:12px 14px;font-size:12.5px;color:var(--txt);line-height:1.55;white-space:pre-wrap}
.ai-btn{display:inline-flex;align-items:center;gap:7px;background:#5B8CFF;color:#fff;border:none;border-radius:8px;
padding:9px 14px;font-size:12.5px;font-weight:600;cursor:pointer;text-decoration:none}
.ai-btn.alt{background:var(--bg3);color:var(--txt2);border:1px solid var(--line)}
.hold-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}
@media(max-width:600px){.hold-grid{grid-template-columns:1fr}}
.hold{display:flex;justify-content:space-between;align-items:center;gap:8px;background:var(--bg3);border:1px solid var(--line);
border-radius:7px;padding:7px 10px;font-size:11.5px}
.hold .h-sym{font-family:ui-monospace,monospace;font-weight:700;color:var(--txt)}
.hold .h-top{color:var(--txt2);font-family:ui-monospace,monospace;font-size:11px}
.hold a{color:#5B8CFF;text-decoration:none;font-size:10.5px}
.lrow{display:grid;grid-template-columns:150px 1fr;gap:12px;align-items:center;padding:8px 0;border-bottom:1px solid var(--line)}
@media(max-width:560px){.lrow{grid-template-columns:1fr;gap:4px}}
.lsec b{font-family:ui-monospace,monospace;color:var(--txt)}.lsec span{color:var(--txt3);font-size:10.5px}
.lchips{display:flex;flex-wrap:wrap;gap:6px}
.lchip{display:inline-flex;align-items:center;gap:5px;background:var(--bg3);border:1px solid var(--line);border-radius:7px;padding:3px 7px;font-size:11.5px}
.lchip b{font-family:ui-monospace,monospace;color:var(--txt)}
.rsbadge{font-family:ui-monospace,monospace;font-size:10px;border:1px solid;border-radius:4px;padding:0 4px}
.accel{font-family:ui-monospace,monospace;font-size:10px;color:#2FD08A;font-weight:700}
.accel.down{color:#F4607A}
.emrow{display:grid;grid-template-columns:64px 86px 60px 96px 1fr auto;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid var(--line);font-size:12px}
@media(max-width:600px){.emrow{grid-template-columns:1fr 1fr;gap:4px 10px}}
.em-sym{font-family:ui-monospace,monospace;font-weight:700;color:var(--txt)}
.em-sec{font-family:ui-monospace,monospace;color:var(--txt2);font-size:11px}
.em-rs{font-family:ui-monospace,monospace;color:var(--txt2)}
.em-drs{font-family:ui-monospace,monospace;font-weight:700}
.em-hi{font-family:ui-monospace,monospace;color:var(--txt3);font-size:11px}
.emtag{justify-self:end;font-size:9.5px;color:#0A0E17;background:#2FD08A;border-radius:4px;padding:1px 7px;font-weight:700;text-transform:uppercase;letter-spacing:.5px}
.wkrow{display:grid;grid-template-columns:78px 1fr auto auto auto auto;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid var(--line);font-size:12px}
@media(max-width:620px){.wkrow{grid-template-columns:1fr 1fr;gap:4px 10px}}
.wk-sym{font-family:ui-monospace,monospace;font-weight:700;color:var(--txt)}
.wk-name{color:var(--txt2);font-size:11px}
.wk-eur{font-family:ui-monospace,monospace;font-weight:700;color:#5B8CFF}
.wk-x3{font-family:ui-monospace,monospace;font-size:10px;color:#F4B740;background:rgba(244,183,64,.12);padding:1px 6px;border-radius:4px}
.wk-stk{font-family:ui-monospace,monospace;font-size:10.5px;color:var(--txt3)}
.wk-new{justify-self:end;font-size:9.5px;color:#0A0E17;background:#4CC2E0;border-radius:4px;padding:1px 7px;font-weight:700;letter-spacing:.5px}
.wk-keep{justify-self:end;font-size:9.5px;color:var(--txt3);border:1px solid var(--line);border-radius:4px;padding:1px 7px}
.fgrid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}
@media(max-width:680px){.fgrid{grid-template-columns:1fr}}
.fcol{background:var(--bg3);border:1px solid var(--line);border-radius:9px;padding:10px 12px}
.fhead{font-size:11px;font-weight:700;margin-bottom:8px;font-family:ui-monospace,monospace}
.fchips{display:flex;flex-wrap:wrap;gap:6px}
.fchip{display:inline-flex;align-items:center;gap:5px;border:1px solid var(--line);border-radius:6px;padding:3px 8px;font-size:11.5px;font-family:ui-monospace,monospace;font-weight:600;background:var(--bg2)}
.ring1{width:9px;height:9px;border-radius:50%;border:2px solid #2FD08A;display:inline-block;margin-right:2px}
.ring2{width:11px;height:11px;border-radius:50%;border:2px solid #F4607A;box-shadow:0 0 0 2px #F4607A;display:inline-block;margin-right:2px}
.hm{width:100%;border-collapse:separate;border-spacing:3px}
.hm-h{font-size:10px;color:var(--txt3);text-align:center;padding:4px 0;font-family:ui-monospace,monospace;text-transform:uppercase;letter-spacing:.5px;font-weight:600}
.hm-name{text-align:left;padding:6px 8px;font-size:12px;white-space:nowrap}
.hm-name b{font-family:ui-monospace,monospace}
.hm-name span{color:var(--txt3);font-size:11px}
.hm-c{text-align:center;font-family:ui-monospace,monospace;font-size:12px;font-weight:700;border-radius:5px;height:30px;width:18%}
.hm-turn{font-size:9.5px;color:#0A0E17;background:#4CC2E0;border-radius:4px;padding:1px 6px;font-weight:700;letter-spacing:.3px;margin-left:6px}
.sc{width:100%;border-collapse:separate;border-spacing:2px}
.sc-h{font-size:9.5px;color:var(--txt3);text-align:center;padding:4px 2px;font-family:ui-monospace,monospace;text-transform:uppercase;letter-spacing:.3px;font-weight:600}
.sc-name{text-align:left;padding:7px 8px;font-size:12px;white-space:nowrap;background:var(--bg3);border-radius:5px}
.sc-name b{font-family:ui-monospace,monospace}
.sc-name span{color:var(--txt3);font-size:11px}
.sc-c{text-align:center;font-size:14px;font-weight:700;background:var(--bg3);border-radius:5px}
.sc-tot{text-align:center;font-family:ui-monospace,monospace;font-weight:700;font-size:13px;background:var(--bg3);border-radius:5px}
.sc-act{text-align:center;font-size:11px;font-weight:700;background:var(--bg3);border-radius:5px;padding:0 6px}
.sc-acc{font-size:9px;color:#0A0E17;background:#F4B740;border-radius:4px;padding:1px 5px;font-weight:700;margin-left:6px}
.sc-warn{font-size:9px;color:#0A0E17;background:#F4607A;border-radius:4px;padding:1px 5px;font-weight:700;margin-left:6px}
.lbreadth{font-size:10px;border:1px solid;border-radius:5px;padding:1px 6px;margin-left:8px;font-weight:600}
.sc-grp,.rk-grp{background:#0E1521 !important;color:#5B8CFF;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;padding:8px 10px !important;text-align:left;border-top:2px solid #1C2740}
.fgwrap{display:flex;align-items:baseline;gap:14px;margin:2px 0 4px}
.fgnum{font-size:42px;font-weight:800;line-height:1}.fgnum span{font-size:15px;color:var(--txt3);font-weight:600}
.fgzone{font-size:17px;font-weight:700}
.fgbar{position:relative;height:10px;border-radius:6px;margin:8px 0 6px;background:linear-gradient(90deg,#F4607A,#F4824A,#F4B740,#7FC97F,#2FD08A)}
.fgmark{position:absolute;top:-3px;width:3px;height:16px;background:#fff;transform:translateX(-50%);border-radius:2px;box-shadow:0 0 3px #000}
.fgctx{display:flex;gap:8px;flex-wrap:wrap;margin:6px 0}
.fgchip{font-size:11px;color:var(--txt3);border:1px solid #1C2740;border-radius:6px;padding:2px 7px}
.verdict{border:1px solid #2B3850;background:linear-gradient(180deg,rgba(91,140,255,.06),var(--bg2))}
.vrow{display:flex;gap:10px;align-items:baseline;flex-wrap:wrap;padding:7px 0;border-bottom:1px solid #131C2B;font-size:14px;color:#C7D3E3;line-height:1.5}
.vrow:last-of-type{border-bottom:none}
.vk{flex:0 0 auto;font-size:10px;font-weight:700;color:#0A0E17;border-radius:5px;padding:2px 9px;letter-spacing:.3px}
details.why{grid-column:1/-1;margin-bottom:14px}
details.why[open]{display:grid;grid-template-columns:1.55fr 1fr;gap:14px}
@media(max-width:900px){details.why[open]{grid-template-columns:1fr}}
details.why>summary{grid-column:1/-1;cursor:pointer;list-style:none;background:var(--bg2);border:1px solid var(--line);border-radius:10px;padding:13px 15px;font-size:14px;font-weight:600;color:var(--txt1);user-select:none}
details.why>summary::-webkit-details-marker{display:none}
details.why>summary::before{content:'▸ ';color:#5B8CFF}
details.why>summary span{color:var(--txt3);font-weight:400;font-size:12px}
details.why[open]>summary{color:#5B8CFF}
details.why[open]>summary::before{content:'▾ '}
.readbox{display:flex;gap:12px;align-items:flex-start;background:var(--bg3);border:1px solid var(--line);border-radius:10px;padding:14px}
.read-light{width:14px;height:14px;border-radius:50%;flex:0 0 auto;margin-top:3px;box-shadow:0 0 12px currentColor}
.read-txt{font-size:13px;color:var(--txt);margin-bottom:6px}
.read-stance{font-size:12.5px;font-weight:700}
.pb{width:100%;border-collapse:separate;border-spacing:2px;margin-top:4px}
.pb th{font-size:10px;color:var(--txt3);text-transform:uppercase;letter-spacing:.3px;padding:4px 8px;text-align:right}
.pb .pb-l{text-align:left}
.pb td{background:var(--bg3);padding:7px 8px;font-size:12px}
.pb-l{text-align:left;border-radius:5px 0 0 5px}
.pb-v{text-align:right;font-family:ui-monospace,monospace;font-weight:700}
.pb-n{text-align:right;color:var(--txt3);font-size:11px;border-radius:0 5px 5px 0}
.cand{background:var(--bg3);border:1px solid var(--line);border-radius:9px;padding:10px 12px;margin-bottom:8px}
.cand-h{display:flex;align-items:center;gap:8px;font-size:13px;margin-bottom:4px}
.cand-h b{font-family:ui-monospace,monospace}
.cand-h span{color:var(--txt3);font-size:11px}
.cand-sc{margin-left:auto;font-family:ui-monospace,monospace;font-weight:700}
.cand-r{font-size:12px;color:var(--txt2);margin-bottom:2px}
.cand-p{font-size:12px;color:var(--txt)}
.se{width:100%;border-collapse:separate;border-spacing:2px}
.scrollx{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
.se th{font-size:10px;color:var(--txt3);text-transform:uppercase;letter-spacing:.3px;padding:4px 8px;text-align:center}
.se .se-l{text-align:left}
.se td{background:var(--bg3);padding:7px 8px;font-size:12px}
.se-l{text-align:left;border-radius:5px 0 0 5px;white-space:nowrap}
.se-c{text-align:center}
.se-pup{font-family:ui-monospace,monospace;font-weight:700;font-size:13px;display:block}
.se-avg{font-family:ui-monospace,monospace;font-size:10px;display:block;margin-top:1px}
.se-hi td{background:#1A2233}
.se-now{font-size:9px;color:#0A0E17;background:#5B8CFF;border-radius:4px;padding:1px 6px;font-weight:700;margin-left:8px}
.se-next{font-size:9px;color:#0A0E17;background:#2FD08A;border-radius:4px;padding:1px 6px;font-weight:700;margin-left:8px}
.bar-cmf{font-family:ui-monospace,monospace;font-size:10px;margin-left:8px;min-width:62px;text-align:right}
@media(max-width:640px){.sc-name span{display:none}.sc-h{font-size:8px}.sc-act{font-size:9px}}
@media(max-width:600px){.hm-name span{display:none}.hm-c{font-size:11px}}
footer{font-size:10.5px;color:var(--txt3);text-align:center;padding:18px 20px;max-width:760px;margin:0 auto;line-height:1.6}
"""

def render_svg(rrg, flow=None, quality=None):
    flow = flow or {}
    W, H = 1040, 720
    mL, mR, mT, mB = 60, 66, 28, 54
    pw, ph = W - mL - mR, H - mT - mB
    maxdev = 4.0
    for d in rrg.values():
        maxdev = max(maxdev, abs(d["ratio"] - 100), abs(d["mom"] - 100))
        for r, m in d["tail"]:
            maxdev = max(maxdev, abs(r - 100), abs(m - 100))
    r = max(6, min(18, math.ceil(maxdev) + 2))
    lo, hi = 100 - r, 100 + r
    X = lambda v: mL + (v - lo) / (hi - lo) * pw
    Y = lambda v: mT + (1 - (v - lo) / (hi - lo)) * ph
    cx, cy = X(100), Y(100)
    qof = lambda rr, mm: ("Lider" if rr >= 100 and mm >= 100 else "Debilitandose" if rr >= 100
                          else "Mejorando" if mm >= 100 else "Rezagado")
    s = [f'<svg viewBox="0 0 {W} {H}">']
    quads = [(cx, mT, mL + pw - cx, cy - mT, "#2FD08A"),
             (cx, cy, mL + pw - cx, mT + ph - cy, "#F4B740"),
             (mL, cy, cx - mL, mT + ph - cy, "#F4607A"),
             (mL, mT, cx - mL, cy - mT, "#4CC2E0")]
    for x, y, w, h, c in quads:
        s.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{c}" opacity="0.06"/>')
    for i in range(9):
        vx = lo + (hi - lo) * i / 8
        s.append(f'<line x1="{X(vx):.1f}" y1="{mT}" x2="{X(vx):.1f}" y2="{mT+ph}" stroke="#1E2A3D"/>')
    for i in range(7):
        vy = lo + (hi - lo) * i / 6
        s.append(f'<line x1="{mL}" y1="{Y(vy):.1f}" x2="{mL+pw}" y2="{Y(vy):.1f}" stroke="#1E2A3D"/>')
    s.append(f'<line x1="{cx:.1f}" y1="{mT}" x2="{cx:.1f}" y2="{mT+ph}" stroke="#2A3A52" stroke-width="1.5"/>')
    s.append(f'<line x1="{mL}" y1="{cy:.1f}" x2="{mL+pw}" y2="{cy:.1f}" stroke="#2A3A52" stroke-width="1.5"/>')
    corners = [(mL+pw-8, mT+17, "LIDER", "end", "#2FD08A"),
               (mL+pw-8, mT+ph-8, "DEBILITANDOSE", "end", "#F4B740"),
               (mL+8, mT+ph-8, "REZAGADO", "start", "#F4607A"),
               (mL+8, mT+17, "MEJORANDO", "start", "#4CC2E0")]
    for x, y, t, a, c in corners:
        s.append(f'<text x="{x}" y="{y}" fill="{c}" font-size="13" font-family="ui-monospace,monospace" '
                 f'text-anchor="{a}" opacity="0.7" letter-spacing="1">{t}</text>')
    s.append(f'<text x="{mL+pw/2:.0f}" y="{H-14}" fill="#5E708A" font-size="11" text-anchor="middle" '
             f'font-family="ui-monospace,monospace">RS-Ratio - fuerza relativa -></text>')
    s.append(f'<text x="16" y="{mT+ph/2:.0f}" fill="#5E708A" font-size="11" text-anchor="middle" '
             f'font-family="ui-monospace,monospace" transform="rotate(-90 16 {mT+ph/2:.0f})">RS-Momentum - impulso -></text>')
    labels = []
    for sym, d in rrg.items():
        col = QUAD[d["quad"]][1]
        tail = d["tail"]
        tdates = d.get("tail_dates", [""] * len(tail))
        nm = NAMES.get(sym, (sym, sym, ""))[1]
        # estela: linea con degradado + un PUNTO por semana (con fecha al pasar el raton)
        for i in range(1, len(tail)):
            a, b = tail[i-1], tail[i]
            op = 0.10 + 0.6 * (i / max(1, len(tail)-1))
            s.append(f'<line x1="{X(a[0]):.1f}" y1="{Y(a[1]):.1f}" x2="{X(b[0]):.1f}" y2="{Y(b[1]):.1f}" '
                     f'stroke="{col}" stroke-width="1.6" stroke-opacity="{op:.2f}" stroke-linecap="round"/>')
        for i in range(len(tail) - 1):   # semanas anteriores (no la actual)
            rr, mm = tail[i]
            op = 0.25 + 0.5 * (i / max(1, len(tail)-1))
            wk = tdates[i] if i < len(tdates) else ""
            info = f"{sym} · semana {wk} · {qof(rr, mm)} (fuerza {rr:.0f}, impulso {mm:.0f})"
            s.append(f'<circle cx="{X(rr):.1f}" cy="{Y(mm):.1f}" r="3" fill="{col}" fill-opacity="{op:.2f}" '
                     f'stroke="#0A0E17" stroke-width="0.5"/>'
                     f'<circle cx="{X(rr):.1f}" cy="{Y(mm):.1f}" r="9" fill="transparent" class="tdot" '
                     f'data-t="{esc(info)}" style="cursor:pointer"><title>{esc(info)}</title></circle>')
        lx, ly = X(d["ratio"]), Y(d["mom"])
        labels.append((sym, lx, ly, col, nm, d, tail))
    # anillos de FLUJO (verde = entra dinero / acumulacion; doble rojo = cuidado, distribucion oculta)
    def _rad(sym):
        if quality is not None and sym in quality:
            q = max(-1.0, min(8.0, quality[sym]))
            return 4.0 + (q + 1.0) / 9.0 * 7.0
        return 6.5
    for sym, lx, ly, col, nm, d, tail in labels:
        f = flow.get(sym, {})
        dv = f.get("diverg")
        lab = f.get("label")
        rr = _rad(sym)
        if dv == "distribucion oculta":
            s.append(f'<circle cx="{lx:.1f}" cy="{ly:.1f}" r="{rr+3:.1f}" fill="none" stroke="#F4607A" stroke-width="1.4"/>')
            s.append(f'<circle cx="{lx:.1f}" cy="{ly:.1f}" r="{rr+5.5:.1f}" fill="none" stroke="#F4607A" stroke-width="1.4" stroke-opacity="0.55"/>')
        elif dv == "acumulacion oculta":
            s.append(f'<circle cx="{lx:.1f}" cy="{ly:.1f}" r="{rr+3:.1f}" fill="none" stroke="#2FD08A" stroke-width="1.6"/>')
        elif lab == "Acumulacion":
            s.append(f'<circle cx="{lx:.1f}" cy="{ly:.1f}" r="{rr+3:.1f}" fill="none" stroke="#2FD08A" stroke-width="1.1" stroke-opacity="0.45"/>')
        elif lab == "Distribucion":
            s.append(f'<circle cx="{lx:.1f}" cy="{ly:.1f}" r="{rr+3:.1f}" fill="none" stroke="#F4607A" stroke-width="1.1" stroke-opacity="0.45"/>')
    # flecha de direccion + punto actual (en TODOS, brillante y encima)
    for sym, lx, ly, col, nm, d, tail in labels:
        if len(tail) >= 2:
            ax, ay = X(tail[-2][0]), Y(tail[-2][1])
            ang = math.atan2(ly - ay, lx - ax)
            if abs(lx - ax) > 0.3 or abs(ly - ay) > 0.3:
                tip = (lx + 13 * math.cos(ang), ly + 13 * math.sin(ang))
                b1 = (lx + 4 * math.cos(ang + 2.6), ly + 4 * math.sin(ang + 2.6))
                b2 = (lx + 4 * math.cos(ang - 2.6), ly + 4 * math.sin(ang - 2.6))
                s.append(f'<polygon points="{tip[0]:.1f},{tip[1]:.1f} {b1[0]:.1f},{b1[1]:.1f} {b2[0]:.1f},{b2[1]:.1f}" '
                         f'fill="{col}"/>')
        rel = d.get("rel4", 0)
        f = flow.get(sym, {})
        fl = ""
        if f.get("diverg") == "distribucion oculta":
            fl = " | ⚠ distribucion oculta (cuidado)"
        elif f.get("diverg") == "acumulacion oculta":
            fl = " | entra dinero (acumulacion oculta)"
        elif f.get("label"):
            fl = f" | flujo: {f['label']}"
        info = (f"{sym} · {nm} — {QUAD[d['quad']][0]} | fuerza {d['ratio']:.1f}, "
                f"impulso {d['mom']:.1f} | vs indice 4s {rel:+.1f}%{fl}")
        if quality is not None and sym in quality:
            rad = _rad(sym)
        else:
            rad = 6.5
        s.append(f'<circle cx="{lx:.1f}" cy="{ly:.1f}" r="{rad:.1f}" fill="{col}" stroke="#0A0E17" stroke-width="1.8" '
                 f'class="tdot" data-t="{esc(info)}" style="cursor:pointer"><title>{esc(info)}</title></circle>')
    # etiquetas: columna a cada lado + linea guia desde la bola a su nombre (sin ambiguedad)
    GAP = 14
    rightballs = sorted([l for l in labels if l[1] >= cx], key=lambda p: p[2])   # bolas en mitad derecha -> nombre a la derecha
    leftballs = sorted([l for l in labels if l[1] < cx], key=lambda p: p[2])     # bolas en mitad izquierda -> nombre a la izquierda

    def place(group, side):
        if not group:
            return
        xs = [lx for _, lx, _, _, _, _, _ in group]
        if side == "right":
            colx = min(W - 6, max(xs) + 18); anchor = "start"
        else:
            colx = max(6, min(xs) - 18); anchor = "end"
        tys = [p[2] for p in group]                  # deseado = altura de su bola
        for i in range(1, len(tys)):                 # separar hacia abajo
            if tys[i] - tys[i-1] < GAP:
                tys[i] = tys[i-1] + GAP
        over = tys[-1] - (mT + ph - 4)               # si se sale por abajo, subir todo
        if over > 0:
            tys = [t - over for t in tys]
        if tys[0] < mT + 10:                          # si se sale por arriba, bajar todo
            sh = (mT + 10) - tys[0]
            tys = [t + sh for t in tys]
        anchorx = colx - 2 if side == "right" else colx + 2
        for (sym, lx, ly, col, nm, d, tail), ty in zip(group, tys):
            s.append(f'<line x1="{lx:.1f}" y1="{ly:.1f}" x2="{anchorx:.1f}" y2="{ty-3:.1f}" '
                     f'stroke="{col}" stroke-width="0.7" stroke-opacity="0.55"/>')
            info = f"{sym} · {nm}"
            s.append(f'<text x="{colx:.1f}" y="{ty:.1f}" fill="#E6EDF6" font-size="11.5" text-anchor="{anchor}" '
                     f'font-family="ui-monospace,monospace" font-weight="600" class="tdot" data-t="{esc(info)}" '
                     f'style="cursor:pointer"><title>{esc(info)}</title>{sym}</text>')
    place(rightballs, "right")
    place(leftballs, "left")
    s.append("</svg>")
    return "".join(s)

def quadrant_grid(rrg):
    """Vista alternativa: cuatro cajas con los ETFs de cada cuadrante (sin solapes)."""
    order = ["leading", "weakening", "improving", "lagging"]
    titles = {"leading": "LIDER", "weakening": "DEBILITANDOSE", "improving": "MEJORANDO", "lagging": "REZAGADO"}
    buckets = {q: [] for q in order}
    for sym, d in rrg.items():
        buckets[d["quad"]].append((sym, d["mom"], d["ratio"]))
    for q in buckets:
        buckets[q].sort(key=lambda x: -x[1])
    cells = ""
    for q in order:
        col = QUAD[q][1]
        chips = ""
        for sym, mom, ratio in buckets[q]:
            nm = NAMES.get(sym, (sym, sym, ""))[1]
            chips += (f"<span class='qchip' style='border-color:{col}33' title='{esc(sym)} · {esc(nm)}'>"
                      f"<b style='color:{col}'>{sym}</b> <i>{ratio:.0f}/{mom:.0f}</i></span>")
        if not chips:
            chips = "<span class='qempty'>—</span>"
        cells += (f"<div class='qcell' style='border-top:2px solid {col}'>"
                  f"<div class='qhead' style='color:{col}'>{titles[q]} <span>{QUAD[q][2]}</span></div>"
                  f"<div class='qchips'>{chips}</div></div>")
    return f"<div class='qgrid'>{cells}</div>"

def esc(x):
    return str(x).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def _pm(v):
    if v is None:
        return "n/d"
    return f"{'+' if v >= 0 else ''}{v}%"

def equity_svg(dates, eq_s, eq_b):
    W, H = 900, 250
    mL, mR, mT, mB = 50, 16, 16, 28
    pw, ph = W - mL - mR, H - mT - mB
    allv = eq_s + eq_b
    lo, hi = min(allv), max(allv)
    rng = (hi - lo) or 1e-9
    n = len(eq_s)
    X = lambda i: mL + pw * i / max(1, n - 1)
    Y = lambda v: mT + ph * (1 - (v - lo) / rng)
    def poly(arr, col, w):
        pts = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(arr))
        return f'<polyline points="{pts}" fill="none" stroke="{col}" stroke-width="{w}" stroke-linejoin="round"/>'
    grid = []
    for g in range(5):
        v = lo + rng * g / 4
        y = Y(v)
        grid.append(f'<line x1="{mL}" y1="{y:.1f}" x2="{mL+pw}" y2="{y:.1f}" stroke="#1E2A3D"/>'
                    f'<text x="{mL-6}" y="{y+3:.1f}" fill="#5E708A" font-size="10" text-anchor="end" '
                    f'font-family="ui-monospace,monospace">{v:.2f}x</text>')
    return (f'<svg viewBox="0 0 {W} {H}" style="width:100%;height:auto">'
            + "".join(grid) + poly(eq_b, "#93A4BC", 1.6) + poly(eq_s, "#5B8CFF", 2.2)
            + f'<text x="{mL+pw}" y="{mT+10}" fill="#5B8CFF" font-size="11" text-anchor="end" '
              f'font-family="ui-monospace,monospace">Estrategia</text>'
            + f'<text x="{mL+pw}" y="{mT+24}" fill="#93A4BC" font-size="11" text-anchor="end" '
              f'font-family="ui-monospace,monospace">Comprar y mantener {BENCH}</text>'
            + "</svg>")

def build_html(df, rrg, alerts, breadth, risk, regime, buy, avoid, sources, fred, flow=None, bt=None,
               dd=None, dd_meta=None, plan=None, fx=None, long_src="", ai_text=None, leaders=None, leaders_n=0, bt2=None, heatmap=None, scores=None, probs=None, season=None, early=None, sector_breadth=None, meanrev=None, nq_close=None, fg_idx=None, spy_flow=None):
    rank = {"leading": 0, "weakening": 1, "improving": 2, "lagging": 3}
    ranked = sorted(rrg.items(), key=lambda kv: (rank[kv[1]["quad"]], -kv[1]["mom"]))
    last_date = df.index[-1].date()
    _dias = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
    _mes = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]
    last_lbl = f"{_dias[last_date.weekday()]} {last_date.day} {_mes[last_date.month-1]}"
    stale_days = (dt.date.today() - last_date).days
    src_summary = ", ".join(sorted(set(v for v in sources.values() if v not in ("—",))))

    # ranking enriquecido (sparkline RS + rendimiento relativo 4 semanas)
    def spark_svg(vals, color):
        if not vals or len(vals) < 2:
            return ""
        w, h = 78, 22
        lo, hi = min(vals), max(vals)
        rng = (hi - lo) or 1e-9
        pts = " ".join(f"{w*i/(len(vals)-1):.1f},{h-2-(h-4)*(v-lo)/rng:.1f}" for i, v in enumerate(vals))
        return (f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}" preserveAspectRatio="none">'
                f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="1.5" '
                f'stroke-linejoin="round" stroke-linecap="round"/></svg>')

    def _rk_row(sym, d):
        c = QUAD[d["quad"]][1]
        rcol = "#2FD08A" if d["rel4"] >= 0 else "#F4607A"
        rarrow = "+" if d["rel4"] >= 0 else ""
        veh = LEV3X.get(sym, "—")
        veh_html = f"<span class='veh3'>{veh}</span>" if veh and veh != "—" else "<span class='veh3 off'>—</span>"
        return (
            f'<tr><td class="tk" title="{esc(sym)} · {esc(NAMES.get(sym,("","",""))[1])}"><b>{sym}</b><em>{esc(NAMES.get(sym,("","",""))[1])}</em></td>'
            f'<td><span class="dot" style="background:{c}"></span>{QUAD[d["quad"]][0]}</td>'
            f'<td class="r">{d["ratio"]:.1f}</td><td class="r">{d["mom"]:.1f}</td>'
            f'<td class="r" style="color:{rcol}">{rarrow}{d["rel4"]:.1f}%</td>'
            f'<td>{veh_html}</td>'
            f'<td class="spk">{spark_svg(d["spark"], c)}</td></tr>')
    rows = []
    for g in GRUPO_ORDEN:
        grp = [(sym, d) for sym, d in ranked if GRUPO.get(sym) == g]
        if not grp:
            continue
        rows.append(f'<tr><td class="rk-grp" colspan="7">{GRUPO_NOMBRE.get(g, g)}</td></tr>')
        for sym, d in grp:
            rows.append(_rk_row(sym, d))
    table = ('<table><tr><th>Activo</th><th>Cuadrante</th><th class="r">Fuerza</th>'
             '<th class="r">Impulso</th><th class="r">vs idx 4s</th><th>x3</th><th>Tendencia RS</th></tr>'
             + "".join(rows) + "</table>")

    # alertas
    if alerts:
        al = "".join(f'<div class="alert a-{k}"><span class="atk">{s}</span><span class="atx">{esc(t)}</span></div>'
                     for s, k, t in alerts)
    else:
        al = '<div class="note">Sin giros relevantes en la ultima lectura. El liderazgo se mantiene estable.</div>'

    # barras de impulso
    mom_sorted = sorted(rrg.items(), key=lambda kv: -kv[1]["mom"])
    maxabs = max([6.0] + [abs(d["mom"] - 100) for _, d in mom_sorted])
    bars = []
    for sym, d in mom_sorted:
        v = d["mom"] - 100
        pct = abs(v) / maxabs * 50
        c = QUAD[d["quad"]][1]
        left = 50 if v >= 0 else 50 - pct
        bars.append(f'<div class="bar-row"><span class="bar-lab">{sym}</span>'
                    f'<div class="bar-track"><div class="bar-mid"></div>'
                    f'<div class="bar" style="background:{c};width:{pct:.1f}%;left:{left:.1f}%"></div></div>'
                    f'<span class="bar-val" style="color:{c}">{d["mom"]:.1f}</span></div>')

    def meter(label, val, good=50):
        col = "#2FD08A" if val >= good else "#F4B740" if val >= good - 15 else "#F4607A"
        return (f'<div class="meter"><div class="meter-top"><span>{label}</span><b style="color:{col}">{val}%</b></div>'
                f'<div class="meter-track"><div class="meter-fill" style="width:{val}%;background:{col}"></div></div></div>')

    # macro
    sig_rows = "".join(f'<div class="kv"><span>{esc(k)}</span><b>{("+" if (v is not None and v>=0) else "")}{v if v is not None else "n/d"}{"%" if k!="Apetito riesgo" and v is not None else ""}</b></div>'
                       for k, v in regime["sig"].items())
    favor = "".join(f'<span class="tag good">{s}</span>' for s in regime["favor"])
    hurt = "".join(f'<span class="tag bad">{s}</span>' for s in regime["hurt"])
    buy_t = "".join(f'<span class="tag good">{s}</span>' for s in buy) or '<em style="color:#5E708A">Ninguno ahora.</em>'
    avoid_t = "".join(f'<span class="tag bad">{s}</span>' for s in avoid) or '<em style="color:#5E708A">Ninguno ahora.</em>'

    fred_html = ""
    if fred:
        fr = "".join(f'<div class="kv"><span>{esc(k)}</span><b>{v["last"]} ({"+" if v["chg"]>=0 else ""}{v["chg"]} 13s)</b></div>'
                     for k, v in fred.items())
        fred_html = f'<div class="panel"><h2>Macro FRED (13 semanas)</h2>{fr}</div>'

    risk_cls = risk["label"].replace("-", "")

    html = []
    html.append("<!DOCTYPE html><html lang='es'><head><meta charset='utf-8'>")
    html.append("<meta name='viewport' content='width=device-width,initial-scale=1'>")
    html.append("<title>Rotacion - Smart-Money Flow Terminal</title>")
    html.append("<meta name='theme-color' content='#0A0E17'>")
    html.append("<link rel='manifest' href='manifest.webmanifest'>")
    html.append("<meta name='apple-mobile-web-app-capable' content='yes'>")
    html.append("<meta name='mobile-web-app-capable' content='yes'>")
    html.append("<meta name='apple-mobile-web-app-status-bar-style' content='black-translucent'>")
    html.append("<meta name='apple-mobile-web-app-title' content='Rotacion'>")
    html.append("<link rel='apple-touch-icon' href='icons/apple-touch-icon.png'>")
    html.append("<link rel='icon' href='icons/icon-192.png'>")
    html.append("<style>" + CSS + "</style></head><body>")
    html.append(
        "<header><div class='brand'><div><div class='title'>ROTACION</div>"
        "<div class='sub'>Smart-Money Flow Terminal</div></div></div>"
        f"<div class='status'><span class='pill RiskON' style='background:rgba(47,208,138,.12);color:#2FD08A'>DATOS REALES</span>"
        f"<span><b>Fuente</b>{esc(src_summary)}</span>"
        f"<span><b>Referencia</b>{BENCH}</span>"
        f"<span><b>Activos</b>{len(rrg)}</span>"
        f"<span><b>Ult. cierre</b>{last_lbl}</span>"
        + (f"<span class='pill' style='background:rgba(244,183,64,.15);color:#F4B740'>⚠ datos {stale_days}d atrás</span>" if stale_days >= 5 else "")
        + f"<span class='pill {risk_cls}'>{risk['label']}</span></div></header>")
    html.append("<main>")
    html.append(
        "<div class='viewtabs' style='position:sticky;top:0;z-index:60;background:var(--bg);padding:8px 0 6px;margin:-4px 0 6px;border-bottom:1px solid var(--line)'>"
        "<button class='viewtab mainview active' onclick=\"mainView('ctx',this)\" style='font-size:13px;padding:7px 16px'>📊 Contexto</button>"
        "<button class='viewtab mainview' onclick=\"mainView('op',this)\" style='font-size:13px;padding:7px 16px'>🎯 Operativa</button>"
        "</div>"
        "<div id='vista-ctx'>")
    # ---- barra-resumen de rotacion ----
    entering = [s for s, d in rrg.items() if d["quad"] == "improving"]
    leaving = [s for s, d in rrg.items() if d["quad"] == "weakening"]
    leadnow = [s for s, d in rrg.items() if d["quad"] == "leading"]
    flow_col = "#2FD08A" if risk["score"] > 1.5 else "#F4607A" if risk["score"] < -1.5 else "#93A4BC"
    def scard(lab, big, big_col, sm):
        return (f"<div class='scard'><div class='lab'>{lab}</div>"
                f"<div class='big' style='color:{big_col}'>{big}</div><div class='sm'>{sm}</div></div>")
    html.append("<div class='summary full'>"
                + scard("Sesgo de flujo", risk["label"], flow_col, f"{'+' if risk['score']>=0 else ''}{risk['score']} ciclicos vs defensivos")
                + scard("Entrando a liderazgo", str(len(entering)), "#4CC2E0", (", ".join(entering[:4]) or "—"))
                + scard("Perdiendo liderazgo", str(len(leaving)), "#F4B740", (", ".join(leaving[:4]) or "—"))
                + scard("Regimen macro", regime["label"].split(" / ")[0], "#5B8CFF", f"{len(leadnow)} sectores liderando")
                + "</div>")
    verdict_pos = len(html)                       # aqui se insertara el "Veredicto de hoy" (se construye mas abajo)
    light, stance, n_buy, bull, chosen = "#93A4BC", "—", 0, True, []

    # ---- PLAN DE LIQUIDEZ + CAIDAS DEL S&P 500 (fusionado) ----
    if plan or dd:
        left = ""
        if plan:
            ddc = "#F4607A" if plan["dd"] <= -5 else "#F4B740" if plan["dd"] <= -2 else "#2FD08A"
            idx_name = "S&amp;P 500" if "SP" in long_src.upper() or long_src in ("^SPX", "^GSPC") else long_src or "S&amp;P 500"
            rungs_html = ""
            for r in plan["rungs"]:
                veh = LEV3X.get("QQQ", "TQQQ")
                stt = ("<span style='color:#2FD08A'>ALCANZADA</span>" if r["hit"]
                       else f"<span style='color:#5E708A'>faltan {(r['thr'] + plan['dd']):.1f}%</span>")
                bcol = "#2FD08A" if r["hit"] else "#1E2A3D"
                rungs_html += (f"<div class='rung' style='border-left-color:{bcol}'>"
                               f"<span class='rk-thr'>−{r['thr']}%</span>"
                               f"<span class='rk-lvl'>{idx_name} ≤ {r['level']}</span>"
                               f"<span class='rk-pct'>desplegar {r['pct']}%</span>"
                               f"<span class='rk-veh'>{veh}</span>"
                               f"<span class='rk-st'>{stt}</span></div>")
            left = (f"<div class='dd-now'><div class='lab'>Caida actual del {idx_name} desde maximos</div>"
                    f"<div class='dd-big' style='color:{ddc}'>{plan['dd']:.1f}%</div>"
                    f"<div class='sm'>Maximo {plan['peak']} · ahora {plan['last']} · fuente {long_src}</div></div>"
                    + rungs_html)
        right = ""
        if dd:
            rows = ""
            for t in DD_THRESHOLDS:
                e = dd[t]
                ytdcol = "#F4B740" if e["ytd"] > 0 else "#5E708A"
                restcol = "#2FD08A" if e["rest"] >= 50 else "#F4B740" if e["rest"] >= 20 else "#9FB0C8"
                rows += (f"<tr><td class='r' style='color:#E6EDF6'>−{t:g}%</td>"
                         f"<td class='r'>{e['avg20']}</td><td class='r'>{e['avgfull']}</td>"
                         f"<td class='r' style='color:#5B8CFF'>{e['probfull']}%</td>"
                         f"<td class='r' style='color:{restcol}'>{e['rest']}%</td>"
                         f"<td class='r' style='color:{ytdcol}'>{e['ytd']}</td></tr>")
            meta = dd_meta or {}
            right = ("<table><tr><th>Caida</th><th class='r'>media/año<br>20a</th>"
                     "<th class='r'>media/año<br>histórico</th><th class='r'>prob. en<br>un año</th>"
                     "<th class='r'>prob. resto<br>del año</th>"
                     "<th class='r'>ya este<br>año</th></tr>" + rows + "</table>"
                     f"<div class='note' style='margin-top:6px'>Histórico {meta.get('start','?')}–{meta.get('end','?')} "
                     f"({long_src}, <b>{meta.get('basis','cierre')}</b>). «Prob. en un año» = % de años con al menos una caída de ese tamaño. "
                     "«Prob. resto del año» = % de años en que ocurrió una caída así <b>entre la fecha de hoy y fin de año</b>. "
                     "«Media/año» = nº de caídas de ese tamaño por año (un evento se cierra al recuperar la mitad). "
                     + ("<b>Intradía</b>: cuenta cuando el índice <b>tocó</b> ese nivel en algún momento del día (ahí suele haber compras y rebote), aunque cerrara más arriba."
                        if meta.get('basis') == 'intradía' else
                        "Medido sobre precios de <b>cierre</b>.")
                     + " <b>Método:</b> caída desde el <b>máximo histórico</b> (más estricto que «desde cualquier pico reciente»). "
                       "Consenso de mercado verificado: un <b>−10%</b> ocurre ≈<b>1 vez/año</b> y un <b>−20%</b> ≈<b>1 vez cada 5-6 años</b> "
                       "(13 desde 1950) — tus cifras encajan. El típico «−5% tres veces al año» mide pullbacks desde cualquier pico, "
                       "no desde máximos, por eso aquí el −5% sale más bajo. Son frecuencias históricas, no predicción.</div>")
        html.append("<div class='panel full'><h2>Plan de liquidez y caídas del S&amp;P 500</h2>"
                    "<div class='note'>Guía de entrada escalonada según la caída del S&amp;P desde máximos, junto a la "
                    "frecuencia histórica de caídas. Los porcentajes de despliegue se editan arriba del archivo (CASH_PLAN).</div>"
                    "<div class='planwrap'><div class='planladder'>" + left + "</div>"
                    "<div class='planstats'>" + right + "</div></div>"
                    "<div class='note' style='margin-top:8px;color:#F4607A'>⚠ Los productos apalancados x3 (TQQQ y similares) se reajustan "
                    "a diario, sufren desgaste por volatilidad y pueden caer mucho más que el índice (TQQQ perdió ~80% en 2022). "
                    "No son para mantener en mercados laterales. El mercado puede seguir cayendo más allá del −20%. No es asesoramiento.</div></div>")

    # ---- LECTURA DEL MERCADO Y PROBABILIDADES (fusion de todo) ----
    if scores and probs:
        spy = df[BENCH]
        bull = bool(spy.iloc[-1] > spy.rolling(min(40, len(spy))).mean().iloc[-1])
        st = probs["stats"]; fwd = probs["fwd"]
        lite = lambda r: sum(1 for _, v in r["parts"][:3] if v)
        buy = [r for r in scores if r["score"] >= 4]
        n_buy = len(buy)
        if not bull:
            light, stance = "#F4607A", "ROJO — el S&P está por debajo de su media de 40 semanas: el filtro de tendencia recomienda prudencia (liquidez o defensivos)."
        elif n_buy >= 5:
            light, stance = "#2FD08A", "VERDE — mercado alcista y varias oportunidades de alta puntuación: entorno favorable para invertir, siendo selectivo."
        elif n_buy >= 2:
            light, stance = "#F4B740", "ÁMBAR-VERDE — mercado alcista pero selectivo: hay oportunidades, aunque pocas y concentradas."
        else:
            light, stance = "#F4B740", "ÁMBAR — mercado alcista pero sin señales fuertes claras esta semana: mejor paciencia."
        read = (f"Régimen <b>{esc(regime['label'])}</b>, apetito de riesgo <b>{esc(risk['label'])}</b>, "
                f"tendencia del mercado <b>{'alcista' if bull else 'bajista'}</b>. "
                f"<b>{n_buy}</b> ETF con puntuación de compra (4–5/5) esta semana.")
        # tabla de probabilidades base (historica)
        prob_rows = ""
        for sc in [3, 2, 1, 0]:
            d = st.get(sc, {})
            if d.get("pup") is None:
                continue
            pcol = "#2FD08A" if d["pup"] >= 60 else "#F4B740" if d["pup"] >= 50 else "#F4607A"
            acol = "#2FD08A" if d["avg"] >= 0 else "#F4607A"
            prob_rows += (f"<tr><td class='pb-l'><b>{sc}/3</b> señales estructurales</td>"
                          f"<td class='pb-v' style='color:{pcol}'>{d['pup']}%</td>"
                          f"<td class='pb-v' style='color:{acol}'>{d['avg']:+.1f}%</td>"
                          f"<td class='pb-n'>{d['n']} casos</td></tr>")
        # candidatos listos con motivos + probabilidad
        cand = ""
        for r in buy[:8]:
            ls = lite(r); bd = st.get(ls, {})
            reasons = ", ".join(name for name, v in r["parts"] if v)
            prob_txt = (f"<b style='color:{'#2FD08A' if bd['pup']>=55 else '#F4B740'}'>{bd['pup']}%</b> histórico de subir en {fwd} sem (media {bd['avg']:+.1f}%)"
                        if bd.get("pup") is not None else "—")
            nm = NAMES.get(r["sym"], (r["sym"], r["sym"], ""))[1]
            acc = " <span class='sc-acc'>⚡</span>" if r["obv_cross"] else ""
            cand += (f"<div class='cand'><div class='cand-h'><b>{r['sym']}</b> <span>{esc(nm)}</span>"
                     f"<span class='cand-sc' style='color:{'#2FD08A' if r['score']>=4 else '#F4B740'}'>{r['score']}/5</span>{acc}</div>"
                     f"<div class='cand-r'>Listo para la semana que viene porque: {esc(reasons)}.</div>"
                     f"<div class='cand-p'>Probabilidad: {prob_txt}.</div></div>")
        # ---- FEAR & GREED de CNN (sentimiento contrario) ----
        if fg_idx:
            sc = fg_idx["score"]
            if sc < 25:
                zona, col = "Miedo extremo", "#F4607A"
            elif sc < 45:
                zona, col = "Miedo", "#F4824A"
            elif sc <= 55:
                zona, col = "Neutral", "#F4B740"
            elif sc <= 74:
                zona, col = "Codicia", "#7FC97F"
            else:
                zona, col = "Codicia extrema", "#2FD08A"
            if sc >= 75:
                lect = "Sentimiento eufórico — históricamente <b>peor</b> momento para añadir riesgo. Encaja con tu pólvora seca: cautela."
            elif sc < 25:
                lect = "Pánico — históricamente de las <b>mejores</b> ventanas de entrada (pero no es señal de timing: puede caer más). Es cuando tu plan de liquidez entra en juego."
            else:
                lect = "Sentimiento intermedio, sin extremo contrario claro."
            def _fgchip(lbl, v):
                return f"<span class='fgchip'>{lbl}: <b>{v if v is not None else '—'}</b></span>"
            html.append("<div class='panel full'><h2>Fear &amp; Greed (CNN)</h2>"
                        f"<div class='fgwrap'><div class='fgnum' style='color:{col}'>{sc}<span>/100</span></div>"
                        f"<div class='fgzone' style='color:{col}'>{esc(zona)}</div></div>"
                        f"<div class='fgbar'><div class='fgmark' style='left:{sc}%'></div></div>"
                        f"<div class='fgctx'>{_fgchip('ayer', fg_idx['prev'])}{_fgchip('hace 1 sem', fg_idx['week'])}"
                        f"{_fgchip('hace 1 mes', fg_idx['month'])}{_fgchip('hace 1 año', fg_idx['year'])}</div>"
                        f"<div class='note'>{lect} Es un indicador <b>contrario</b>: mide la emoción del mercado "
                        "(0 = pánico, 100 = euforia), no su dirección. Fuente: CNN. No es asesoramiento.</div></div>")
        else:
            html.append("<div class='panel full'><h2>Fear &amp; Greed (CNN)</h2>"
                        "<div class='note'>⚠ <b>F&amp;G no disponible</b> ahora mismo: CNN no ha devuelto el dato "
                        "(puede ser un fallo temporal de su servidor o de red). El resto del panel no se ve afectado; "
                        "vuelve a ejecutar más tarde y reaparecerá. No es asesoramiento.</div></div>")

        # ===== TERMOMETRO DEL MERCADO — SPY (entra o sale dinero) =====
        try:
            if spy_flow:
                sf = spy_flow
                spy = df[BENCH].dropna()
                sma40 = spy.rolling(40).mean()
                trend_up = bool(spy.iloc[-1] > sma40.iloc[-1]) if sma40.notna().any() else None
                mom3 = ((spy.iloc[-1] / spy.iloc[-14] - 1) * 100) if len(spy) > 14 else None
                obv_ok = bool(sf.get("obv_above")); cmf = sf.get("cmf", 0.0) or 0.0
                cmf_pos = bool(sf.get("cmf_pos")); diverg = bool(sf.get("diverg"))
                if diverg:
                    verd, vcol = "⚠ Distribución oculta: el precio sube pero el dinero SALE", "#F4607A"
                elif obv_ok and cmf_pos:
                    verd, vcol = "Dinero ENTRANDO en el mercado (acumulación)", "#2FD08A"
                elif (not obv_ok) and cmf < 0:
                    verd, vcol = "Dinero SALIENDO del mercado (distribución)", "#F4607A"
                else:
                    verd, vcol = "Flujo mixto / sin señal clara", "#F4B740"
                def _yn(b, t, f):
                    return (f"<b style='color:#2FD08A'>{t}</b>" if b else f"<b style='color:#F4607A'>{f}</b>")
                obv_txt = _yn(obv_ok, "por encima de su media (acumula)", "por debajo (distribuye)")
                cmf_col = "#2FD08A" if cmf > 0 else "#F4607A"
                cmf_txt = f"<span style='color:{cmf_col}'>{cmf:+.3f} ({'compra' if cmf > 0 else 'venta'})</span>"
                div_txt = "⚠ <b style='color:#F4607A'>sí</b>" if diverg else "<span style='color:#2FD08A'>no</span>"
                rows = (f"<tr><td class='se-l'>OBV (volumen acumulado)</td><td class='r'>{obv_txt}</td></tr>"
                        f"<tr><td class='se-l'>CMF (dinero neto, Chaikin)</td><td class='r'>{cmf_txt}</td></tr>"
                        f"<tr><td class='se-l'>Distribución oculta</td><td class='r'>{div_txt}</td></tr>")
                if trend_up is not None:
                    rows += f"<tr><td class='se-l'>Tendencia (precio vs media 40s)</td><td class='r'>{_yn(trend_up, 'alcista', 'bajista')}</td></tr>"
                if mom3 is not None:
                    mcol = "#2FD08A" if mom3 > 0 else "#F4607A"
                    rows += f"<tr><td class='se-l'>Momentum 3 meses</td><td class='r' style='color:{mcol}'>{mom3:+.1f}%</td></tr>"
                if sf.get("vol_break"):
                    rows += "<tr><td class='se-l'>Volumen</td><td class='r' style='color:#2FD08A'>ruptura al alza con volumen</td></tr>"
                html.append(
                    "<div class='panel full'><h2>Termómetro del mercado — ¿entra o sale dinero del SPY?</h2>"
                    f"<div class='readbox' style='border-color:{vcol}55'><div class='read-light' style='background:{vcol}'></div>"
                    f"<div><div class='read-txt'>{verd}</div><div class='read-stance' style='color:{vcol}'>SPY = el mercado entero (el centro del RRG)</div></div></div>"
                    "<div class='scrollx' style='margin-top:10px'><table class='se'><tr><th class='se-l'>señal</th><th class='r'>lectura</th></tr>"
                    + rows + "</table></div>"
                    "<div class='note' style='margin-top:8px'>Es el <b>flujo absoluto del propio SPY</b> (no relativo): la <b>marea</b> del mercado entero. "
                    "Como SPY es el centro del RRG, su dinero no se ve ahí, por eso va aquí. "
                    "<b>Distribución oculta</b> (el precio sube pero OBV/CMF caen) es el aviso más útil: el mercado sube pero el dinero se va. No es asesoramiento.</div></div>")
        except Exception:
            pass

        html.append("<div class='panel full'><h2>Lectura del mercado y probabilidades</h2>"
                    f"<div class='readbox' style='border-color:{light}55'><div class='read-light' style='background:{light}'></div>"
                    f"<div><div class='read-txt'>{read}</div><div class='read-stance' style='color:{light}'>{stance}</div></div></div>"
                    "<div class='note' style='margin-top:12px'><b>Probabilidades históricas</b> (base, no predicción): de todas las veces que un ETF "
                    "cumplía N de las 3 señales estructurales (<b>precio &gt; media 40s</b>, <b>RS subiendo</b>, <b>gana dinero a 3m</b>), "
                    f"qué % de veces estaba más arriba <b>{fwd} semanas después</b> y cuánto de media. Calculado sobre {probs['weeks']} semanas de tu propio histórico.</div>"
                    f"<table class='pb'><tr><th class='pb-l'></th><th class='pb-v'>prob. subir</th><th class='pb-v'>media {fwd}s</th><th class='pb-n'>muestra</th></tr>{prob_rows}</table>"
                    + (f"<div class='note' style='margin:12px 0 6px'><b>Listos para invertir la semana que viene</b> (puntuación 4–5/5), con el porqué y su probabilidad histórica:</div>{cand}" if cand else "")
                    + "<div class='note' style='margin-top:10px;color:#F4B740'>⚠ Son <b>frecuencias históricas sobre una muestra corta</b> (~"
                    f"{probs['weeks']} semanas), no una predicción. Como el póker: tener buena mano sube las probabilidades, no garantiza ganar la mano. No es asesoramiento.</div></div>")

    # ---- ESTACIONALIDAD (media-quincena: S&P, Nasdaq, Russell) ----
    if season:
        idx_names = list(season.keys())
        base_rows = season[idx_names[0]]["rows"]
        def se_cell(st):
            if not st or st.get("pup") is None:
                return "<td class='se-c' style='color:#3A4658'>—</td>"
            pcol = "#2FD08A" if st["pup"] >= 60 else "#F4B740" if st["pup"] >= 50 else "#F4607A"
            acol = "#9FB0C8" if st["avg"] is None else ("#7FE0B0" if st["avg"] >= 0 else "#F49AAC")
            return (f"<td class='se-c'><span class='se-pup' style='color:{pcol}'>{st['pup']}%</span>"
                    f"<span class='se-avg' style='color:{acol}'>{st['avg']:+.2f}%</span></td>")
        head = "".join(f"<th class='se-c'>{esc(n)}</th>" for n in idx_names)
        body = ""
        for i, base in enumerate(base_rows):
            tag = "<span class='se-now'>ahora</span>" if i == 0 else ("<span class='se-next'>próxima</span>" if i == 1 else "")
            cells = "".join(se_cell(season[n]["rows"][i] if i < len(season[n]["rows"]) else None) for n in idx_names)
            rowcls = " class='se-hi'" if i <= 1 else ""
            body += f"<tr{rowcls}><td class='se-l'>{base['label']}{tag}</td>{cells}</tr>"
        yrs = " · ".join(f"{n} {season[n]['years']}a" for n in idx_names)
        html.append("<div class='panel full'><h2>Estacionalidad por media-quincena (S&P · Nasdaq · Russell)</h2>"
                    "<div class='note'>De cada media-quincena (1ª mitad = días 1–15, 2ª = 16–fin), <b>% de años que cerró en positivo</b> "
                    "y <b>retorno medio</b>, para los tres índices. <b style='color:#2FD08A'>Verde</b> = quincena históricamente alcista; "
                    "<b style='color:#F4607A'>rojo</b> = floja. Es un <b>viento de fondo</b> probabilístico, no una señal de entrada. "
                    f"Histórico: {yrs}.</div>"
                    f"<table class='se'><tr><th class='se-l'></th>{head}</tr>{body}</table>"
                    "<div class='note' style='margin-top:8px'>El Russell (small caps) y el Nasdaq suelen tener su patrón propio "
                    "(p. ej. fuerza de fin de año en small caps). Por eso conviene mirar el índice del activo que vas a tocar.</div></div>")

    # ---- PUNTUACION (SCORING): el entregable de 5 minutos ----
    if scores:
        def sc_col(sc):
            return "#2FD08A" if sc >= 4 else "#F4B740" if sc == 3 else "#F4607A"
        def sc_act(sc):
            return ("comprar" if sc >= 4 else "vigilar" if sc == 3 else "evitar / vender")
        labels = [p[0] for p in scores[0]["parts"]]
        head = "".join(f"<th class='sc-h'>{l}</th>" for l in labels)
        body = ""
        ncols = 1 + len(labels) + 2
        def _sc_row(r):
            cells = ""
            for _, v in r["parts"]:
                cells += (f"<td class='sc-c' style='color:{'#2FD08A' if v else '#5E708A'}'>{'✓' if v else '·'}</td>")
            nm = NAMES.get(r["sym"], (r["sym"], r["sym"], ""))[1]
            cross = "<span class='sc-acc' title='OBV cruzó su media esta semana: presión compradora acelerando'>⚡ acelera</span>" if r["obv_cross"] else ""
            warn = "<span class='sc-warn' title='precio sube pero el dinero sale: distribución oculta'>⚠ distribución</span>" if r.get("distrib") else ""
            col = sc_col(r["score"])
            return (f"<tr><td class='sc-name'><b>{r['sym']}</b> <span>{esc(nm)}</span>{cross}{warn}</td>{cells}"
                    f"<td class='sc-tot' style='color:{col}'>{r['score']}/5</td>"
                    f"<td class='sc-act' style='color:{col}'>{sc_act(r['score'])}</td></tr>")
        for g in GRUPO_ORDEN:
            grp_rows = [r for r in scores if GRUPO.get(r["sym"]) == g]
            if not grp_rows:
                continue
            body += f"<tr><td class='sc-grp' colspan='{ncols}'>{GRUPO_NOMBRE.get(g, g)}</td></tr>"
            for r in grp_rows:
                body += _sc_row(r)
        html.append("<div class='panel full'><h2>Puntuación (scoring) — decide en 5 minutos</h2>"
                    "<div class='note'>Cada ETF suma 1 punto por: <b>precio &gt; su media de 40 semanas</b>, "
                    "<b>RS subiendo</b> (vs S&P), <b>momentum absoluto 3m &gt; 0</b> (gana dinero de verdad), "
                    "<b>OBV por encima de su media</b> y <b>CMF &gt; 0</b> (entra dinero). Ordenado de mayor a menor. "
                    "Regla simple: entra en los <b>4–5/5</b>, vende los que bajen a <b>≤2/5</b>. "
                    "El <b>⚡ acelera</b> marca que el OBV acaba de cruzar su media (entrada temprana). No es asesoramiento.</div>"
                    f"<table class='sc'><tr><th class='sc-name'></th>{head}<th class='sc-h'>total</th><th class='sc-h'>acción</th></tr>{body}</table></div>")

    # ---- CARTERA DE LA SEMANA (Lider + Mejorando + momentum absoluto positivo) ----
    _ord = {"leading": 0, "improving": 1}
    _cart_universe = set(SECTORS + THEMATIC + EXTRA)   # la cartera rota sectores/tematicos, no satelites (IWM, TLT, GLD, UUP, HYG)
    chosen_all = [(s, d) for s, d in rrg.items() if d["quad"] in ("leading", "improving") and s in _cart_universe]

    def _abs_mom_sym(sym):
        # momentum absoluto 3m (13 semanas) calculado directamente del precio (vale para satelites)
        if sym not in df.columns:
            return None
        s = df[sym].dropna()
        if len(s) < 14:
            return None
        n = min(13, len(s) - 1)
        return float(s.iloc[-1] / s.iloc[-1 - n] - 1)

    excluded_dm = []
    if CARTERA_DUAL_MOMENTUM:
        keep = []
        for s, d in chosen_all:
            am = _abs_mom_sym(s)
            if am is None or am > 0:        # si no se puede medir, NO se excluye por esto
                keep.append((s, d))
            else:
                excluded_dm.append(s)
        chosen = keep
    else:
        chosen = chosen_all
    # alinear con el scoring: fuera lo que el scoring suspende (< CARTERA_SCORE_MIN) y SIEMPRE la distribución oculta
    excluded_sc, excluded_di = [], []
    if scores:
        sc_map = {r["sym"]: r["score"] for r in scores}
        distrib_set = {r["sym"] for r in scores if r.get("distrib")}
        keep = []
        for s, d in chosen:
            if s in distrib_set:                         # distribución oculta: el dinero sale -> nunca entra (arregla la paradoja ITB)
                excluded_di.append(s)
            elif CARTERA_SCORE_MIN and sc_map.get(s, 0) < CARTERA_SCORE_MIN:
                excluded_sc.append(s)
            else:
                keep.append((s, d))
        chosen = keep
    chosen.sort(key=lambda sd: (_ord.get(sd[1]["quad"], 9), -sd[1]["mom"]))

    def _prev_quad(d):
        rs = d.get("ratio_series") or []
        ms = d.get("mom_series") or []
        if len(rs) >= 2 and rs[-2] is not None and ms[-2] is not None and rs[-2] == rs[-2] and ms[-2] == ms[-2]:
            return quad_of(rs[-2], ms[-2])
        return None

    n_wk = len(chosen)
    if n_wk:
        # estado del mercado para el filtro de tendencia
        spy_w = df[BENCH]
        spy_ma = float(spy_w.rolling(min(TREND_MA_WEEKS, len(spy_w)), min_periods=5).mean().iloc[-1])
        bull = spy_w.iloc[-1] >= spy_ma
        wvol = {s: df[s].pct_change().rolling(13, min_periods=4).std().iloc[-1] for s in rrg}

        def _weights(syms):
            w = {}
            for s in syms:
                if PESO == "volatilidad":
                    v = wvol.get(s)
                    w[s] = 1.0 / (v if v and v == v and v > 1e-6 else 0.02)
                elif PESO == "impulso":
                    w[s] = max(0.1, (rrg[s]["mom"] or 100) - 99)
                else:
                    w[s] = 1.0
            tot = sum(w.values()) or 1.0
            return {s: w[s] / tot for s in syms}

        def _cartera_block(keep):
            sel = [(s, d) for s, d in chosen if keep(s)]
            sel.sort(key=lambda sd: -(sd[1]["mom"] or 0))
            if MAX_POSICIONES and len(sel) > MAX_POSICIONES:
                sel = sel[:MAX_POSICIONES]
            n = len(sel)
            if not n:
                return "<div class='note'>Nada en Líder/Mejorando esta semana.</div>"
            w = _weights([s for s, _ in sel])
            rows = ""
            for s, d in sel:
                col = QUAD[d["quad"]][1]
                nm = NAMES.get(s, (s, s, ""))[1]
                eur = CARTERA_CAPITAL * w[s]
                veh = LEV3X.get(s, "—")
                veh_h = f"<span class='wk-x3'>x3 {veh}</span>" if veh and veh != "—" else ""
                top = TOP_HOLDING.get(s, "")
                top_h = f"<span class='wk-stk' title='accion lider (orientativo)'>lider: {esc(top)}</span>" if top else ""
                isnew = _prev_quad(d) not in ("leading", "improving")
                tag = "<span class='wk-new'>NUEVO</span>" if isnew else "<span class='wk-keep'>mantener</span>"
                rows += (f"<div class='wkrow'><span class='wk-sym'><span class='dot' style='background:{col}'></span>{s}</span>"
                         f"<span class='wk-name'>{esc(nm)} · {QUAD[d['quad']][0]}</span>"
                         f"<span class='wk-eur'>{eur:,.0f} €</span>{veh_h}{top_h}{tag}</div>")
            ex = [s for s, d in rrg.items() if keep(s) and d["quad"] not in ("leading", "improving") and _prev_quad(d) in ("leading", "improving")]
            ex_h = (f"<div class='note' style='margin-top:10px;color:#F4607A'><b>Salen esta semana (vender):</b> {', '.join(ex)}</div>" if ex else "")
            pesotxt = {"volatilidad": "ponderado por volatilidad inversa", "impulso": "ponderado por impulso", "igual": "a partes iguales"}[PESO]
            head = f"<div class='note' style='margin-bottom:8px'><b>{n}</b> posiciones (tope {MAX_POSICIONES or '∞'}, {pesotxt})</div>"
            return head + rows + ex_h

        bull_banner = ("<div class='note' style='margin-bottom:10px;padding:8px 12px;border-radius:8px;background:rgba(47,208,138,.1);color:#2FD08A'>"
                       "✓ <b>Mercado alcista</b> (S&P por encima de su media de 40 semanas): la estrategia invierte.</div>"
                       if bull else
                       "<div class='note' style='margin-bottom:10px;padding:8px 12px;border-radius:8px;background:rgba(244,96,122,.12);color:#F4607A'>"
                       "⚠ <b>Mercado bajista</b> (S&P por debajo de su media de 40 semanas): el filtro de tendencia recomienda "
                       "<b>liquidez / defensivo</b>. Las posiciones de abajo son orientativas; el backtest estaría en liquidez.</div>")

        sec_html = _cartera_block(lambda s: s in SECTORS)
        all_html = _cartera_block(lambda s: True)
        dm_note = ""
        if excluded_dm:
            dm_note = ("<div class='note' style='margin-top:8px;color:#F4B740'>⚠ <b>Excluidos por momentum absoluto negativo</b> "
                       "(suben respecto al S&P pero <b>pierden dinero</b> en términos absolutos, así que no se entra): "
                       + ", ".join(excluded_dm) + ".</div>")
        if excluded_di:
            dm_note += ("<div class='note' style='margin-top:8px;color:#F4607A'>⚠ <b>Excluidos por distribución oculta</b> "
                        "(el precio sube pero el dinero sale; no se entra aunque roten al alza): " + ", ".join(excluded_di) + ".</div>")
        if excluded_sc:
            dm_note += ("<div class='note' style='margin-top:8px;color:#F4B740'>⚠ <b>Excluidos por puntuación &lt; "
                        f"{CARTERA_SCORE_MIN}/5</b> (el scoring los marca como «evitar», para que cartera y scoring no se contradigan): "
                        + ", ".join(excluded_sc) + ".</div>")
        html.append("<div class='panel full'><h2>Cartera de la semana (rotación)</h2>"
                    + bull_banner +
                    f"<div class='note'>Reparto de <b>{CARTERA_CAPITAL:,.0f} €</b> entre lo más fuerte en "
                    "<b>Líder o Mejorando</b>, con las optimizaciones activas: <b>filtro de tendencia</b> (solo invierte en "
                    f"mercado alcista), <b>doble momentum</b> (exige también que gane dinero en absoluto), <b>tope de {MAX_POSICIONES or '∞'} posiciones</b> por impulso "
                    "y <b>peso por volatilidad</b>. <b>Solo sectores</b> = menos comisiones; "
                    "<b>Todos</b> incluye temáticos. Importe editable en CARTERA_CAPITAL.</div>"
                    + dm_note +
                    "<div class='viewtabs'>"
                    "<button class='viewtab cartab active' onclick=\"carView('sec',this)\">Solo sectores</button>"
                    "<button class='viewtab cartab' onclick=\"carView('all',this)\">Todos</button>"
                    "</div>"
                    "<div id='car-sec'>" + sec_html + "</div>"
                    "<div id='car-all' style='display:none'>" + all_html + "</div>"
                    "<script>function carView(v,b){document.getElementById('car-sec').style.display=(v=='sec')?'block':'none';"
                    "document.getElementById('car-all').style.display=(v=='all')?'block':'none';"
                    "document.querySelectorAll('.cartab').forEach(function(x){x.classList.remove('active')});b.classList.add('active');}</script>"
                    "<div class='note' style='margin-top:10px'>Rutina: <b>decides en el cierre del viernes y ejecutas el lunes</b>; "
                    "aguantas la semana y solo tocas lo que cambia (NUEVO / salen). No es asesoramiento.</div></div>")

    # ---- SEGUIMIENTO SEMANAL DEL SISTEMA (track record real, semana a semana + acumulado) ----
    basket = [s for s, d in chosen]
    tperf = None
    if basket:
        try:
            px_now = {k: float(v) for k, v in df.iloc[-1].to_dict().items() if v == v}
            px_now["SPY"] = float(df[BENCH].iloc[-1])
            if "IWM" in df.columns:
                px_now["IWM"] = float(df["IWM"].iloc[-1])
            if nq_close is not None and len(nq_close):
                px_now["QQQ"] = float(nq_close.iloc[-1])
            recs = update_track_record(basket, px_now, str(df.index[-1].date()))
            tperf = compute_track_perf(recs)
        except Exception:
            tperf = None
    if tperf:
        def _pct(x):
            return f"{x*100:+.1f}%"
        def _cc(x):
            return "#2FD08A" if x >= 0 else "#F4607A"
        bn = ("SPY", "QQQ", "IWM")
        cum = tperf["cum"]
        has_ew = "ew" in cum and any(w.get("ew") is not None for w in tperf["weeks"])
        rows = ""
        for w in tperf["weeks"][-10:]:
            beat = w["sys"] - w["bench"].get("SPY", 0.0)
            bcells = ""
            for b in bn:
                rb = w["bench"].get(b)
                bcells += (f"<td class='r' style='color:{_cc(rb)}'>{_pct(rb)}</td>" if rb is not None else "<td class='r' style='color:#5E708A'>—</td>")
            ew = w.get("ew")
            ewcell = (f"<td class='r' style='color:{_cc(ew)}'>{_pct(ew)}</td>" if ew is not None else "<td class='r' style='color:#5E708A'>—</td>") if has_ew else ""
            rows += (f"<tr><td class='se-l'>{w['week']}</td>"
                     f"<td class='r' style='color:{_cc(w['sys'])};font-weight:700'>{_pct(w['sys'])}</td>{ewcell}{bcells}"
                     f"<td class='r' style='color:{_cc(beat)}'>{_pct(beat)}</td></tr>")
        cumcells = "".join(f"<td class='r' style='color:{_cc(cum.get(b,0))};font-weight:700'>{_pct(cum.get(b,0))}</td>" for b in bn)
        ewcum = cum.get("ew", 0.0)
        ewcumcell = (f"<td class='r' style='color:{_cc(ewcum)};font-weight:700'>{_pct(ewcum)}</td>") if has_ew else ""
        beat_cum = cum["sys"] - cum.get("SPY", 0.0)
        beat_ew = cum["sys"] - ewcum
        cumrow = (f"<tr style='border-top:2px solid #1C2740'><td class='se-l'><b>ACUMULADO ({tperf['n']} sem)</b></td>"
                  f"<td class='r' style='color:{_cc(cum['sys'])};font-weight:800'>{_pct(cum['sys'])}</td>{ewcumcell}{cumcells}"
                  f"<td class='r' style='color:{_cc(beat_cum)};font-weight:700'>{_pct(beat_cum)}</td></tr>")
        ewth = "<th class='r'>sect.EW</th>" if has_ew else ""
        verdict = (f"bate al S&P por {_pct(beat_cum)}" if beat_cum >= 0 else f"por debajo del S&P ({_pct(beat_cum)})")
        ewphrase = ""
        if has_ew:
            ewverd = (f"<b style='color:#2FD08A'>bate por {_pct(beat_ew)}</b>" if beat_ew >= 0
                      else f"<b style='color:#F4607A'>pierde por {_pct(beat_ew)}</b>")
            ewphrase = (f" · vs <b>sectores equiponderados</b> {_pct(ewcum)}: la <b>selección</b> {ewverd} "
                        "a tener los 11 sectores por igual")
        head = (f"Desde que registras ({tperf['n']} semanas): <b style='color:{_cc(cum['sys'])}'>sistema {_pct(cum['sys'])}</b> · "
                f"SPY {_pct(cum.get('SPY',0))} · QQQ {_pct(cum['QQQ']) if 'QQQ' in cum else '—'} · IWM {_pct(cum['IWM']) if 'IWM' in cum else '—'} → "
                f"<b style='color:{_cc(beat_cum)}'>{verdict}</b>{ewphrase}")
        pend = tperf["pending"]
        html.append("<div class='panel full'><h2>Cómo lo está haciendo el sistema (semana a semana)</h2>"
                    f"<div class='note'>{head}</div>"
                    "<div class='scrollx'><table class='se'><tr><th class='se-l'>semana</th><th class='r'>sistema</th>"
                    + ewth + "<th class='r'>SPY</th><th class='r'>QQQ</th><th class='r'>IWM</th><th class='r'>vs S&amp;P</th></tr>"
                    + rows + cumrow + "</table></div>"
                    f"<div class='note' style='margin-top:8px'>La <b>cesta del sistema</b> = las posiciones de la <b>Cartera de la semana</b> (equiponderadas), rotada cada semana. "
                    "<b>sect.EW</b> = los <b>11 sectores SPDR equiponderados</b> (sin rotar): es la referencia honesta de si tu <b>selección</b> aporta algo o si te bastaría con tenerlos todos por igual. "
                    f"En curso ({esc(pend['week'])}): <b>{esc(', '.join(pend['basket']) or '—')}</b> — su resultado se medirá en el próximo registro. "
                    "<b>Paper-track honesto</b>: sin comisiones, impuestos ni slippage; se construye solo si ejecutas la herramienta cada semana. No es asesoramiento.</div></div>")
    elif basket:
        html.append("<div class='panel full'><h2>Cómo lo está haciendo el sistema (semana a semana)</h2>"
                    f"<div class='note'>Acabo de registrar la cesta de esta semana (<b>{esc(', '.join(basket))}</b>). "
                    "El seguimiento se construye <b>ejecutando la herramienta cada semana</b>: la próxima vez compararé esta cesta con <b>SPY / QQQ / IWM</b> "
                    "y verás, semana a semana y en acumulado, si el sistema bate al mercado. No es asesoramiento.</div></div>")

    # ---- SINTETIZAR FIW: acciones de agua ordenadas por fuerza relativa (para España, donde no se compra el ETF) ----
    if leaders and leaders.get("FIW"):
        _wn = {"ROP":"Roper","FERG":"Ferguson","MLI":"Mueller Ind.","AWK":"American Water","WAT":"Waters",
               "XYL":"Xylem","VLTO":"Veralto","ECL":"Ecolab","IEX":"IDEX","PNR":"Pentair","A":"Agilent",
               "IDXX":"IDEXX Labs","J":"Jacobs","MAS":"Masco","STN":"Stantec","ACM":"AECOM","FELE":"Franklin Electric",
               "WMS":"Adv. Drainage","WTS":"Watts Water","MWA":"Mueller Water","TTEK":"Tetra Tech","ZWS":"Zurn Elkay",
               "CNM":"Core & Main","BMI":"Badger Meter","ITRI":"Itron"}
        wrows = ""
        for r in leaders["FIW"]:
            acc = "—"
            if r["drs"] is not None:
                if r["drs"] >= 8:
                    acc = f"<span style='color:#2FD08A'>⚡ +{r['drs']}</span>"
                elif r["drs"] <= -8:
                    acc = f"<span style='color:#F4607A'>▼ {r['drs']}</span>"
                else:
                    acc = f"<span style='color:var(--txt3)'>{r['drs']:+d}</span>"
            rscol = "#2FD08A" if r["rs"] >= 70 else ("#F4B740" if r["rs"] >= 40 else "#9FB0C8")
            hicol = "#2FD08A" if r["hi"] >= 90 else ("#F4B740" if r["hi"] >= 75 else "#9FB0C8")
            cfd = (" <span class='lchip' style='background:#13351F;border-color:#2FD08A55;color:#2FD08A;font-size:10px;padding:1px 5px'>CFD XTB</span>"
                   if r["sym"] in XTB_CFD_AGUA else "")
            wrows += (f"<tr><td class='se-l'><b>{r['sym']}</b> <span style='color:var(--txt3);font-size:11px'>{esc(_wn.get(r['sym'],''))}</span>{cfd}</td>"
                      f"<td class='r' style='color:{rscol};font-weight:700'>{r['rs']}</td>"
                      f"<td class='r' style='color:{hicol}'>{r['hi']}%</td>"
                      f"<td class='r'>{acc}</td></tr>")
        topn = [r["sym"] for r in leaders["FIW"][:6]]
        html.append("<div class='panel full'><h2>Sintetiza FIW: agua por fuerza relativa</h2>"
                    "<div class='note'>El ETF FIW no se compra en España, pero <b>sus acciones US sí</b> (XTB/DEGIRO; lo que la UE bloquea es el ETF, no la acción). "
                    "Aquí van las empresas del fondo <b>ordenadas por percentil de fuerza relativa frente a todo el mercado</b> (no por tamaño): "
                    "<b>percentil</b> 1–99 (99 = de las más fuertes del mercado), <b>% máx 52s</b> (cerca de 100 = en máximos), "
                    "<b>acel. 3m</b> = cuánto ha subido su percentil en 3 meses (⚡ acelerando, ▼ perdiendo fuerza). "
                    f"Para sintetizar el ETF quedándote con lo mejor, una vía es las de mayor percentil — ahora mismo: <b>{esc(', '.join(topn))}</b>. "
                    "Equipondéralas y revisa cada semana: rota la que caiga de percentil. Ojo: 5–8 acciones es <b>más concentrado</b> que las 39 del ETF, "
                    "así que más riesgo idiosincrático; cuantas más metas, más te pareces al fondo. "
                    "La etiqueta <span style='color:#2FD08A'>CFD XTB</span> marca las que creo disponibles como CFD en XTB (para apalancar agua, que no tiene ETF x3); "
                    "<b>es una lista de partida que debes verificar</b> en el buscador de XTB, porque su catálogo cambia y no puedo comprobarlo en vivo. No es asesoramiento.</div>"
                    "<div class='scrollx'><table class='se'><tr><th class='se-l'>empresa</th><th class='r'>percentil RS</th>"
                    "<th class='r'>% máx 52s</th><th class='r'>acel. 3m</th></tr>" + wrows + "</table></div></div>")

    # ---- PLAN DE ROTACION DE MI CARTERA (compara tu cartera real con las señales) ----
    mi_plan = compute_mi_cartera_plan(MI_CARTERA, rrg, scores, flow, chosen)
    if mi_plan:
        mrows = ""
        for r in mi_plan["rows"]:
            est = (f"{r.get('quad','—')}" + (f" · {r['sc']}/5" if r.get("sc") is not None else "")) if r["base"] else "—"
            eur = f"{r['eur']:,.0f} €" if isinstance(r["eur"], (int, float)) else esc(str(r["eur"]))
            mrows += (f"<tr><td class='se-l'><b>{esc(r['tk'])}</b>{esc(r.get('via',''))}</td>"
                      f"<td class='r' style='color:#9FB0C8'>{esc(r['broker'])}</td>"
                      f"<td class='r'>{eur}</td><td class='r' style='color:#9FB0C8;font-size:11px'>{esc(est)}</td>"
                      f"<td class='r'><b style='color:{r['col']}'>{esc(r['act'])}</b></td>"
                      f"<td class='se-l' style='font-size:11px;color:var(--txt2)'>{r['why']}</td></tr>")
        rot = ""
        if mi_plan["rotar_hacia"]:
            chips = " ".join(f"<span class='lchip'><b>{r['sym']}</b> <span style='color:var(--txt3)'>{r['quad']}"
                             + (f" {r['sc']}/5" if r["sc"] is not None else "") + "</span></span>" for r in mi_plan["rotar_hacia"])
            rot = (f"<div style='margin-top:10px'><b style='color:#5B8CFF'>ROTAR HACIA</b> "
                   "<span class='note' style='display:inline'>(recomendadas que aún no tienes):</span><div class='lchips' style='margin-top:6px'>" + chips + "</div></div>")
        html.append("<div class='panel full'><h2>Plan de rotación de mi cartera</h2>"
                    f"<div class='note'>Compara <b>tus posiciones reales</b> (editables arriba del archivo en <code>MI_CARTERA</code>) con las señales de hoy. "
                    f"Total declarado: <b>{mi_plan['total']:,.0f} €</b> · mantener {mi_plan['n_mantener']} · vender/rotar {mi_plan['n_vender']}. "
                    "Las acciones y apalancados se evalúan por su ETF de referencia (vía …).</div>"
                    "<div class='scrollx'><table class='se'><tr><th class='se-l'></th><th class='r'>broker</th><th class='r'>importe</th>"
                    "<th class='r'>estado</th><th class='r'>acción</th><th class='se-l'>motivo</th></tr>"
                    + mrows + "</table></div>" + rot +
                    "<div class='note' style='margin-top:10px;color:#F4B740'>⚠ Esto aplica a tu <b>parte de rotación</b>, no a la liquidez que guardas para caídas. "
                    "Rotar cada semana entre 3 brokers genera <b>comisiones</b> y, en España, <b>plusvalías que tributan en cada venta</b> (rotación frecuente = mucho coste fiscal). "
                    "Por eso conviene <b>solo mover lo que cambia de verdad</b> (de Líder/Mejorando a Debilitándose/Rezagado), no cada microcambio. No es asesoramiento.</div></div>")

    # ---- VEREDICTO DE HOY (resumen de un vistazo, se inserta arriba) ----
    sem_short = stance.split("—")[0].strip() or "—"
    reg_short = regime["label"].split(" / ")[0]
    mkt = "alcista" if bull else "bajista"
    top_pos = [s for s, _ in sorted(chosen, key=lambda sd: -(sd[1]["mom"] or 0))[:(MAX_POSICIONES or 5)]] if chosen else []
    if not bull:
        cartera_txt = "liquidez — el filtro de tendencia no invierte en mercado bajista"
    elif top_pos:
        cartera_txt = ", ".join(top_pos)
    else:
        cartera_txt = "nada claro — mantener liquidez"
    breadth_pct = round(100 * sum(1 for s in rrg if rrg[s]["ratio"] >= 100) / max(1, len(rrg)))
    if not bull:
        ojo = "el S&P está por debajo de su media de 40s: prioriza <b>liquidez / defensivo</b>."
    elif excluded_di:
        ojo = f"<b>distribución oculta</b> (el dinero sale) en {', '.join(excluded_di)} — no te fíes de su subida."
    elif leaving:
        ojo = f"perdiendo liderazgo: <b>{', '.join(leaving[:4])}</b> (recoger / no añadir)."
    elif breadth_pct < 40:
        ojo = f"amplitud estrecha ({breadth_pct}%): la subida la sostienen pocos sectores, sé selectivo."
    else:
        ojo = "sin alertas mayores; sigue el plan."
    liq = ""
    if plan:
        nxt = next((r for r in plan["rungs"] if not r["hit"]), None)
        if nxt:
            liq = f"S&P {plan['dd']:.1f}% de máximos · próximo escalón −{nxt['thr']}% (faltan {(nxt['thr'] + plan['dd']):.1f}%)."
    verdict_html = (
        "<div class='panel full verdict'><h2>Veredicto de hoy</h2>"
        f"<div class='vrow'><span class='vk' style='background:{light}'>¿Invierto?</span>"
        f"<span><b style='color:{light}'>{esc(sem_short)}</b> · {esc(reg_short)}, {esc(risk['label'])}, mercado {mkt}</span></div>"
        f"<div class='vrow'><span class='vk' style='background:#5B8CFF'>Compra</span><span>{esc(cartera_txt)}</span></div>"
        f"<div class='vrow'><span class='vk' style='background:#F4B740'>Ojo</span><span>{ojo}</span></div>"
        + (f"<div class='vrow'><span class='vk' style='background:#93A4BC'>Liquidez</span><span>{liq}</span></div>" if liq else "")
        + "<div class='note' style='margin-top:6px'>Resumen de un vistazo. Debajo tienes la decisión completa (scoring, cartera, entrada temprana) "
          "y, plegado, todo el detalle (RRG, flujo, rankings). No es asesoramiento.</div></div>")

    # ---- ANALISIS IA (opcional) + boton para analizar con IA ----
    snap = state_summary(rrg, risk, regime, breadth, plan, flow)
    snap_js = (snap.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"')
                   .replace("`", "'").replace("\n", "\\n"))
    ai_inner = ""
    if ai_text:
        ai_inner = f"<div class='ai-box'>{esc(ai_text)}</div>"
    else:
        ai_inner = ("<div class='note'>Este panel calcula los datos (no es IA en tiempo real). Pulsa para que una IA "
                    "te analice la foto de hoy: copia el resumen y lo pegas en Claude/ChatGPT, o abre Claude directamente.</div>")
    html.append("<div class='panel full'><h2>Análisis con IA</h2>" + ai_inner +
                "<div style='margin-top:10px;display:flex;gap:8px;flex-wrap:wrap'>"
                f"<button class='ai-btn' onclick=\"navigator.clipboard.writeText('Analiza esta rotacion sectorial (datos de cierre):\\n\\n{snap_js}'); this.textContent='Copiado, pegalo en tu IA';\">Copiar resumen para IA</button>"
                "<a class='ai-btn alt' href='https://claude.ai/new' target='_blank' rel='noopener'>Abrir Claude</a>"
                "</div></div>")

    # ---- TIRA RESUMEN (flujo + alertas) justo encima del RRG ----
    entra, sale, cuida = [], [], []
    for sym, fdat in (flow or {}).items():
        dv = fdat.get("diverg"); lab = fdat.get("label")
        if dv == "acumulacion oculta":
            entra.append((sym, True))
        elif lab == "Acumulacion":
            entra.append((sym, False))
        if dv == "distribucion oculta":
            cuida.append(sym)
        elif lab == "Distribucion":
            sale.append(sym)
    def fchips(items, col, ring=0):
        out = ""
        for it in items:
            sym = it[0] if isinstance(it, tuple) else it
            strong = it[1] if isinstance(it, tuple) else False
            mark = ""
            if ring == 2:   # doble circulo rojo
                mark = "<span class='ring2'></span>"
            elif strong:
                mark = "<span class='ring1'></span>"
            out += f"<span class='fchip' style='border-color:{col}55;color:{col}'>{mark}{sym}</span>"
        return out or "<span class='qempty'>—</span>"
    alert_chips = ""
    for sym, kind, txt in (alerts or [])[:8]:
        acol = {"warn": "#F4B740", "in": "#2FD08A", "lead": "#5B8CFF", "down": "#F4607A"}.get(kind, "#93A4BC")
        alert_chips += f"<span class='fchip' style='border-color:{acol}55;color:{acol}' title='{esc(txt)}'>{sym}</span>"
    html.append("<div class='panel full'><h2>Resumen visual: flujo y rotación</h2>"
                "<div class='fgrid'>"
                "<div class='fcol'><div class='fhead' style='color:#2FD08A'>● Entra dinero (acumulación)</div>"
                f"<div class='fchips'>{fchips(entra, '#2FD08A')}</div></div>"
                "<div class='fcol'><div class='fhead' style='color:#F4607A'>◎ Cuidado: distribución oculta</div>"
                f"<div class='fchips'>{fchips(cuida, '#F4607A', ring=2)}</div></div>"
                "<div class='fcol'><div class='fhead' style='color:#F4B740'>Alertas de rotación</div>"
                f"<div class='fchips'>{alert_chips or '<span class=qempty>sin giros</span>'}</div></div>"
                "</div>"
                "<div class='note' style='margin-top:8px'>El <b>◎ doble círculo rojo</b> marca distribución oculta (precio sube, dinero sale: "
                "cuidado). Estos mismos avisos salen dibujados <b>dentro del RRG</b>: anillo verde = entra dinero, doble anillo rojo = cuidado.</div></div>")

    # ---- RRG con selector por grupo (Todos / Sectores / Subsectores / Internacional) ----
    # calidad global de cada ETF: alimenta el TAMAÑO de la bola (mas verde en todo -> mas grande)
    quality = {}
    sc_q = {r["sym"]: r for r in scores} if scores else {}
    for s in rrg:
        base = sc_q.get(s, {}).get("score")
        q = 2.5 if base is None else float(base)              # satelites sin score -> neutro
        f = flow.get(s, {}) if flow else {}
        if f.get("diverg") == "distribucion oculta":
            q -= 1.5
        elif f.get("obv_above") and f.get("cmf_pos"):
            q += 1.5
        if sector_breadth and s in sector_breadth:
            bp = sector_breadth[s]["pct"]
            q += 1.0 if bp >= 60 else (-1.0 if bp < 40 else 0.0)
        if f.get("vol_break"):
            q += 0.7
        quality[s] = q
    rrg_g = {g: {s: d for s, d in rrg.items() if GRUPO.get(s) == g} for g in GRUPO_ORDEN}
    html.append("<div class='panel full'><h2>Grafico de rotacion relativa (RRG)</h2>"
                "<div class='note'>Cada punto pequeño de la estela es una <b>semana</b> (pasa el ratón o toca para la fecha). "
                "La <b>flecha</b> marca hacia dónde se mueve. El <b>tamaño de la bola</b> = calidad global de la señal "
                "(scoring + flujo + amplitud + volumen): más grande = mejor en todo. Anillo <b style='color:#2FD08A'>verde</b> = entra dinero; "
                "<b style='color:#F4607A'>doble rojo</b> = distribución oculta (cuidado). Usa el selector para ver cada grupo a tamaño completo.</div>"
                "<div class='viewtabs'>"
                "<button class='viewtab rrgtab active' onclick=\"rrgView('all',this)\">Todos</button>"
                "<button class='viewtab rrgtab' onclick=\"rrgView('sector',this)\">Sectores</button>"
                "<button class='viewtab rrgtab' onclick=\"rrgView('subsector',this)\">Subsectores</button>"
                "<button class='viewtab rrgtab' onclick=\"rrgView('ia',this)\">IA</button>"
                "<button class='viewtab rrgtab' onclick=\"rrgView('internac',this)\">Internacional</button>"
                "</div>"
                "<div id='rrg-all' style='max-width:1040px;margin:0 auto;display:block'>" + render_svg(rrg, flow, quality) + "</div>"
                "<div id='rrg-sector' style='max-width:1040px;margin:0 auto;display:none'>" + render_svg(rrg_g["sector"], flow, quality) + "</div>"
                "<div id='rrg-subsector' style='max-width:1040px;margin:0 auto;display:none'>" + render_svg(rrg_g["subsector"], flow, quality) + "</div>"
                "<div id='rrg-ia' style='max-width:1040px;margin:0 auto;display:none'>" + render_svg(rrg_g["ia"], flow, quality) + "</div>"
                "<div id='rrg-internac' style='max-width:1040px;margin:0 auto;display:none'>" + render_svg(rrg_g["internac"], flow, quality) + "</div>"
                "<script>function rrgView(v,b){['all','sector','subsector','ia','internac'].forEach(function(g){"
                "document.getElementById('rrg-'+g).style.display=(g==v)?'block':'none';});"
                "document.querySelectorAll('.rrgtab').forEach(function(x){x.classList.remove('active')});b.classList.add('active');}</script>"
                "<div id='rrgtip' style='position:fixed;display:none;z-index:9999;background:#0F1623;color:#E6EDF6;"
                "border:1px solid #2B3850;border-radius:7px;padding:6px 9px;font-size:12px;max-width:240px;"
                "box-shadow:0 6px 20px rgba(0,0,0,.5);pointer-events:none'></div>"
                "<script>(function(){var tip=document.getElementById('rrgtip');"
                "function show(x,y,t){tip.textContent=t;tip.style.display='block';"
                "var L=Math.min(x+12,window.innerWidth-tip.offsetWidth-8);tip.style.left=Math.max(6,L)+'px';"
                "tip.style.top=Math.min(y+12,window.innerHeight-tip.offsetHeight-8)+'px';}"
                "function hide(){tip.style.display='none';}"
                "document.addEventListener('click',function(e){var d=e.target.closest('.tdot');"
                "if(d){show(e.clientX,e.clientY,d.getAttribute('data-t'));e.stopPropagation();}else hide();},true);"
                "document.querySelectorAll('.tdot').forEach(function(d){"
                "d.addEventListener('mouseenter',function(e){show(e.clientX,e.clientY,d.getAttribute('data-t'));});"
                "d.addEventListener('mouseleave',hide);});})();</script>"
                "<div class='legend' style='justify-content:center'>" +
                "".join(f"<span><i style='background:{QUAD[q][1]}'></i>{QUAD[q][0]}</span>" for q in QUAD) +
                "</div></div>")
    # ---- ZONA DE ENTRADA TEMPRANA (giro al alza, aún sin extender) ----
    if early:
        def _emerging_stock(sym):
            if not leaders or sym not in leaders:
                return None
            rows = leaders[sym]
            em = [r for r in rows if r.get("drs") is not None and r["drs"] >= 10 and 45 <= r["rs"] <= 92]
            if em:
                return max(em, key=lambda r: r["drs"])
            acc = [r for r in rows if r.get("drs") is not None and r["drs"] >= 5 and r["rs"] <= 92]
            return max(acc, key=lambda r: r["drs"]) if acc else None
        erows = ""
        for r in early[:8]:
            nm = NAMES.get(r["sym"], (r["sym"], r["sym"], ""))[1]
            qn = QUAD.get(r["quad"], (r["quad"], "#888"))[0]
            extcol = "#2FD08A" if r["ext"] <= 2 else "#F4B740"
            st = _emerging_stock(r["sym"])
            stock = (f"<b>{st['sym']}</b> <span style='color:#7BD88F'>RS {st['rs']} ↑{st['drs']}</span>"
                     if st else "<span style='color:#5E708A'>—</span>")
            fl = flow.get(r["sym"], {})
            if fl.get("diverg") == "distribucion oculta":
                conf = "<span style='color:#F4607A'>⚠ sale dinero</span>"
            elif fl.get("obv_above") and fl.get("cmf_pos"):
                conf = "<span style='color:#2FD08A'>✓ flujo confirma</span>"
            elif fl.get("obv_above") or fl.get("cmf_pos"):
                conf = "<span style='color:#F4B740'>~ parcial</span>"
            else:
                conf = "<span style='color:#5E708A'>— sin flujo</span>"
            erows += (f"<tr><td class='se-l'><b>{r['sym']}</b> <span style='color:var(--txt3);font-size:11px'>{esc(nm)}</span></td>"
                      f"<td class='r' style='color:#9FB0C8'>{qn}</td>"
                      f"<td class='r'>{r['ratio']:.0f}</td><td class='r' style='color:#5B8CFF'>{r['mom']:.0f}</td>"
                      f"<td class='r' style='color:#2FD08A'>+{r['accel']:.1f}</td>"
                      f"<td class='r' style='color:{extcol}'>{r['ext']:+.1f}%</td>"
                      f"<td class='r' style='font-size:11px'>{conf}</td>"
                      f"<td class='se-l'>{stock}</td></tr>")
        if erows:
            html.append("<div class='panel full'><h2>Zona de entrada temprana — giro al alza, aún sin extender</h2>"
                        "<div class='note'>Lo contrario de comprar caro: ETFs cuyo <b>impulso acaba de girarse al alza</b> "
                        "(aceleración positiva) pero que <b>todavía tienen fuerza baja y precio poco estirado</b> sobre su media. "
                        "Es la zona de abajo-izquierda del RRG que empieza a curvarse: <b>el principio del movimiento</b>, antes de que sea "
                        "un líder caro. <b>Aceleración</b> = subida del impulso en 4 semanas; <b>extensión</b> = cuánto está el precio por encima de su media de 40s. "
                        "<b>Flujo</b>: <span style='color:#2FD08A'>✓ confirma</span> = entra dinero (OBV&gt;media y CMF&gt;0) → señal más fiable; "
                        "<span style='color:#F4607A'>⚠ sale dinero</span> = distribución oculta, desconfía. La <b>acción emergente</b> es el nombre del sector que "
                        "más acelera y aún no está agotado. Más especulativo que el scoring. No es asesoramiento.</div>"
                        "<div class='scrollx'><table class='se'><tr><th class='se-l'></th><th class='r'>cuadrante</th><th class='r'>fuerza</th>"
                        "<th class='r'>impulso</th><th class='r'>acelera</th><th class='r'>extensión</th><th class='r'>flujo</th><th class='se-l'>acción emergente</th></tr>"
                        + erows + "</table></div></div>")

    # ---- Vista alternativa: mapa de cuadrantes (sin solapes) ----
    html.append("<details class='why'><summary>El porqué — mapas, flujo, rankings, backtests y diagnóstico <span>(toca para abrir)</span></summary>")
    # ---- MARGEN VS SU MEDIA HISTORICA (contexto de extension, no senal) ----
    if meanrev:
        mvrows = sorted((kv for kv in meanrev.items() if kv[1].get("ytd") is not None),
                        key=lambda kv: -(kv[1]["margen"] if kv[1]["margen"] is not None else -999))
        mrows = ""
        for sym, m in mvrows:
            nm = NAMES.get(sym, (sym, sym, ""))[1]
            mg = m["margen"]
            if m["ytd"] < -10:
                lec, col = "rezagado / débil", "#9FB0C8"
            elif mg >= 5:
                lec, col = "le queda recorrido", "#2FD08A"
            elif mg >= -5:
                lec, col = "en su media (estirado)", "#F4B740"
            else:
                lec, col = "por encima de su media", "#F4607A"
            q = rrg.get(sym, {})
            turning = q.get("quad") in ("leading", "improving") and q.get("mom", 0) > 100
            combo = " <span style='color:#2FD08A;font-size:11px'>⬆ sitio + girando</span>" if (mg >= 3 and turning) else ""
            ytdcol = "#2FD08A" if m["ytd"] >= 0 else "#F4607A"
            mrows += (f"<tr><td class='se-l'><b>{sym}</b> <span style='color:var(--txt3);font-size:11px'>{esc(nm)}</span>{combo}</td>"
                      f"<td class='r' style='color:#9FB0C8'>{m['cagr']:+.1f}%</td>"
                      f"<td class='r' style='color:{ytdcol}'>{m['ytd']:+.1f}%</td>"
                      f"<td class='r' style='color:{col}'><b>{mg:+.1f}</b></td>"
                      f"<td class='se-l' style='font-size:11px;color:{col}'>{lec}</td></tr>")
        if mrows:
            html.append("<div class='panel full'><h2>Margen vs su media histórica</h2>"
                        "<div class='note'>Rentabilidad media anual de cada ETF (CAGR ~10 años) frente a lo que <b>lleva en el año</b> (YTD). "
                        "El <b>margen</b> = media − YTD: <span style='color:#2FD08A'>positivo</span> = va por debajo de su ritmo habitual (le queda sitio); "
                        "<span style='color:#F4607A'>negativo</span> = ya por encima (estirado). <b>Es contexto, no señal</b>: estar por debajo de la media "
                        "<b>no garantiza</b> subir — un sector puede seguir barato años. Solo es potente combinado con el RRG: "
                        "<b style='color:#2FD08A'>⬆ sitio + girando</b> marca los que están por debajo de su media <b>Y</b> rotando al alza — "
                        "esa es la combinación que de verdad interesa. Ordenado por margen (más sitio arriba). No es asesoramiento.</div>"
                        "<div class='scrollx'><table class='se'><tr><th class='se-l'></th><th class='r'>media anual</th><th class='r'>este año</th>"
                        "<th class='r'>margen</th><th class='se-l'>lectura</th></tr>" + mrows + "</table></div></div>")
    if heatmap and heatmap["rows"]:
        hcols = "".join(f"<th class='hm-h'>{c}</th>" for c in heatmap["cols"])
        hrows = ""
        for r in heatmap["rows"]:
            nm = NAMES.get(r["sym"], (r["sym"], r["sym"], ""))[1]
            turn = "<span class='hm-turn' title='rotacion temprana'>↗ girando</span>" if r["turning"] else ""
            cells = ""
            for v in r["vals"]:
                txt = "—" if v is None else f"{v:+.1f}"
                cells += f"<td class='hm-c' style='{heatmap_color(v)}'>{txt}</td>"
            hrows += (f"<tr><td class='hm-name'><b>{r['sym']}</b> <span>{esc(nm)}</span>{turn}</td>{cells}</tr>")
        html.append("<div class='panel full'><h2>Mapa de calor: fuerza relativa por plazo</h2>"
                    "<div class='note'>Rendimiento de cada ETF <b>menos el del S&P 500</b> en cada plazo. "
                    "<b style='color:#2FD08A'>Verde</b> = bate al mercado; <b style='color:#F4607A'>rojo</b> = lo hace peor. "
                    "La señal de <b>rotación temprana</b> es una fila <b>roja a 3–6 meses</b> que se pone <b>verde a 1 semana/1 mes</b> "
                    "(marcada con <b>↗ girando</b>): un sector castigado que empieza a despertar.</div>"
                    f"<table class='hm'><tr><th class='hm-name'></th>{hcols}</tr>{hrows}</table></div>")

    # ---- Vista de cuadrantes ----
    html.append("<div class='panel full'><h2>Mapa de cuadrantes (vista alternativa)</h2>"
                "<div class='note'>La misma información sin puntos que se solapan: cada caja lista los ETFs de ese cuadrante, "
                "ordenados por impulso. El número es fuerza/impulso (100 = igual que el índice).</div>"
                + quadrant_grid(rrg) + "</div>")

    # columna izquierda
    html.append("<div>")
    html.append("<div class='panel'><h2>Impulso relativo (RS-Momentum)</h2>"
                "<div class='note'>A la derecha = gana impulso vs indice. A la izquierda = lo pierde. "
                "Aqui aparece pronto el giro antes de que el precio lo confirme.</div>" + "".join(bars) + "</div>")
    html.append("</div>")
    # columna derecha
    html.append("<div>")
    html.append("<div class='panel'><h2>Alertas de rotacion</h2><div class='alerts'>" + al + "</div></div>")
    html.append("<div class='panel'><h2>Amplitud y riesgo</h2>" +
                meter("Sectores con fuerza &gt; indice", breadth["leaders"]) +
                meter("Sectores en tendencia alcista", breadth["uptrend"]) +
                f"<div class='bigrisk {risk_cls}'>{risk['label']}</div>"
                f"<div class='note'>Ciclicos/sensibles vs defensivos: {'+' if risk['score']>=0 else ''}{risk['score']} puntos.</div></div>")
    # panel de flujo de dinero por volumen
    if flow:
        fl_sorted = sorted(flow.items(), key=lambda kv: kv[1]["flow"], reverse=True)
        divs = [(s, d) for s, d in flow.items() if d["diverg"]]
        flow_rows = []
        for s, d in fl_sorted:
            col = "#2FD08A" if d["label"] == "Acumulacion" else "#F4607A" if d["label"] == "Distribucion" else "#93A4BC"
            mag = min(abs(d["flow"]) / 3.0, 1.0) * 50
            left = 50 if d["flow"] >= 0 else 50 - mag
            cmf = d.get("cmf", 0)
            ccol = "#2FD08A" if cmf > 0 else "#F4607A" if cmf < 0 else "#93A4BC"
            cross = " <span class='sc-acc' title='OBV cruzó su media: presión compradora acelerando'>⚡</span>" if d.get("obv_cross") else ""
            vr = d.get("vol_rel", 1.0)
            vcol = "#2FD08A" if d.get("vol_break") else ("#F4B740" if vr >= 1.0 else "#5E708A")
            brk = " 🔼" if d.get("vol_break") else ""
            vol_h = f"<span class='bar-cmf' style='color:{vcol}' title='Volumen de hoy vs media de 20 sesiones (≥1.3x con precio al alza = ruptura con volumen)'>×{vr:.1f} vol{brk}</span>"
            flow_rows.append(f"<div class='bar-row'><span class='bar-lab'>{s}{cross}</span>"
                             f"<div class='bar-track'><div class='bar-mid'></div>"
                             f"<div class='bar' style='background:{col};width:{mag:.0f}%;left:{left:.0f}%'></div></div>"
                             f"<span class='bar-val' style='color:{col}'>{d['flow']:+.1f}</span>"
                             f"<span class='bar-cmf' style='color:{ccol}' title='Chaikin Money Flow'>CMF {cmf:+.2f}</span>"
                             f"{vol_h}</div>")
        div_html = ""
        if divs:
            items = []
            for s, d in divs:
                kind = "warn" if d["diverg"] == "distribucion oculta" else "in"
                txt = ("Precio sube pero sale dinero (distribucion oculta): cuidado."
                       if d["diverg"] == "distribucion oculta"
                       else "Precio flojo pero entra dinero (acumulacion oculta): vigilar.")
                items.append(f"<div class='alert a-{kind}'><span class='atk'>{s}</span><span class='atx'>{txt}</span></div>")
            div_html = "<div class='alerts' style='margin-bottom:10px'>" + "".join(items) + "</div>"
        html.append("<div class='panel'><h2>Flujo de dinero (volumen)</h2>"
                    "<div class='note'>Acumulacion/Distribucion por volumen (OBV + A/D + <b>CMF</b>). Verde = entra dinero, rojo = sale. "
                    "El <b>CMF</b> (−1 a +1) es la presión compradora reciente; <b>⚡</b> = el OBV cruzó al alza su media (acelera). "
                    "El <b>×N vol</b> es el volumen de hoy frente a su media de 20 sesiones; <b>🔼</b> = ruptura al alza con volumen (≥1.3×). "
                    "Las <b>divergencias</b> (precio y dinero en sentidos opuestos) avisan antes que el precio.</div>"
                    + div_html + "".join(flow_rows) + "</div>")
    # panel de cobertura EUR/USD (avanzado)
    if fx:
        euro_strong = fx["strong"]
        fxcol = "#F4607A" if euro_strong else "#2FD08A"
        fxtrend = "Euro fuerte / dólar débil" if euro_strong else "Dólar fuerte / euro débil"
        # recomendacion de cobertura segun fuerza del euro
        if euro_strong and fx["pos"] > 60:
            hedge = ("Euro fuerte y caro (cerca de máximos de 52s): es cuando <b>más conviene cubrir</b> tus "
                     "activos en dólares. Usa ETFs con clase <b>EUR hedged</b> o reduce exposición neta al dólar.")
            hcol = "#F4607A"; hlab = "Cobertura: ALTA prioridad"
        elif euro_strong:
            hedge = ("El euro sube pero no está caro: cobertura <b>moderada</b>. Puedes cubrir una parte e ir "
                     "ajustando si rompe la media de 200 al alza con fuerza.")
            hcol = "#F4B740"; hlab = "Cobertura: media"
        else:
            hedge = ("Dólar fuerte: te da <b>viento a favor</b> al convertir a euros, así que cubrir es poco "
                     "urgente. Vigila un giro del euro (cruce de la media de 50 sobre la de 200).")
            hcol = "#2FD08A"; hlab = "Cobertura: baja prioridad"
        sp = fx["spark"]
        fx_spark = ""
        if len(sp) > 2:
            lo_, hi_ = min(sp), max(sp); rg = (hi_ - lo_) or 1e-9
            pts = " ".join(f"{200*i/(len(sp)-1):.1f},{34-2-(34-4)*(v-lo_)/rg:.1f}" for i, v in enumerate(sp))
            fx_spark = f"<svg width='100%' height='34' viewBox='0 0 200 34' preserveAspectRatio='none'><polyline points='{pts}' fill='none' stroke='{fxcol}' stroke-width='1.5'/></svg>"
        html.append("<div class='panel'><h2>Cobertura EUR/USD</h2>" + fx_spark +
                    f"<div class='kv'><span>EUR/USD</span><b style='color:{fxcol}'>{fx['last']}</b></div>"
                    f"<div class='kv'><span>Media 50 / 200</span><b>{fx['ma50']} / {fx['ma200']}</b></div>"
                    f"<div class='kv'><span>Cruce de medias</span><b>{fx['cross']}</b></div>"
                    f"<div class='kv'><span>Variación 1m / 3m / 6m</span><b>{_pm(fx['roc1m'])} / {_pm(fx['roc3m'])} / {_pm(fx['roc6m'])}</b></div>"
                    f"<div class='kv'><span>Rango 52 semanas</span><b>{fx['lo52']}–{fx['hi52']} ({fx['pos']}%)</b></div>"
                    f"<div class='kv'><span>Tendencia</span><b style='color:{fxcol}'>{fxtrend}</b></div>"
                    f"<div class='note' style='margin-top:8px;color:{hcol}'><b>{hlab}.</b> {hedge}</div>"
                    "<div class='note' style='color:#5E708A'>La dirección del cambio no se puede predecir; esto es la "
                    "lectura técnica actual y su implicación para tu cartera en dólares, no una previsión.</div></div>")
    html.append("</div>")
    # fila completa: ranking enriquecido
    html.append("<div class='panel full'><h2>Ranking por cuadrante</h2>" + table + "</div>")
    # fila completa: backtest
    if bt:
        delta = bt["tot_s"] - bt["tot_b"]
        dcol = "#2FD08A" if delta >= 0 else "#F4607A"
        opt = []
        if TREND_FILTER: opt.append("filtro de tendencia (200d)")
        if MAX_POSICIONES: opt.append(f"tope {MAX_POSICIONES} posic.")
        opt.append({"volatilidad": "peso por volatilidad", "impulso": "peso por impulso", "igual": "peso igual"}[PESO])
        if BUFFER: opt.append(f"histeresis ±{BUFFER:g}")
        html.append("<div class='panel full'><h2>Backtest A — salir al debilitarse</h2>"
                    "<div class='note'>Estrategia <b>causal</b> (no mira el futuro): mantiene los activos en <b>Líder o Mejorando</b> "
                    "y <b>vende al pasar a Debilitándose</b>. Optimizaciones activas: <b>" + ", ".join(opt) + "</b>. "
                    f"Sobre {bt['weeks']} semanas (en mercado el {bt.get('exposure', 100)}% del tiempo).</div>"
                    + equity_svg(bt["dates"], bt["eq_s"], bt["eq_b"]) +
                    "<div class='summary' style='margin-top:12px'>"
                    + scard("Rentab. estrategia", f"{bt['tot_s']:+.1f}%", "#5B8CFF", "periodo completo")
                    + scard(f"Rentab. {BENCH}", f"{bt['tot_b']:+.1f}%", "#93A4BC", "comprar y mantener")
                    + scard("Diferencia", f"{delta:+.1f}%", dcol, "estrategia vs indice")
                    + scard("Caida maxima", f"{bt['mdd_s']:.0f}% / {bt['mdd_b']:.0f}%", "#F4B740", "estrategia / indice")
                    + "</div>"
                    "<div class='note' style='margin-top:8px'>El filtro de tendencia busca <b>bajar la caída máxima</b> (te saca en "
                    "mercados bajistas), no tanto subir la rentabilidad. Historia corta; sin comisiones ni impuestos. No es asesoramiento.</div></div>")
    if bt2:
        delta2 = bt2["tot_s"] - bt2["tot_b"]
        dcol2 = "#2FD08A" if delta2 >= 0 else "#F4607A"
        diff_ab = bt2["tot_s"] - (bt["tot_s"] if bt else 0)
        html.append("<div class='panel full'><h2>Backtest B — aguantar hasta rezagado</h2>"
                    "<div class='note'>Igual que la A pero <b>más paciente</b>: mantiene también los que están en <b>Debilitándose</b> "
                    "y <b>solo vende cuando caen a Rezagado</b> (la salida tardía «Debilitándose → Rezagado»). "
                    f"Sobre {bt2['weeks']} semanas.</div>"
                    + equity_svg(bt2["dates"], bt2["eq_s"], bt2["eq_b"]) +
                    "<div class='summary' style='margin-top:12px'>"
                    + scard("Rentab. estrategia", f"{bt2['tot_s']:+.1f}%", "#5B8CFF", "periodo completo")
                    + scard(f"Rentab. {BENCH}", f"{bt2['tot_b']:+.1f}%", "#93A4BC", "comprar y mantener")
                    + scard("Diferencia", f"{delta2:+.1f}%", dcol2, "estrategia vs indice")
                    + scard("B vs A", f"{diff_ab:+.1f}%", "#2FD08A" if diff_ab >= 0 else "#F4607A", "aguantar vs salir antes")
                    + "</div>"
                    "<div class='note' style='margin-top:8px'>Compara salir pronto (A) con aguantar (B): si <b>B &gt; A</b>, salir al primer "
                    "síntoma te cuesta dinero (sales demasiado pronto); si <b>A &gt; B</b>, cortar rápido protege. Historia corta, no es asesoramiento.</div></div>")
    # fila completa: empresa lider de cada ETF (por si no hay apalancado, entrar en la accion)
    rank_pri = {"leading": 0, "weakening": 1, "improving": 2, "lagging": 3}
    hold_syms = sorted([s for s in rrg if s in TOP_HOLDING],
                       key=lambda s: (rank_pri.get(rrg[s]["quad"], 9), -rrg[s]["mom"]))
    holds = ""
    for s in hold_syms:
        col = QUAD[rrg[s]["quad"]][1]
        holds += (f"<div class='hold'><span class='h-sym'><span class='dot' style='background:{col}'></span>{s}</span>"
                  f"<span class='h-top'>{esc(TOP_HOLDING[s])}</span>"
                  f"<a href='https://stockanalysis.com/etf/{s}/holdings/' target='_blank' rel='noopener'>ver</a></div>")
    html.append("<div class='panel full'><h2>Empresa líder de cada ETF</h2>"
                "<div class='note'>Por si no encuentras el ETF apalancado: la mayor posición de cada ETF (orientativo, "
                "puede cambiar). Pulsa «ver» para la lista actualizada de cada uno. Ordenado por cuadrante e impulso.</div>"
                "<div class='hold-grid'>" + holds + "</div></div>")
    # fila completa: acciones lideres por sector (RS Rating)
    if leaders:
        def rs_col(v):
            return "#2FD08A" if v >= 95 else "#7BD88F" if v >= 90 else "#F4B740" if v >= 80 else "#93A4BC" if v >= 60 else "#5E708A"
        lead_order = sorted(leaders.keys(),
                            key=lambda sec: (rank_pri.get(rrg.get(sec, {}).get("quad"), 9),
                                             -(rrg.get(sec, {}).get("mom", 0))))
        lrows = ""
        for sec in lead_order:
            q = rrg.get(sec, {}).get("quad")
            qchip = (f"<span class='dot' style='background:{QUAD[q][1]}'></span>" if q else "")
            chips = ""
            for r in leaders[sec][:LEADERS_TOP_N]:
                c = rs_col(r["rs"])
                star = " ★" if r["rs"] >= 99 else ""
                drs = r.get("drs")
                acc = ""
                if drs is not None and drs >= 6:
                    acc = f"<span class='accel'>↑{drs}</span>"
                elif drs is not None and drs <= -6:
                    acc = f"<span class='accel down'>↓{abs(drs)}</span>"
                chips += (f"<span class='lchip'><b>{r['sym']}</b>"
                          f"<span class='rsbadge' style='color:{c};border-color:{c}55'>RS {r['rs']}{star}</span>{acc}</span>")
            secname = NAMES.get(sec, (sec, sec, ""))[1]
            br = (sector_breadth or {}).get(sec)
            br_h = ""
            if br:
                bp = br["pct"]
                bc = "#2FD08A" if bp >= 60 else "#F4B740" if bp >= 40 else "#F4607A"
                btitle = ("amplitud amplia: la fuerza del sector está repartida" if bp >= 60 else
                          "amplitud media" if bp >= 40 else "ojo: falso liderazgo, suben pocas (2-3 megacaps)")
                br_h = f"<span class='lbreadth' style='color:{bc};border-color:{bc}55' title='{btitle}'>{bp}% &gt;media50</span>"
            lrows += (f"<div class='lrow'><div class='lsec'>{qchip}<b>{sec}</b> <span>{esc(secname)}</span>{br_h}</div>"
                      f"<div class='lchips'>{chips}</div></div>")
        html.append("<div class='panel full'><h2>Acciones líderes por sector (fuerza relativa)</h2>"
                    f"<div class='note'>RS Rating estilo IBD (1–99): percentil de fuerza calculado sobre las <b>{leaders_n} acciones seguidas</b> "
                    "(cuanto mayor el universo, más se acerca al percentil real del mercado; amplía la lista en SECTOR_STOCKS). "
                    "Las de <b>RS 90+</b> (verde) son las líderes; <b>★</b> = RS 99. El <b>↑N</b> es cuánto ha subido de percentil en 3 meses "
                    "(aceleración). El <b>% &gt;media50</b> de cada sector es su <b>amplitud real</b>: qué % de sus acciones están sobre su media de 50 sesiones "
                    "(<span style='color:#2FD08A'>verde &ge;60%</span> = subida repartida; <span style='color:#F4607A'>rojo &lt;40%</span> = <b>falso liderazgo</b>, tiran 2-3 megacaps). "
                    "Sectores ordenados por su cuadrante. Aproximación del rating, no asesoramiento.</div>"
                    + lrows + "</div>")

        # ---- ACCIONES EMERGENTES: RS acelerando en sectores donde entra dinero ----
        entering = [sec for sec in leaders if rrg.get(sec, {}).get("quad") in ("improving", "leading")]
        cands = []
        for sec in entering:
            for r in leaders[sec]:
                if r.get("drs") is not None:
                    cands.append((sec, r))
        # quitar duplicados (una accion puede estar en SMH e XLK): nos quedamos con el mayor drs
        best = {}
        for sec, r in cands:
            k = r["sym"]
            if k not in best or r["drs"] > best[k][1]["drs"]:
                best[k] = (sec, r)
        ranked = sorted(best.values(), key=lambda x: -x[1]["drs"])[:14]
        if ranked:
            erows = ""
            for sec, r in ranked:
                sweet = (r["drs"] >= 10 and 45 <= r["rs"] <= 92)
                dcol = "#2FD08A" if r["drs"] >= 10 else "#7BD88F" if r["drs"] >= 5 else "#93A4BC"
                qcol = QUAD[rrg.get(sec, {}).get("quad", "improving")][1]
                tag = "<span class='emtag'>emergente</span>" if sweet else ""
                erows += (f"<div class='emrow'><span class='em-sym'>{r['sym']}</span>"
                          f"<span class='em-sec' title='{esc(NAMES.get(sec,(sec,sec,''))[1])}'>"
                          f"<span class='dot' style='background:{qcol}'></span>{sec}</span>"
                          f"<span class='em-rs'>RS {r['rs']}</span>"
                          f"<span class='em-drs' style='color:{dcol}'>↑{r['drs']} en 3m</span>"
                          f"<span class='em-hi'>{r['hi']}% del máx.</span>{tag}</div>")
            html.append("<div class='panel full'><h2>Acciones emergentes (RS acelerando)</h2>"
                        "<div class='note'>Acciones cuyo <b>percentil RS sube más rápido</b> (últimos 3 meses), y solo en sectores que "
                        "están <b>entrando o liderando</b> en el RRG (donde fluye el dinero). La idea: pillarlas <b>mientras escalan</b>, "
                        "antes de que estén en RS 95+ y ya muy estiradas. <b>«emergente»</b> = sube fuerte (≥10) pero aún no está agotada "
                        "(RS 45–92). El «% del máx.» es lo cerca que está de su máximo de 52 semanas. No es asesoramiento.</div>"
                        + erows + "</div>")
    # fila completa: macro
    html.append("<div class='panel full'><h2>Regimen macro automatico: " + esc(regime["label"]) + "</h2>"
                "<div class='note'>Lectura orientativa deducida del propio mercado (bonos, credito, oro, dolar y apetito de riesgo).</div>"
                "<div class='conv'>"
                "<div><div class='kv'><span><b>Senales (variacion 13 semanas)</b></span><b></b></div>" + sig_rows + "</div>"
                "<div><div style='margin-bottom:10px'><h3 style='color:#2FD08A;font-size:11px'>Favorece</h3><div class='tags'>" + favor + "</div></div>"
                "<div><h3 style='color:#F4607A;font-size:11px'>Penaliza</h3><div class='tags'>" + hurt + "</div></div></div>"
                "</div>"
                "<div class='conv'>"
                "<div class='conv-box'><h3 style='color:#2FD08A'>Alta conviccion alcista</h3>"
                "<div class='note' style='margin:0 0 6px'>Regimen a favor + rotacion entrando/liderando:</div>"
                "<div class='tags'>" + buy_t + "</div></div>"
                "<div class='conv-box'><h3 style='color:#F4607A'>Evitar / reducir confirmado</h3>"
                "<div class='note' style='margin:0 0 6px'>Regimen en contra + rotacion saliendo/rezagada:</div>"
                "<div class='tags'>" + avoid_t + "</div></div>"
                "</div></div>")
    if fred_html:
        html.append("<div class='full'>" + fred_html + "</div>")
    html.append("</details>")
    html.insert(verdict_pos, verdict_html)
    # ===== PREVISION MACRO (reloj de inversion) — al final del todo =====
    try:
        _macro = fetch_macro()
        _mr = compute_macro_regime(_macro, ISM_MANUAL)
        if _macro and _mr:
            def _ar(it):
                d = it["dir"]; gu = it.get("goodup", True)
                if d > 0:
                    return "▲", ("#2FD08A" if gu else "#F4607A")
                if d < 0:
                    return "▼", ("#F4607A" if gu else "#2FD08A")
                return "▬", "#9FB0C8"
            def _rows(kind):
                r = ""
                for k, v in _macro.items():
                    if v["kind"] != kind:
                        continue
                    a, c = _ar(v)
                    r += (f"<tr><td class='se-l'>{esc(v['lab'])}</td>"
                          f"<td class='r'>{v['val']:g}{(' ' + v['unit']) if v['unit'] else ''}</td>"
                          f"<td class='r' style='color:{c}'>{a} {v['dir']:+g}</td></tr>")
                return r
            ism_row = (f"<tr><td class='se-l'>ISM manufacturas <span style='color:#5E708A;font-size:10px'>(manual)</span></td>"
                       f"<td class='r'>{ISM_MANUAL:g}</td>"
                       f"<td class='r' style='color:{'#2FD08A' if ISM_MANUAL >= 50 else '#F4607A'}'>{'expansión' if ISM_MANUAL >= 50 else 'contracción'}</td></tr>")
            conf_list, wait_list = [], []
            for s in _mr["favor"]:
                q = (rrg.get(s, {}) or {}).get("quad")
                (conf_list if q in ("leading", "improving") else wait_list).append(s)
            qcol = {"recuperacion": "#2FD08A", "sobrecalentamiento": "#F4B740",
                    "estanflacion": "#F4607A", "desinflacion": "#5AA9E6"}.get(_mr["quad"], "#9FB0C8")
            pr = _mr["pr"]
            esc_base = f"sigue <b>{_mr['label']}</b> → favorece {', '.join(_mr['favor'][:5])}"
            html.append(
                "<div class='panel full'><h2>Previsión macro — reloj de inversión</h2>"
                "<div class='note'>Cruzo la <b>dirección del crecimiento</b> (datos blandos, que se adelantan) con la <b>dirección de la inflación</b> "
                "(PCE/IPC subyacente) para situar el régimen, y miro dónde está entrando el dinero en tu propio panel. "
                "<b>Es un mapa de probabilidades por régimen, no una predicción.</b></div>"
                "<div class='scrollx'><table class='se'><tr><th class='se-l'>indicador</th><th class='r'>nivel</th><th class='r'>tendencia</th></tr>"
                "<tr><td colspan='3' style='color:#5E708A;font-size:11px;padding-top:6px'>DUROS (retrasados)</td></tr>"
                + _rows("hard") +
                "<tr><td colspan='3' style='color:#5E708A;font-size:11px;padding-top:6px'>BLANDOS (líderes)</td></tr>"
                + ism_row + _rows("soft") +
                "</table></div>"
                f"<div style='margin-top:12px;padding:10px;border:1px solid {qcol}55;border-radius:8px;background:{qcol}11'>"
                f"Crecimiento <b>{_mr['grow_lbl']}</b> · inflación <b>{_mr['infl_lbl']}</b> → "
                f"<b style='color:{qcol}'>{_mr['label']}</b><br>"
                f"<span style='color:#9FB0C8'>Playbook histórico:</span> a favor <b style='color:#2FD08A'>{', '.join(_mr['favor'])}</b> · "
                f"en contra <b style='color:#F4607A'>{', '.join(_mr['hurt'])}</b></div>"
                "<div class='note' style='margin-top:10px'><b>¿El dinero lo confirma?</b> "
                + (f"Ya en Líder/Mejorando: <b style='color:#2FD08A'>{', '.join(conf_list)}</b>. " if conf_list else "Aún ninguno de los favorecidos está en Líder/Mejorando. ")
                + (f"Aún no confirman: <span style='color:#9FB0C8'>{', '.join(wait_list)}</span>. " if wait_list else "")
                + "Actúa donde el régimen <b>y</b> el flujo coinciden.</div>"
                "<div class='scrollx' style='margin-top:10px'><table class='se'><tr><th class='se-l'>escenario</th><th class='r'>prob.*</th><th class='se-l'>implicación</th></tr>"
                f"<tr><td class='se-l'>Base</td><td class='r' style='font-weight:700'>~{pr['base']}%</td><td class='se-l'>{esc_base}</td></tr>"
                f"<tr><td class='se-l'>Alcista</td><td class='r'>~{pr['bull']}%</td><td class='se-l'>crecimiento reacelera con inflación contenida → giro a cíclicos/tech (XLK, XLY, XLF, IWM)</td></tr>"
                f"<tr><td class='se-l'>Bajista</td><td class='r'>~{pr['bear']}%</td><td class='se-l'>susto de crecimiento o inflación que reacelera → defensa (XLP, XLU, XLV, TLT, GLD)</td></tr>"
                "</table></div>"
                "<div class='note' style='margin-top:8px'><b>Línea de tiempo — qué dato rompe el empate:</b> "
                "el <b>PCE subyacente</b> (fin de mes) marca el eje inflación; las <b>nóminas</b> (1er viernes), el <b>ISM</b> (1er día hábil) y el <b>IPC</b> (mitad de mes) marcan el crecimiento. "
                "Cada build lo recalcula con el dato fresco.</div>"
                f"<div class='note' style='margin-top:8px;color:#5E708A'>*Probabilidades gruesas derivadas de la fuerza de la señal (claridad {round(_mr['conf'] * 100)}%), "
                "no de un modelo predictivo. La previsión macro es de poca pericia hasta para los bancos: úsala como marco, no como certeza. "
                "El <b>flujo manda</b>. No es asesoramiento.</div></div>")
        elif _macro is None:
            _k = _fred_key()
            if not _k:
                _diag = ("No encuentro la key. En el <b>PC</b>: pon <b>clave_fred.txt</b> (con la key dentro) en la misma carpeta "
                         "desde la que lanzas <code>python rotacion.py</code> y re-ejecuta. En <b>GitHub</b>: ponla en Secrets "
                         "(Settings → Secrets and variables → Actions → <b>FRED_API_KEY</b>).")
            else:
                _diag = (f"Key detectada (<b>{len(_k)} caracteres</b>) pero FRED no devolvió datos. Casi seguro es internet/firewall al "
                         "ejecutar o una key inválida. Pruébala en el navegador: "
                         "<code>https://api.stlouisfed.org/fred/series/observations?series_id=UNRATE&amp;api_key=TU_KEY&amp;file_type=json&amp;limit=1</code> "
                         "— si te devuelve JSON, la key va bien.")
            html.append("<div class='panel full'><h2>Previsión macro — reloj de inversión</h2>"
                        f"<div class='note'>⚙ {_diag}</div></div>")
    except Exception:
        pass
    # ===== V3 — VISTA OPERATIVA (cerrar Contexto, abrir Operativa) =====
    html.append("</div><div id='vista-op' style='display:none'>")
    try:
        QL = {"leading": "Líder", "improving": "Mejorando", "weakening": "Debilitándose", "lagging": "Rezagado"}
        QC = {"leading": "#2FD08A", "improving": "#5AA9E6", "weakening": "#F4B740", "lagging": "#F4607A"}
        GL = {"sector": "Sector", "subsector": "Subsector", "ia": "IA/infra", "internac": "Internac."}
        cand, warns = [], []
        for r in (scores or []):
            s = r["sym"]; sc = r["score"]; distrib = bool(r.get("distrib")); am = r.get("abs_mom", 0)
            q = (rrg.get(s, {}) or {}).get("quad")
            f = (flow or {}).get(s, {})
            money_in = bool(f.get("obv_above")) and bool(f.get("cmf_pos"))
            if (q in ("leading", "improving")) and sc >= 3 and not distrib and money_in and am > 0:
                cand.append((s, sc, q, am))
            elif distrib or (q == "weakening" and sc >= 3):
                warns.append((s, q, sc, "distribución oculta" if distrib else "debilitándose"))
        crows = ""
        for s, sc, q, am in cand:
            desc = NAMES.get(s, (s, "", ""))[1] or s
            grp = GL.get(GRUPO.get(s, ""), "")
            lid = TOP_HOLDING.get(s, "")
            crows += (f"<tr><td class='se-l'><b>{s}</b> <span style='color:var(--txt3);font-size:11px'>{esc(desc)}</span>"
                      + (f"<br><span style='color:#5E708A;font-size:10px'>líder: {esc(lid)}</span>" if lid else "") + "</td>"
                      f"<td class='r'><span style='color:{QC.get(q, '#9FB0C8')}'>{QL.get(q, q)}</span></td>"
                      f"<td class='r' style='font-weight:700;color:{'#2FD08A' if sc >= 4 else '#F4B740'}'>{sc}/5</td>"
                      f"<td class='r' style='color:#2FD08A'>+{am:g}%</td>"
                      f"<td class='r' style='color:#5E708A;font-size:11px'>{grp}</td></tr>")
        if not crows:
            crows = "<tr><td colspan='5' style='color:#9FB0C8;padding:12px'>Ningún candidato pasa todos los filtros ahora mismo. En seco: no fuerces entradas.</td></tr>"
        # ---- DESTRIPE: las acciones más fuertes dentro de cada candidato (por si entras directo en la empresa) ----
        destr = ""
        for s, sc, q, am in cand:
            rl = (leaders or {}).get(s)
            if not rl:
                continue
            trows = ""
            for j, rr in enumerate(rl[:5]):
                sym2 = rr["sym"]; rs2 = rr.get("rs", 0); hi2 = rr.get("hi", 0); dr = rr.get("drs")
                tag = " 🔥" if (rs2 >= 70 and (dr or 0) > 0) else ""
                if hi2 >= 97:
                    tag += " <span style='color:#F4B740;font-size:10px'>⚠ extendida</span>"
                if (dr or 0) > 0:
                    acc = f"<span style='color:#2FD08A'>⚡ +{dr}</span>"
                elif dr is not None and dr < 0:
                    acc = f"<span style='color:#F4607A'>▼ {dr}</span>"
                else:
                    acc = "—"
                stl = "font-weight:700;color:#2FD08A" if j == 0 else ""
                trows += (f"<tr><td class='se-l' style='{stl}'>{sym2}{tag}</td>"
                          f"<td class='r'>{rs2}</td><td class='r'>{hi2}%</td><td class='r'>{acc}</td></tr>")
            desc = NAMES.get(s, (s, "", ""))[1] or s
            destr += (f"<details style='margin:6px 0'><summary style='cursor:pointer;color:#9FB0C8;padding:4px 0'>"
                      f"<b style='color:#fff'>{s}</b> · {esc(desc)} — las más fuertes dentro</summary>"
                      "<div class='scrollx'><table class='se'><tr><th class='se-l'>empresa</th><th class='r'>percentil</th><th class='r'>% máx 52s</th><th class='r'>acel 3m</th></tr>"
                      + trows + "</table></div></details>")
        destr_block = (("<div class='note' style='margin-top:16px'><b>🔬 Tripas — entra en la empresa más fuerte, no a ciegas:</b> "
                        "dentro de cada candidato, sus acciones por <b>fuerza relativa</b> (percentil), con aceleración 3m y cercanía a máximos. "
                        "La <b style='color:#2FD08A'>primera (verde)</b> es la más fuerte. 🔥 = fuerte y acelerando · "
                        "<span style='color:#F4B740'>⚠ extendida</span> = pegada a máximos (fuerte pero con riesgo de comprar la punta, justo lo que pasó con MLI).</div>"
                        + destr) if destr else "")
        wrows = ""
        for s, q, sc, why in warns[:10]:
            desc = NAMES.get(s, (s, "", ""))[1] or s
            wrows += (f"<tr><td class='se-l'><b>{s}</b> <span style='color:var(--txt3);font-size:11px'>{esc(desc)}</span></td>"
                      f"<td class='r' style='color:#F4607A'>{esc(why)}</td></tr>")
        op = (
            "<div class='panel full'><h2>🎯 Operativa — candidatos ya filtrados</h2>"
            "<div class='note'>Lista corta de <b>posibles entradas</b> que pasan <b>todos</b> los filtros a la vez: "
            "cuadrante <b>Líder o Mejorando</b> + puntuación ≥ 3/5 + <b>el flujo confirma</b> (OBV y CMF a favor) + "
            "sin distribución oculta + ganando dinero a 3 meses. No es una orden de compra; es lo que merece mirar.</div>"
            "<div class='scrollx'><table class='se'><tr><th class='se-l'>candidato</th><th class='r'>cuadrante</th><th class='r'>nota</th><th class='r'>mom 3m</th><th class='r'>grupo</th></tr>"
            + crows + "</table></div>"
            + destr_block
            + (("<div class='note' style='margin-top:14px;color:#F4607A'><b>⚠ Ojo / evitar (no entrar):</b></div>"
                "<div class='scrollx'><table class='se'>" + wrows + "</table></div>") if wrows else "")
            + "<div class='note' style='margin-top:14px'><b>Cómo ejecutar (tu rutina):</b> decides en el <b>cierre del viernes</b> y ejecutas el lunes; "
              "tamaño por <b>volatilidad inversa</b> (menos en lo que más se mueve); <b>stop</b> bajo el mínimo de las últimas semanas o un % fijo que aguantes; "
              "y si está en <b>vertical</b> (mom 3m muy alto), mejor esperar una pausa que perseguir la punta. No es asesoramiento.</div>"
            "<div class='note' style='margin-top:8px;color:#5E708A'>Próximo paso (Fase 2): aquí se conectará tu <b>cartera</b> (archivo cartera.json) para mapear tus posiciones a mantener/añadir/recortar/salir y ver el saldo por broker.</div>"
            "</div>")
        html.append(op)
    except Exception:
        pass
    html.append("</div>")
    html.append("<script>function mainView(v,b){document.getElementById('vista-ctx').style.display=(v=='ctx')?'block':'none';"
                "document.getElementById('vista-op').style.display=(v=='op')?'block':'none';"
                "document.querySelectorAll('.mainview').forEach(function(x){x.classList.remove('active')});b.classList.add('active');window.scrollTo(0,0);}</script>")
    html.append("</main>")
    gen = dt.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    html.append("<footer>Actualizado: " + gen + " &middot; Herramienta de apoyo a la decision basada en fuerza relativa (estilo RRG) con datos de cierre reales "
                "de Stooq/Yahoo. No es asesoramiento financiero; los datos de fin de dia van con retardo y no sustituyen tu "
                "gestion de riesgo (tamano de posicion y stops).</footer>")
    html.append("<script>if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){});});}</script>")
    html.append("</body></html>")
    return "".join(html)

# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------
def main():
    print("=" * 56)
    print(" ROTACION - Smart-Money Flow Terminal (escritorio)")
    print("=" * 56)
    df, daily, sources = download_all()
    if BENCH not in df.columns or len(df) < 30:
        print("\nNo hay suficientes datos comunes para calcular. Reintenta mas tarde.")
        return
    print(f"\nMatriz alineada: {len(df)} semanas x {len(df.columns)} activos.")

    rrg = compute_rrg(df)
    alerts = build_alerts(rrg)
    breadth, risk = breadth_risk(rrg)
    flow = compute_volume_flow(daily)
    spy_flow = compute_volume_flow(daily, only=BENCH).get(BENCH)
    heatmap = compute_heatmap(daily)
    scores = compute_scores(df, rrg, daily, flow)
    early = compute_early(df, rrg)
    meanrev = compute_mean_reversion(SECTORS + THEMATIC + EXTRA)
    fg_idx = fetch_fear_greed()
    probs = compute_probabilities(df, rrg)
    fred, fred_sig = fetch_fred()
    regime = detect_regime(df, rrg, risk, fred_sig)
    buy, avoid = conviction(rrg, regime)
    bt = backtest(df, rrg, hold=("leading", "improving")) if BACKTEST else None
    bt2 = backtest(df, rrg, hold=("leading", "improving", "weakening")) if BACKTEST else None
    long_close, long_src, long_hl = fetch_long_close()
    dd, dd_meta = (drawdown_stats(long_close, DD_THRESHOLDS, hl=long_hl) if long_close is not None else (None, None))
    plan = cash_plan(long_close) if long_close is not None else None
    season = {}
    sp_se = compute_seasonality(long_close) if long_close is not None else None
    if sp_se:
        season["S&P 500"] = sp_se
    print("  Estacionalidad: descargando Nasdaq y Russell (historico largo)...")
    nq_close, _, _ = _fetch_long("^ndx", "QQQ", "^NDX")
    nq_se = compute_seasonality(nq_close) if nq_close is not None else None
    if nq_se:
        season["Nasdaq 100"] = nq_se
    rut_close, _, _ = _fetch_long("^rut", "IWM", "^RUT")
    rut_se = compute_seasonality(rut_close) if rut_close is not None else None
    if rut_se:
        season["Russell 2000"] = rut_se
    if not season:
        season = None
    fx = fetch_fx()
    leaders, leaders_n, sector_breadth = compute_rs_leaders(fetch_stock_universe()) if STOCK_LEADERS else (None, 0, {})
    ai_text = ai_commentary(state_summary(rrg, risk, regime, breadth, plan, flow))
    if ai_text:
        print("\n  Comentario IA generado.")

    # resumen en consola
    print("\n--- ALERTAS DE ROTACION ---")
    if alerts:
        for s, k, t in alerts:
            print(f"  [{k.upper():4s}] {s:5s} {t}")
    else:
        print("  Sin giros relevantes; liderazgo estable.")
    print(f"\n  Apetito de riesgo: {risk['label']} ({risk['score']:+})")
    print(f"  Amplitud: {breadth['leaders']}% con fuerza>indice | {breadth['uptrend']}% en tendencia")
    print(f"  Regimen macro{' (con FRED)' if fred else ''}: {regime['label']}")
    if buy:   print(f"  Alta conviccion alcista: {', '.join(buy)}")
    if avoid: print(f"  Evitar/reducir: {', '.join(avoid)}")
    divs = [s for s, d in (flow or {}).items() if d.get("diverg")]
    if divs: print(f"  Divergencias de flujo: {', '.join(divs)}")
    if bt:   print(f"  Backtest: estrategia {bt['tot_s']:+}% vs {BENCH} {bt['tot_b']:+}% ({bt['weeks']} sem)")
    if plan: print(f"  Caida actual del {BENCH} desde maximos: {plan['dd']}%")

    # avisos automaticos (Telegram / webhook) si hay giros, divergencias o caidas alcanzadas
    lines = []
    for s, k, t in alerts:
        lines.append(f"• {s}: {t}")
    for s, d in (flow or {}).items():
        if d.get("diverg"):
            lines.append(f"• {s}: {d['diverg']} (flujo de volumen)")
    if plan:
        for r in plan["rungs"]:
            if r["hit"]:
                lines.append(f"• Caida −{r['thr']}% del {BENCH} ALCANZADA → plan: desplegar {r['pct']}%")
    if lines:
        msg = (f"ROTACION {dt.date.today()} — {risk['label']} — {regime['label']}\n"
               + "\n".join(lines))
        if notify(msg):
            print("\nAviso enviado.")

    html = build_html(df, rrg, alerts, breadth, risk, regime, buy, avoid, sources, fred, flow=flow, bt=bt,
                      dd=dd, dd_meta=dd_meta, plan=plan, fx=fx, long_src=long_src, ai_text=ai_text, leaders=leaders, leaders_n=leaders_n, bt2=bt2, heatmap=heatmap, scores=scores, probs=probs, season=season, early=early, sector_breadth=sector_breadth, meanrev=meanrev, nq_close=nq_close, fg_idx=fg_idx, spy_flow=spy_flow)
    os.makedirs(SITE_DIR, exist_ok=True)
    # copiar archivos estaticos (iconos, manifest, service worker) al sitio
    if os.path.isdir(STATIC_DIR):
        import shutil
        for root, _, files in os.walk(STATIC_DIR):
            rel = os.path.relpath(root, STATIC_DIR)
            dest = os.path.join(SITE_DIR, rel) if rel != "." else SITE_DIR
            os.makedirs(dest, exist_ok=True)
            for fn in files:
                shutil.copy2(os.path.join(root, fn), os.path.join(dest, fn))
    out = os.path.abspath(OUTPUT_HTML)
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"\nPanel generado: {out}")
    if scores:
        print("\n  PUNTUACION (de mayor a menor) — entra en 4-5/5, vende <=2/5:")
        for r in scores[:12]:
            acc = " ⚡" if r["obv_cross"] else ""
            ticks = "".join("✓" if v else "·" for _, v in r["parts"])
            print(f"    {r['sym']:5s} {r['score']}/5  [{ticks}]  mom3m {r['abs_mom']:+5.1f}%{acc}")
    if not os.environ.get("CI"):     # en local abre el navegador; en GitHub no
        try:
            webbrowser.open("file://" + out)
            print("Abriendo en el navegador...")
        except Exception:
            print("Abre el archivo manualmente en tu navegador.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nCancelado.")
